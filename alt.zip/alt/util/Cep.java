package com.util;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Cep {
	private String 
	codigoPostal;
	private String 
	logradouro;
	private String 
	numero;
	private String 
	complemento;
	private String 
	bairro;
	private String 
	municipio;
	private String 
	uf;
	private Integer codigoIbge;



	public boolean buscaCEP(){
		WebServiceCep webServiceCep = WebServiceCep.searchCep(codigoPostal);
		if (webServiceCep.wasSuccessful()) {
			this.logradouro 
			= webServiceCep.getLogradouroFull();
			this.bairro 
			= webServiceCep.getBairro();
			this.municipio 
			= webServiceCep.getCidade();
			this.uf 
			= webServiceCep.getUf();

			return true;
			//caso haja problemas imprime as exce��es.
		} else {
			Tools tools = new Tools();
			String msg;
			msg = "Erro ["+ webServiceCep.getResulCode() +"] [" + webServiceCep.getResultText() + "] ao buscar o CEP";
			tools.msgAviso(msg);
			System.out.println(msg);
			return false;
		}
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public Integer getCodigoIbge() {
		return codigoIbge;
	}

	public void setCodigoIbge(Integer codigoIbge) {
		this.codigoIbge = codigoIbge;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
}
