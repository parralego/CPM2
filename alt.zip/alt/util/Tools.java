package com.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.mail.EmailException;
import org.jrimum.bopepo.BancosSuportados;
import org.jrimum.bopepo.Boleto;
import org.jrimum.bopepo.exemplo.Exemplos;
import org.jrimum.bopepo.view.BoletoViewer;
import org.jrimum.domkee.comum.pessoa.endereco.CEP;
import org.jrimum.domkee.comum.pessoa.endereco.Endereco;
import org.jrimum.domkee.comum.pessoa.endereco.UnidadeFederativa;
import org.jrimum.domkee.financeiro.banco.febraban.Agencia;
import org.jrimum.domkee.financeiro.banco.febraban.Carteira;
import org.jrimum.domkee.financeiro.banco.febraban.Cedente;
import org.jrimum.domkee.financeiro.banco.febraban.ContaBancaria;
import org.jrimum.domkee.financeiro.banco.febraban.NumeroDaConta;
import org.jrimum.domkee.financeiro.banco.febraban.Sacado;
import org.jrimum.domkee.financeiro.banco.febraban.TipoDeTitulo;
import org.jrimum.domkee.financeiro.banco.febraban.Titulo;
import org.jrimum.domkee.financeiro.banco.febraban.Titulo.EnumAceite;
import org.primefaces.context.RequestContext;

import com.model.User;

public class Tools {
	
	/****************************************************************************************************
	 * Nome: sprintf()
	 * Descricao: Reponsavel por fazer a substituicao dos caracteres '%' seguidos de um numero sequencial
	 * 			  iniciado em 0, esse valores sao substituido por os valores do lista passado por paramtro  
	 * Criacao: Cl�udio Parralego  
	 * Data: 04/02/2008 
	 ****************************************************************************************************/
	public String sprintf(String string, List<String> list){
		String sReplace;

		for(int i = 0; i < list.size(); i++){
			sReplace = "%" + String.valueOf(i) + "!";
			string = string.replaceAll(sReplace, list.get(i));
		}

		return string;
	}
	
	
	//
	// Conversoes
	//
	
	public Date convertStringToDate(String data, String formato){
		SimpleDateFormat sdf1= new SimpleDateFormat(formato);
		try {
			return sdf1.parse(data);
		} catch (ParseException e) {
			msgAviso(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	public String convertDateToString(Date data, String formato){
		SimpleDateFormat sdf1= new SimpleDateFormat(formato);
		return sdf1.format(data);
	}

	public int convertStringToInt(String s){
		return Integer.parseInt(s);
	}
	
	public String convertCharToString(char c){
		String s = String.valueOf(c);
		return s;
		
	}
	
	public String convertCharToString(char[] c){
		String s = String.valueOf(c);
		return s;
		
	}
	
	public String convertStringToInt(int i){
		return String.valueOf(i);
	}
	
	public String convertObjToString(Object o){
		return String.valueOf(o);
	}
	
	public int convertObjToInt(Object o){
		String s = String.valueOf(o);
		return Integer.parseInt(s);	
	}
	
	public char convertObjToChar(Object o){
		String s = String.valueOf(o);
		return s.charAt(0);	
	}
	
	public char[] convertObjToCharArray(Object o){
		String s = String.valueOf(o);
		return s.toCharArray();
	}
	
	public String convertIntToString(int i){
		return String.valueOf(i);
	}
	
	public char[] convertStringToChar(String s){
		return s.toCharArray();
	}
	
	public byte[] convertStringToByte(String s){
		return s.getBytes();
	}
	
	public String convertByteToString(byte[] b){
		return new String (b);
	}
	
	public char[] convertBinaryToChar(byte[] b){
		return b.toString().toCharArray();
	}
	
	public byte[] convertObjToBinary(Object o){
		return o.toString().getBytes();
	}
	
	public BigDecimal convertDoubleToBigDecimal(double val){
		return BigDecimal.valueOf(val);
	}
	
	
	
	
	
	
	public String convertLongToString(long l){
		return String.valueOf(l);
	}
	
	public void msgPergunta(String nomeDialog){
		RequestContext.getCurrentInstance().execute("PF('"+ nomeDialog +"').show()");
	}
	
	public void msgAviso(String msg){
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendInfoMessageToUser(msg);
	}
	
	public void msgDialog(String titulo, String msg){
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, titulo, msg);
        RequestContext.getCurrentInstance().showMessageInDialog(message);
	}
	
	public void msgErro(String msg){
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendErrorMessageToUser((msg));
	}
	
	public User getUserSession(){
		FacesContext fc = FacesContext.getCurrentInstance();
	    HttpSession session = (HttpSession)fc.getExternalContext().getSession(false);
		User user = (User) session.getAttribute("user");
		return user;
	}
	
	public String getParm(String nomeParm){
		FacesContext fc = FacesContext.getCurrentInstance();
		HttpSession session = (HttpSession)fc.getExternalContext().getSession(false);
		return (String) session.getAttribute(nomeParm);
	}
	
	public String getUrl(){
		String teste;
		FacesContext fc = FacesContext.getCurrentInstance();
		
		teste = fc.getExternalContext().getRequestServerName() + ":" + fc.getExternalContext().getRequestServerPort()+ fc.getExternalContext().getApplicationContextPath()  + "/" + "pages/public/login.xhtml";
		return teste;
	}
	
	public String getMainDir(){
		return FacesContext.getCurrentInstance().getExternalContext().getRealPath("/");
	}
	
	public Properties getProp(String nomeArq) throws IOException {
		Properties props = new Properties();

		String atualDir = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/" + nomeArq;
		
		File file = new File(atualDir);
		FileInputStream in = new FileInputStream(file);
		props.load(in);
		return props;
	}
	
	public Properties getPropGambi(String nomeArq) throws IOException {
		Properties props = new Properties();
		FileInputStream file = new FileInputStream("./email.properties");
		InputStreamReader in = new InputStreamReader(file, "UTF-8");
		props.load(in);
		return props;	
	}
	
	public boolean validarEmail(String email){
		if (!Pattern.matches(".+@.+\\.[a-z]+", email)) {
			return false;
		}
		return true;
	}
	
	public boolean sendSimpleEmail(String assunto, String mensagem, String toNome, String toEmail, String link){
		Email email = new Email();
		
		email.setAssunto(assunto);
		email.setTexto(mensagem);
		email.setToNome(toNome);
		email.setToEmail(toEmail);
		email.setLink(link);
		
		try {
			email.sendSimpleEmail();
			return true;
		} catch (EmailException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean sendHtmlEmail(String assunto, String mensagem, String toNome, String toEmail, String link) throws EmailException, MalformedURLException{
		
		Email email = new Email();
		
		email.setAssunto(assunto);
		email.setTexto(mensagem);
		email.setToNome(toNome);
		email.setToEmail(toEmail);
		email.setLink(link);
		
		try {
			email.sendEmailLinkAcesso();
			return true;
		} catch (EmailException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public String criptar(String sMsgDecodificada){
//		return new Base64().encodeToString(sMsgDecodificada.getBytes());
		
			Cipher cipher;
			try {
				cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
				
				byte[] chave = "CRIPTOGRAFIA CPM".getBytes();
				
				cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(chave, "AES"));
				return convertByteToString(cipher.doFinal(convertStringToByte(sMsgDecodificada)));
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				e.printStackTrace();
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			}
		return "";	
	}
	
	public String decriptar(String sMsgCodificada){
//		return new String(new Base64().decode(sMsgCodificada));
		Cipher cipher;
		try {
			cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			
			byte[] chave = "CRIPTOGRAFIA CPM".getBytes();
			
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(chave, "AES"));
			return convertByteToString(cipher.doFinal(convertStringToByte(sMsgCodificada)));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
	return "";	
	}
	
	
	
	public long getRandomLong(long min, long max) {
	    return (long) (Math.floor(Math.random() * (max - min + 1)) + min);
	}
	
	
	public boolean validarCpfCnpj(String sCpfCnpj, String sTipoDocu)
	{
		if(sCpfCnpj.toUpperCase().equals("NULL") || sCpfCnpj.equals(""))
			return true;
		int contador, digito1 = 0, digito2 = 0, pesonumero = 1, resto = 0;

		if(sTipoDocu.toLowerCase().equals("cpf"))
		{
	        for(contador = 0; contador < (sCpfCnpj.length()-2); contador++)
	        {
	            if (!sCpfCnpj.substring(contador, contador+1).equals(".") &&
	            	!sCpfCnpj.substring(contador, contador+1).equals("-"))
	            {
	                digito1 = digito1 + (11-pesonumero)* Integer.parseInt(sCpfCnpj.substring(contador, contador+1));
	                digito2 = digito2 + (12-pesonumero)* Integer.parseInt(sCpfCnpj.substring(contador, contador+1));
	                pesonumero++;
	            }
	        }
	        resto = digito1 - ((digito1 / 11 )*11);

	        if (resto < 2)
	            digito1 = 0;
	        else
	            digito1 = 11-resto;

	        digito2 = digito2 + (2*digito1);
	        resto = digito2 - ((digito2/11)*11);

	        if (resto < 2)
	            digito2 = 0;
	        else
	            digito2 = 11 - resto;

	        contador = sCpfCnpj.length();
	        if (String.valueOf(digito1).equals(sCpfCnpj.substring(contador-2,contador-1)) &&
	        	String.valueOf(digito2).equals(sCpfCnpj.substring(contador-1,contador)))
	            return true;
	        else
	        {
	        	 return false;
	        }
		}
		else
		{
			for(contador = 0; contador < (sCpfCnpj.length()-2); contador++)
	        {
	            if (sCpfCnpj.charAt(contador)!= '.' && sCpfCnpj.charAt(contador) != '-' && sCpfCnpj.charAt(contador) != '/')
	            {
	                if (pesonumero < 5)
	                    digito1 = digito1 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (6  - pesonumero);
	                else
	                    digito1 = digito1 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (14 - pesonumero);

	                if (pesonumero < 6)
	                    digito2 = digito2 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (7 - pesonumero);
	                else
	                    digito2 = digito2 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (15 - pesonumero);
	                pesonumero++;
	            }
	        }
	        resto = digito1 - ((digito1 / 11 )*11);

	        if (resto < 2)
	            digito1 = 0;
	        else
	            digito1 = 11-resto;

	        digito2 = digito2 + (2*digito1);
	        resto = digito2 - ((digito2/11)*11);

	        if (resto < 2)
	            digito2 = 0;
	        else
	            digito2 = 11 - resto;

	        contador = sCpfCnpj.length();
	        if (String.valueOf(digito1).equals(sCpfCnpj.substring(contador-2, contador-1)) &&
	        	String.valueOf(digito2).equals(sCpfCnpj.substring(contador-1, contador)))
	            return true;
	        else
	        {
	        	 return false;
	        }
		}
	}
	
	public int getIdade(Date dtNasct){

		Calendar dateOfBirth = new GregorianCalendar();
		dateOfBirth.setTime(dtNasct);
		 
		// Cria um objeto calendar com a data atual
		Calendar today = Calendar.getInstance();

		// Obt�m a idade baseado no ano
		int age = today.get(Calendar.YEAR) - dateOfBirth.get(Calendar.YEAR);
		dateOfBirth.add(Calendar.YEAR, age);

		//se a data de hoje � antes da data de Nascimento, ent�o diminui 1(um)
		if (today.before(dateOfBirth)){
			age--;
		}

		return age;
	}
	
	public int comparaData(Date date1, String date2, String format){
		try {
			SimpleDateFormat fmt = new SimpleDateFormat(format);
			Date dtBase = fmt.parse(date2);
			return date1.compareTo(dtBase);
		} catch (ParseException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public int comparaData(Date date1, Date date2){
			return date1.compareTo(date2);	
	}
	
	public void refresh() {  
        FacesContext context = FacesContext.getCurrentInstance();  
        Application application = context.getApplication();  
        ViewHandler viewHandler = application.getViewHandler();  
        UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());  
        context.setViewRoot(viewRoot);  
        context.renderResponse();  
    }
	
	public void gerarBoletoCobranca(User user, String nomeArqTemplate, String nomeArqDestino){
		Cedente cedente = new Cedente("AVM-PR - Associ��o da Vila Militar do Paran�", "00.000.208/0001-00");
		
		/***************************************************
         * INFORMANDO DADOS SOBRE O SACADO.
         ***************************************************/
        Sacado sacado = new Sacado(user.getName(), user.getCpf());
        
        
        // Informando o endere�o do sacado.
        Endereco enderecoSac = new Endereco();
        enderecoSac.setCep(new CEP(user.getCodigoPostal()));
        enderecoSac.setLogradouro(user.getLogradouro());
        enderecoSac.setNumero(user.getNumero());
        enderecoSac.setComplemento(user.getComplemento());
        enderecoSac.setBairro(user.getBairro());
        enderecoSac.setLocalidade(user.getMunicipio());
        enderecoSac.setUF(UnidadeFederativa.valueOf(user.getUf() ) != null ? UnidadeFederativa.valueOf(user.getUf() ) : UnidadeFederativa.DESCONHECIDO);
        sacado.addEndereco(enderecoSac);
        
        
        /***************************************************
         * INFORMANDO DADOS SOBRE O SACADOR AVALISTA.
         ***************************************************/
//        SacadorAvalista sacadorAvalista = new SacadorAvalista("JRimum Enterprise", "00.000.000/0001-91");
//
//        // Informando o endere�o do sacador avalista.
//        Endereco enderecoSacAval = new Endereco();
//        enderecoSacAval.setUF(UnidadeFederativa.DF);
//        enderecoSacAval.setLocalidade("Bras�lia");
//        enderecoSacAval.setCep(new CEP("59000-000"));
//        enderecoSacAval.setBairro("Grande Centro");
//        enderecoSacAval.setLogradouro("Rua Eternamente Principal");
//        enderecoSacAval.setNumero("001");
//        sacadorAvalista.addEndereco(enderecoSacAval);
        
        
        /***************************************************
         * INFORMANDO OS DADOS SOBRE O T�TULO.
         ***************************************************/
        
        // Informando dados sobre a conta banc�ria do t�tulo.
        ContaBancaria contaBancaria = new ContaBancaria(BancosSuportados.BANCO_BRADESCO.create());
        contaBancaria.setNumeroDaConta(new NumeroDaConta(123456, "0"));
        contaBancaria.setCarteira(new Carteira(30));
        contaBancaria.setAgencia(new Agencia(1234, "1"));
        
//        Titulo titulo = new Titulo(contaBancaria, sacado, cedente, sacadorAvalista);
        Titulo titulo = new Titulo(contaBancaria, sacado, cedente);
        titulo.setNumeroDoDocumento("123456");
        titulo.setNossoNumero("99345678912");
        titulo.setDigitoDoNossoNumero("5");
        titulo.setValor(BigDecimal.valueOf(0.23));
        titulo.setDataDoDocumento(new Date());
        titulo.setDataDoVencimento(new Date());
        titulo.setTipoDeDocumento(TipoDeTitulo.DM_DUPLICATA_MERCANTIL);
        titulo.setAceite(EnumAceite.N);
        titulo.setDesconto(new BigDecimal(0.05));
        titulo.setDeducao(BigDecimal.ZERO);
        titulo.setMora(BigDecimal.ZERO);
        titulo.setAcrecimo(BigDecimal.ZERO);
        titulo.setValorCobrado(BigDecimal.ZERO);
        
        /***************************************************
         * INFORMANDO OS DADOS SOBRE O BOLETO.
         ***************************************************/
        Boleto boleto = new Boleto(titulo);
        
        boleto.setLocalPagamento("Pag�vel preferencialmente na Rede X ou em qualquer Banco at� o Vencimento.");
        boleto.setInstrucaoAoSacado("Senhor sacado, sabemos sim que o valor cobrado n�o � o esperado,\n aproveite o DESCONT�O!");
        boleto.setInstrucao1("PARA PAGAMENTO 1 at� Hoje n�o cobrar nada!");
        boleto.setInstrucao2("PARA PAGAMENTO 2 at� Amanh� N�o cobre!");
        boleto.setInstrucao3("PARA PAGAMENTO 3 at� Depois de amanh�, OK, n�o cobre.");
        boleto.setInstrucao4("PARA PAGAMENTO 4 at� 04/xx/xxxx de 4 dias atr�s COBRAR O VALOR DE: R$ 01,00");
        boleto.setInstrucao5("PARA PAGAMENTO 5 at� 05/xx/xxxx COBRAR O VALOR DE: R$ 02,00");
        boleto.setInstrucao6("PARA PAGAMENTO 6 at� 06/xx/xxxx COBRAR O VALOR DE: R$ 03,00");
        boleto.setInstrucao7("PARA PAGAMENTO 7 at� xx/xx/xxxx COBRAR O VALOR QUE VOC� QUISER!");
        boleto.setInstrucao8("AP�S o Vencimento, Pag�vel Somente na Rede X.");
        

        String arqTemplate = getMainDir() + nomeArqTemplate;
        String arqDestino  = getMainDir() + nomeArqDestino; 
        BoletoViewer boletoViewer = new BoletoViewer(boleto, arqTemplate);
        
        File arquivoPdf = boletoViewer.getPdfAsFile(arqDestino);
        
        System.out.println(arquivoPdf.getPath());
		
		return;
	}
	
	public String gerarBoleto(String nomeArqTemplate, String nomeArqDestino){
		Titulo titulo = Exemplos.crieTitulo();
        titulo.getContaBancaria().setBanco(BancosSuportados.BANCO_DO_BRASIL.create());
        titulo.setNossoNumero("1234567890");
        
        Boleto boleto = Exemplos.crieBoleto(titulo);
        
        //Informando o template personalizado:
//        File templatePersonalizado = new File(ClassLoaders.getResource("/templates/BoletoTemplatePersonalizacaoSimples.pdf").getFile());
        
        System.out.println(getMainDir());
        
        String arqTemplate = getMainDir() + nomeArqTemplate;
        String arqDestino  = getMainDir() + nomeArqDestino; 
        BoletoViewer boletoViewer = new BoletoViewer(boleto, arqTemplate);
        
        File arquivoPdf = boletoViewer.getPdfAsFile(arqDestino);
        
//        FileOutputStream fs = new FileOutputStream(jspPath+"generated.pdf");
//        PdfWriter pdfWriter = new PdfWriter(fs);
//        PdfDocument pdfdoc = new PdfDocument(pdfWriter);
        
        if(!arquivoPdf.exists())
        	return null;
        
        return arqDestino;
	}
	
	
	
}
