package com.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.mail.EmailException;
import org.primefaces.context.RequestContext;

import com.model.User;

public class Tools {
	
	/****************************************************************************************************
	 * Nome: sprintf()
	 * Descricao: Reponsavel por fazer a substituicao dos caracteres '%' seguidos de um numero sequencial
	 * 			  iniciado em 0, esse valores sao substituido por os valores do lista passado por paramtro  
	 * Criacao: Cl�udio Parralego  
	 * Data: 04/02/2008 
	 ****************************************************************************************************/
	public String sprintf(String string, List<String> list){
		String sReplace;

		for(int i = 0; i < list.size(); i++){
			sReplace = "%" + String.valueOf(i) + "!";
			string = string.replaceAll(sReplace, list.get(i));
		}

		return string;
	}
	
	
	//
	// Conversoes
	//
	
	public Date convertStringToDate(String data, String formato){
		SimpleDateFormat sdf1= new SimpleDateFormat(formato);
		try {
			return sdf1.parse(data);
		} catch (ParseException e) {
			msgAviso(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	public String convertDateToString(Date data, String formato){
		SimpleDateFormat sdf1= new SimpleDateFormat(formato);
		return sdf1.format(data);
	}

	public int convertStringToInt(String s){
		return Integer.parseInt(s);
	}
	
	public String convertCharToString(char c){
		String s = String.valueOf(c);
		return s;
		
	}
	
	public String convertCharToString(char[] c){
		String s = String.valueOf(c);
		return s;
		
	}
	
	public String convertStringToInt(int i){
		return String.valueOf(i);
	}
	
	public String convertObjToString(Object o){
		return String.valueOf(o);
	}
	
	public int convertObjToInt(Object o){
		String s = String.valueOf(o);
		return Integer.parseInt(s);	
	}
	
	public char convertObjToChar(Object o){
		String s = String.valueOf(o);
		return s.charAt(0);	
	}
	
	public char[] convertObjToCharArray(Object o){
		String s = String.valueOf(o);
		return s.toCharArray();
	}
	
	public String convertIntToString(int i){
		return String.valueOf(i);
	}
	
	public char[] convertStringToChar(String s){
		return s.toCharArray();
	}
	
	public byte[] convertStringToByte(String s){
		return s.getBytes();
	}
	
	public String convertByteToString(byte[] b){
		return new String (b);
	}
	
	public char[] convertBinaryToChar(byte[] b){
		return b.toString().toCharArray();
	}
	
	public byte[] convertObjToBinary(Object o){
		return o.toString().getBytes();
	}
	
	
	
	
	
	
	public String convertLongToString(long l){
		return String.valueOf(l);
	}
	
	public void msgPergunta(String nomeDialog){
		RequestContext.getCurrentInstance().execute("PF('"+ nomeDialog +"').show()");
	}
	
	public void msgAviso(String msg){
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendInfoMessageToUser(msg);
	}
	
	public void msgDialog(String titulo, String msg){
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, titulo, msg);
        RequestContext.getCurrentInstance().showMessageInDialog(message);
	}
	
	public void msgErro(String msg){
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendErrorMessageToUser((msg));
	}
	
	public User getUserSession(){
		FacesContext fc = FacesContext.getCurrentInstance();
	    HttpSession session = (HttpSession)fc.getExternalContext().getSession(false);
		User user = (User) session.getAttribute("user");
		return user;
	}
	
	public String getParm(String nomeParm){
		FacesContext fc = FacesContext.getCurrentInstance();
		HttpSession session = (HttpSession)fc.getExternalContext().getSession(false);
		return (String) session.getAttribute(nomeParm);
	}
	
	public String getUrl(){
		String teste;
		FacesContext fc = FacesContext.getCurrentInstance();
		
		teste = fc.getExternalContext().getRequestServerName() + ":" + fc.getExternalContext().getRequestServerPort()+ fc.getExternalContext().getApplicationContextPath()  + "/" + "pages/public/login.xhtml";
		return teste;
	}
	
	public Properties getProp(String nomeArq) throws IOException {
		Properties props = new Properties();

		String atualDir = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/" + nomeArq;
		
		File file = new File(atualDir);
		FileInputStream in = new FileInputStream(file);
		props.load(in);
		return props;
	}
	
	public Properties getPropGambi(String nomeArq) throws IOException {
		Properties props = new Properties();
		FileInputStream file = new FileInputStream("./email.properties");
		InputStreamReader in = new InputStreamReader(file, "UTF-8");
		props.load(in);
		return props;	
	}
	
	public boolean validarEmail(String email){
		if (!Pattern.matches(".+@.+\\.[a-z]+", email)) {
			return false;
		}
		return true;
	}
	
	public boolean sendSimpleEmail(String assunto, String mensagem, String toNome, String toEmail, String link){
		Email email = new Email();
		
		email.setAssunto(assunto);
		email.setTexto(mensagem);
		email.setToNome(toNome);
		email.setToEmail(toEmail);
		email.setLink(link);
		
		try {
			email.sendSimpleEmail();
			return true;
		} catch (EmailException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean sendHtmlEmail(String assunto, String mensagem, String toNome, String toEmail, String link) throws EmailException, MalformedURLException{
		
		Email email = new Email();
		
		email.setAssunto(assunto);
		email.setTexto(mensagem);
		email.setToNome(toNome);
		email.setToEmail(toEmail);
		email.setLink(link);
		
		try {
			email.sendEmailLinkAcesso();
			return true;
		} catch (EmailException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public String criptar(String sMsgDecodificada){
//		return new Base64().encodeToString(sMsgDecodificada.getBytes());
		
			Cipher cipher;
			try {
				cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
				
				byte[] chave = "CRIPTOGRAFIA CPM".getBytes();
				
				cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(chave, "AES"));
				return convertByteToString(cipher.doFinal(convertStringToByte(sMsgDecodificada)));
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				e.printStackTrace();
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			}
		return "";	
	}
	
	public String decriptar(String sMsgCodificada){
//		return new String(new Base64().decode(sMsgCodificada));
		Cipher cipher;
		try {
			cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			
			byte[] chave = "CRIPTOGRAFIA CPM".getBytes();
			
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(chave, "AES"));
			return convertByteToString(cipher.doFinal(convertStringToByte(sMsgCodificada)));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
	return "";	
	}
	
	
	
	public long getRandomLong(long min, long max) {
	    return (long) (Math.floor(Math.random() * (max - min + 1)) + min);
	}
	
	
	public boolean validarCpfCnpj(String sCpfCnpj, String sTipoDocu)
	{
		if(sCpfCnpj.toUpperCase().equals("NULL") || sCpfCnpj.equals(""))
			return true;
		int contador, digito1 = 0, digito2 = 0, pesonumero = 1, resto = 0;

		if(sTipoDocu.toLowerCase().equals("cpf"))
		{
	        for(contador = 0; contador < (sCpfCnpj.length()-2); contador++)
	        {
	            if (!sCpfCnpj.substring(contador, contador+1).equals(".") &&
	            	!sCpfCnpj.substring(contador, contador+1).equals("-"))
	            {
	                digito1 = digito1 + (11-pesonumero)* Integer.parseInt(sCpfCnpj.substring(contador, contador+1));
	                digito2 = digito2 + (12-pesonumero)* Integer.parseInt(sCpfCnpj.substring(contador, contador+1));
	                pesonumero++;
	            }
	        }
	        resto = digito1 - ((digito1 / 11 )*11);

	        if (resto < 2)
	            digito1 = 0;
	        else
	            digito1 = 11-resto;

	        digito2 = digito2 + (2*digito1);
	        resto = digito2 - ((digito2/11)*11);

	        if (resto < 2)
	            digito2 = 0;
	        else
	            digito2 = 11 - resto;

	        contador = sCpfCnpj.length();
	        if (String.valueOf(digito1).equals(sCpfCnpj.substring(contador-2,contador-1)) &&
	        	String.valueOf(digito2).equals(sCpfCnpj.substring(contador-1,contador)))
	            return true;
	        else
	        {
	        	 return false;
	        }
		}
		else
		{
			for(contador = 0; contador < (sCpfCnpj.length()-2); contador++)
	        {
	            if (sCpfCnpj.charAt(contador)!= '.' && sCpfCnpj.charAt(contador) != '-' && sCpfCnpj.charAt(contador) != '/')
	            {
	                if (pesonumero < 5)
	                    digito1 = digito1 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (6  - pesonumero);
	                else
	                    digito1 = digito1 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (14 - pesonumero);

	                if (pesonumero < 6)
	                    digito2 = digito2 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (7 - pesonumero);
	                else
	                    digito2 = digito2 + Integer.parseInt(""+ sCpfCnpj.charAt(contador)) * (15 - pesonumero);
	                pesonumero++;
	            }
	        }
	        resto = digito1 - ((digito1 / 11 )*11);

	        if (resto < 2)
	            digito1 = 0;
	        else
	            digito1 = 11-resto;

	        digito2 = digito2 + (2*digito1);
	        resto = digito2 - ((digito2/11)*11);

	        if (resto < 2)
	            digito2 = 0;
	        else
	            digito2 = 11 - resto;

	        contador = sCpfCnpj.length();
	        if (String.valueOf(digito1).equals(sCpfCnpj.substring(contador-2, contador-1)) &&
	        	String.valueOf(digito2).equals(sCpfCnpj.substring(contador-1, contador)))
	            return true;
	        else
	        {
	        	 return false;
	        }
		}
	}
	
	public int getIdade(Date dtNasct){

		Calendar dateOfBirth = new GregorianCalendar();
		dateOfBirth.setTime(dtNasct);
		 
		// Cria um objeto calendar com a data atual
		Calendar today = Calendar.getInstance();

		// Obt�m a idade baseado no ano
		int age = today.get(Calendar.YEAR) - dateOfBirth.get(Calendar.YEAR);
		dateOfBirth.add(Calendar.YEAR, age);

		//se a data de hoje � antes da data de Nascimento, ent�o diminui 1(um)
		if (today.before(dateOfBirth)){
			age--;
		}

		return age;
	}
	
	public int comparaData(Date date1, String date2, String format){
		try {
			SimpleDateFormat fmt = new SimpleDateFormat(format);
			Date dtBase = fmt.parse(date2);
			return date1.compareTo(dtBase);
		} catch (ParseException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public int comparaData(Date date1, Date date2){
			return date1.compareTo(date2);	
	}
	
	public void refresh() {  
        FacesContext context = FacesContext.getCurrentInstance();  
        Application application = context.getApplication();  
        ViewHandler viewHandler = application.getViewHandler();  
        UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());  
        context.setViewRoot(viewRoot);  
        context.renderResponse();  
    }
	
}
