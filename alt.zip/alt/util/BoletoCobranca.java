package com.util;

import java.io.File;
import java.util.Date;

import org.jrimum.bopepo.BancosSuportados;
import org.jrimum.bopepo.Boleto;
import org.jrimum.bopepo.view.BoletoViewer;
import org.jrimum.domkee.comum.pessoa.endereco.CEP;
import org.jrimum.domkee.comum.pessoa.endereco.Endereco;
import org.jrimum.domkee.comum.pessoa.endereco.UnidadeFederativa;
import org.jrimum.domkee.financeiro.banco.febraban.Agencia;
import org.jrimum.domkee.financeiro.banco.febraban.Carteira;
import org.jrimum.domkee.financeiro.banco.febraban.Cedente;
import org.jrimum.domkee.financeiro.banco.febraban.ContaBancaria;
import org.jrimum.domkee.financeiro.banco.febraban.NumeroDaConta;
import org.jrimum.domkee.financeiro.banco.febraban.Sacado;
import org.jrimum.domkee.financeiro.banco.febraban.TipoDeTitulo;
import org.jrimum.domkee.financeiro.banco.febraban.Titulo;
import org.jrimum.domkee.financeiro.banco.febraban.Titulo.EnumAceite;

import com.model.User;

public class BoletoCobranca {
	
	public static final int BOLETO_COB_COLONIA	= 1;
	
	private Tools tools = new Tools();
	private String	nomeArqTemplate;
	private String 	nomeArqDestino;
	
	private String 	cedenteNome;
	private String 	cedenteCpfCnpj;
    
	private String 	sacadoNome;
	private String 	sacadoCpfCnpj;
	private String 	sacadoEndCEP;
	private String 	sacadoEndLogradouro;
	private String 	sacadoEndNumero;
	private String 	sacadoEndComplemento;
	private String 	sacadoEndBairro;
	private String 	sacadoEndMunicipio;
	private String 	sacadoEndUf;
	
	// DADOS BANCARIOS
	private int		bancoCodigo;
	private int		agenciaNumero;
	private String 	agenciaDv;
	private int 	contaNumero;
	private String  contaDv;
	private int		carteira;
	
	private String 	numeroDocumento;
	private String 	nossoNumero;
	private String 	nossoNumeroDv;
	private Date	dtDocumento;
	private Date    dtVencimento;
	private TipoDeTitulo tipoTitulo;
	private EnumAceite	 aceite;
	private double 	valor;
	private double 	desconto;
	private double 	deducao;
	private double  mora;
	private double 	acrescimo;
	private double  valCobrado;
	
	public boolean gerarBoletoColonia(User user, double valBoleto, double valDesconto, int idBoleto){
		if(idBoleto == BOLETO_COB_COLONIA){
			this.nomeArqTemplate	= "resources/templates/BoletoTemplatePersonalizacaoSimples.pdf";
			this.nomeArqDestino		= "resources/demo/reportResult.pdf";
		}
		
		// DADOS DO CEDENTE
		this.cedenteNome			= "AVM - Associa��o da Vila Militar do Paran�";
		this.cedenteCpfCnpj			= "00.000.208/0001-00";
		
		
		// DADOS DO SACADO
		this.sacadoNome				= user.getName();
		this.sacadoCpfCnpj			= user.getCpf();
		this.sacadoEndCEP 			= user.getCodigoPostal();
		this.sacadoEndLogradouro	= user.getLogradouro();
		this.sacadoEndNumero		= user.getNumero();
		this.sacadoEndComplemento	= user.getComplemento();
		this.sacadoEndBairro		= user.getBairro();
		this.sacadoEndMunicipio		= user.getMunicipio();
		this.sacadoEndUf			= user.getUf();
		
		
		// DADOS BANCARIOS
		this.bancoCodigo	= 237;
		this.agenciaNumero	= 1244;
		this.agenciaDv		= "0";
		this.contaNumero	= 30207;
		this.contaDv		= "4";
		this.carteira		= 30;
		
		
		// DADOS DO BOLETO
		this.numeroDocumento	= "123456";
        this.nossoNumero		= "00000000001";		// 11 Digitos 
        this.nossoNumeroDv		= "5";
        this.dtDocumento		= new Date();
        this.dtVencimento		= new Date();
        this.tipoTitulo			= TipoDeTitulo.DM_DUPLICATA_MERCANTIL;
        this.aceite				= EnumAceite.N;
        
        this.valor				= valBoleto;
        this.desconto			= valDesconto;
        this.deducao			= 0.0;
        this.mora				= 0.0;
        this.acrescimo			= 0.0;
        this.valCobrado			= 0.0;
				
		if(gerarBoletoCobranca() == null)
			return false;
		
		return true;
	}
	
	public File gerarBoletoCobranca(){
		Cedente cedente = new Cedente(cedenteNome, cedenteCpfCnpj);
		
		/***************************************************
         * INFORMANDO DADOS SOBRE O SACADO.
         ***************************************************/
        Sacado sacado = new Sacado(this.sacadoNome, this.sacadoCpfCnpj);
        
        
        // Informando o endere�o do sacado.
        Endereco enderecoSac = new Endereco();
        enderecoSac.setCep(new CEP(this.sacadoEndCEP));
        enderecoSac.setLogradouro(this.sacadoEndLogradouro);
        enderecoSac.setNumero(this.sacadoEndNumero);
        enderecoSac.setComplemento(this.sacadoEndComplemento);
        enderecoSac.setBairro(this.sacadoEndBairro);
        enderecoSac.setLocalidade(this.sacadoEndMunicipio);
        enderecoSac.setUF(UnidadeFederativa.valueOf(this.sacadoEndUf ) != null ? UnidadeFederativa.valueOf(this.sacadoEndUf ) : UnidadeFederativa.DESCONHECIDO);
        sacado.addEndereco(enderecoSac);
        
        
        /***************************************************
         * INFORMANDO OS DADOS SOBRE O T�TULO.
         ***************************************************/
        BancosSuportados bank = BancosSuportados.BANCO_BRADESCO;
        System.out.println(BancosSuportados.BANCO_BRADESCO.getCodigoDeCompensacao());
        System.out.println(bancoCodigo);
        // Informando dados sobre a conta banc�ria do t�tulo.
        ContaBancaria contaBancaria = new ContaBancaria(bank.create());
        contaBancaria.setAgencia(new Agencia(this.agenciaNumero, this.agenciaDv));
        contaBancaria.setNumeroDaConta(new NumeroDaConta(this.contaNumero, this.contaDv));
        contaBancaria.setCarteira(new Carteira(this.carteira));
        
        
        
        Titulo titulo = new Titulo(contaBancaria, sacado, cedente);
        titulo.setNumeroDoDocumento(this.numeroDocumento);
        titulo.setNossoNumero(this.nossoNumero);
        titulo.setDigitoDoNossoNumero(this.nossoNumeroDv);
        titulo.setDataDoDocumento(this.dtDocumento);
        titulo.setDataDoVencimento(this.dtVencimento);
        titulo.setTipoDeDocumento(this.tipoTitulo);
        titulo.setAceite(this.aceite);
        titulo.setValor(tools.convertDoubleToBigDecimal(this.valor));
        titulo.setDesconto(tools.convertDoubleToBigDecimal(this.desconto));
        
        titulo.setDeducao(tools.convertDoubleToBigDecimal(this.deducao));
        titulo.setMora(tools.convertDoubleToBigDecimal(this.mora));
        titulo.setAcrecimo(tools.convertDoubleToBigDecimal(this.acrescimo));
        titulo.setValorCobrado(tools.convertDoubleToBigDecimal(this.valCobrado));
        
        /***************************************************
         * INFORMANDO OS DADOS SOBRE O BOLETO.
         ***************************************************/
        Boleto boleto = new Boleto(titulo);
        
        boleto.setLocalPagamento("Pag�vel preferencialmente na Rede X ou em qualquer Banco at� o Vencimento.");
        boleto.setInstrucaoAoSacado("Senhor sacado, sabemos sim que o valor cobrado n�o � o esperado,\n aproveite o DESCONT�O!");
        boleto.setInstrucao1("PARA PAGAMENTO 1 at� Hoje n�o cobrar nada!");
        boleto.setInstrucao2("PARA PAGAMENTO 2 at� Amanh� N�o cobre!");
        boleto.setInstrucao3("PARA PAGAMENTO 3 at� Depois de amanh�, OK, n�o cobre.");
        boleto.setInstrucao4("PARA PAGAMENTO 4 at� 04/xx/xxxx de 4 dias atr�s COBRAR O VALOR DE: R$ 01,00");
        boleto.setInstrucao5("PARA PAGAMENTO 5 at� 05/xx/xxxx COBRAR O VALOR DE: R$ 02,00");
        boleto.setInstrucao6("PARA PAGAMENTO 6 at� 06/xx/xxxx COBRAR O VALOR DE: R$ 03,00");
        boleto.setInstrucao7("PARA PAGAMENTO 7 at� xx/xx/xxxx COBRAR O VALOR QUE VOC� QUISER!");
        boleto.setInstrucao8("AP�S o Vencimento, Pag�vel Somente na Rede X.");
        
        String arqTemplate = tools.getMainDir() + this.nomeArqTemplate;
        String arqDestino  = tools.getMainDir() + this.nomeArqDestino; 
        BoletoViewer boletoViewer = new BoletoViewer(boleto, arqTemplate);
        
        File arquivoPdf = boletoViewer.getPdfAsFile(arqDestino);
        
        if(!arquivoPdf.exists())
        	return null;
        
		return arquivoPdf;
	}

	public Tools getTools() {
		return tools;
	}

	public void setTools(Tools tools) {
		this.tools = tools;
	}

	public String getNomeArqTemplate() {
		return nomeArqTemplate;
	}

	public void setNomeArqTemplate(String nomeArqTemplate) {
		this.nomeArqTemplate = nomeArqTemplate;
	}

	public String getNomeArqDestino() {
		return nomeArqDestino;
	}

	public void setNomeArqDestino(String nomeArqDestino) {
		this.nomeArqDestino = nomeArqDestino;
	}

	public String getCedenteNome() {
		return cedenteNome;
	}

	public void setCedenteNome(String cedenteNome) {
		this.cedenteNome = cedenteNome;
	}

	public String getCedenteCpfCnpj() {
		return cedenteCpfCnpj;
	}

	public void setCedenteCpfCnpj(String cedenteCpfCnpj) {
		this.cedenteCpfCnpj = cedenteCpfCnpj;
	}

	public String getSacadoNome() {
		return sacadoNome;
	}

	public void setSacadoNome(String sacadoNome) {
		this.sacadoNome = sacadoNome;
	}

	public String getSacadoCpfCnpj() {
		return sacadoCpfCnpj;
	}

	public void setSacadoCpfCnpj(String sacadoCpfCnpj) {
		this.sacadoCpfCnpj = sacadoCpfCnpj;
	}

	public String getSacadoEndCEP() {
		return sacadoEndCEP;
	}

	public void setSacadoEndCEP(String sacadoEndCEP) {
		this.sacadoEndCEP = sacadoEndCEP;
	}

	public String getSacadoEndLogradouro() {
		return sacadoEndLogradouro;
	}

	public void setSacadoEndLogradouro(String sacadoEndLogradouro) {
		this.sacadoEndLogradouro = sacadoEndLogradouro;
	}

	public String getSacadoEndNumero() {
		return sacadoEndNumero;
	}

	public void setSacadoEndNumero(String sacadoEndNumero) {
		this.sacadoEndNumero = sacadoEndNumero;
	}

	public String getSacadoEndComplemento() {
		return sacadoEndComplemento;
	}

	public void setSacadoEndComplemento(String sacadoEndComplemento) {
		this.sacadoEndComplemento = sacadoEndComplemento;
	}

	public String getSacadoEndBairro() {
		return sacadoEndBairro;
	}

	public void setSacadoEndBairro(String sacadoEndBairro) {
		this.sacadoEndBairro = sacadoEndBairro;
	}

	public String getSacadoEndMunicipio() {
		return sacadoEndMunicipio;
	}

	public void setSacadoEndMunicipio(String sacadoEndMunicipio) {
		this.sacadoEndMunicipio = sacadoEndMunicipio;
	}

	public String getSacadoEndUf() {
		return sacadoEndUf;
	}

	public void setSacadoEndUf(String sacadoEndUf) {
		this.sacadoEndUf = sacadoEndUf;
	}

	public int getBancoCodigo() {
		return bancoCodigo;
	}

	public void setBancoCodigo(int bancoCodigo) {
		this.bancoCodigo = bancoCodigo;
	}

	public int getAgenciaNumero() {
		return agenciaNumero;
	}

	public void setAgenciaNumero(int agenciaNumero) {
		this.agenciaNumero = agenciaNumero;
	}

	public String getAgenciaDv() {
		return agenciaDv;
	}

	public void setAgenciaDv(String agenciaDv) {
		this.agenciaDv = agenciaDv;
	}

	public int getContaNumero() {
		return contaNumero;
	}

	public void setContaNumero(int contaNumero) {
		this.contaNumero = contaNumero;
	}

	public String getContaDv() {
		return contaDv;
	}

	public void setContaDv(String contaDv) {
		this.contaDv = contaDv;
	}

	public int getCarteira() {
		return carteira;
	}

	public void setCarteira(int carteira) {
		this.carteira = carteira;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNossoNumero() {
		return nossoNumero;
	}

	public void setNossoNumero(String nossoNumero) {
		this.nossoNumero = nossoNumero;
	}

	public String getNossoNumeroDv() {
		return nossoNumeroDv;
	}

	public void setNossoNumeroDv(String nossoNumeroDv) {
		this.nossoNumeroDv = nossoNumeroDv;
	}

	public Date getDtDocumento() {
		return dtDocumento;
	}

	public void setDtDocumento(Date dtDocumento) {
		this.dtDocumento = dtDocumento;
	}

	public Date getDtVencimento() {
		return dtVencimento;
	}

	public void setDtVencimento(Date dtVencimento) {
		this.dtVencimento = dtVencimento;
	}

	public TipoDeTitulo getTipoTitulo() {
		return tipoTitulo;
	}

	public void setTipoTitulo(TipoDeTitulo tipoTitulo) {
		this.tipoTitulo = tipoTitulo;
	}

	public EnumAceite getAceite() {
		return aceite;
	}

	public void setAceite(EnumAceite aceite) {
		this.aceite = aceite;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public double getDesconto() {
		return desconto;
	}

	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}

	public double getDeducao() {
		return deducao;
	}

	public void setDeducao(double deducao) {
		this.deducao = deducao;
	}

	public double getMora() {
		return mora;
	}

	public void setMora(double mora) {
		this.mora = mora;
	}

	public double getAcrescimo() {
		return acrescimo;
	}

	public void setAcrescimo(double acrescimo) {
		this.acrescimo = acrescimo;
	}

	public double getValCobrado() {
		return valCobrado;
	}

	public void setValCobrado(double valCobrado) {
		this.valCobrado = valCobrado;
	}
}
