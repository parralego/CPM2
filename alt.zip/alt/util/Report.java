package com.util;

import java.util.List;

public class Report {
	private int    id;
	private String nome;
	private String nomeArqJasper;
	private String assuntoEmail;
	private List<ReportFild> campoList;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getAssuntoEmail() {
		return assuntoEmail;
	}
	public void setAssuntoEmail(String assuntoEmail) {
		this.assuntoEmail = assuntoEmail;
	}
	public List<ReportFild> getCampoList() {
		return campoList;
	}
	public void setCampoList(List<ReportFild> campoList) {
		this.campoList = campoList;
	}
	public String getNomeArqJasper() {
		return nomeArqJasper;
	}
	public void setNomeArqJasper(String nomeArqJasper) {
		this.nomeArqJasper = nomeArqJasper;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}
