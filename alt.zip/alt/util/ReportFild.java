package com.util;

public class ReportFild {
	
	private String	label;
	private String 	nomeParametro;
	private boolean	obrigatorio;
	private Object 	campo;
	
	public ReportFild(){
		
	}
	
	public ReportFild(String label, String nomeParametro, boolean obrigatorio, Object campo){
		this.label 			= label;
		this.nomeParametro	= nomeParametro;
		this.obrigatorio	= obrigatorio;
		this.campo			= campo;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String descricao) {
		this.label = descricao;
	}

	public boolean isObrigatorio() {
		return obrigatorio;
	}

	public void setObrigatorio(boolean obrigatorio) {
		this.obrigatorio = obrigatorio;
	}

	public Object getCampo() {
		return campo;
	}

	public void setCampo(Object campo) {
		this.campo = campo;
	}

	public String getNomeParametro() {
		return nomeParametro;
	}

	public void setNomeParametro(String nomeParametro) {
		this.nomeParametro = nomeParametro;
	}
	

}
