package com.util;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Properties;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;

import com.model.SorteioResultado;
import com.model.User;

public class Email {
	
	private String hostName;
	private int    smtpPort;
	private String user;
	private String senha;
	private String fromNome;
	private String fromEmail;
	private String toNome;
	private String toEmail;
	private String assunto;
	private String texto;
	private String link;
	private String msg1;
	private String assinaturaHtml;
	private String descLink;
	private int    numMaxDestinatario;
	
	Properties prop = null;
	
	private boolean sslConect;
	private boolean startTLS;
	private boolean debug;
	private boolean teste;
	
	private boolean usaAssinatura;
	
	public boolean getConfig(){
		Tools tools = new Tools();
		
		try {
			prop = tools.getProp("email.properties");
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		
		this.hostName 			= prop.getProperty("hostName");
		this.smtpPort 			= tools.convertStringToInt(prop.getProperty("smtpPort"));
		this.user 				= prop.getProperty("user");
		this.senha 				= prop.getProperty("senha");
		this.fromNome			= prop.getProperty("fromNome"); 
		this.fromEmail			= prop.getProperty("fromEmail");
		this.descLink   		= prop.getProperty("descLink");
		
		if(this.msg1 == null || this.msg1.isEmpty())
			this.msg1				= prop.getProperty("msg");
		
		if(this.assinaturaHtml == null || this.assinaturaHtml.isEmpty())
			this.assinaturaHtml				= prop.getProperty("assinaturaHtml");
		
		this.numMaxDestinatario = tools.convertStringToInt(prop.getProperty("numMaxDestinatario")); 
		
		if (prop.getProperty("sslConect").equals("SIM"))
			this.sslConect = true;
		else
			this.sslConect = false;
		
		if (prop.getProperty("startTLS").equals("SIM"))
			this.startTLS = true;
		else
			this.startTLS = false;
		
		if (prop.getProperty("debug").equals("SIM"))
			this.debug = true;
		else
			this.debug = false;
		
		if (prop.getProperty("teste").equals("SIM"))
			this.teste = true;
		else
			this.teste = false;
		
		if(this.assunto == null || this.assunto.isEmpty()){
			if (prop.getProperty("useAssuntoPadrao").equals("SIM"))
				this.assunto	= prop.getProperty("assunto");
		}
		
		return true;
	}
	
	public void printDebug(){
		if(debug){
			System.out.println("hostName	" + this.hostName	);
			System.out.println("smtpPort	" + this.smtpPort	);
			System.out.println("user		" + this.user		);
			System.out.println("senha		" + this.senha		);
			System.out.println("sslConect	" + this.sslConect	);
			System.out.println("startTLS	" + this.startTLS	);
			System.out.println("fromNome	" + this.fromNome	);
			System.out.println("fromEmail	" + this.fromEmail	);
			System.out.println("toNome		" + this.toNome		);
			System.out.println("toEmail		" + this.toEmail	);
		}
	}
	
	
	
	public boolean sendSimpleEmail() throws EmailException{
		
		if(!getConfig())
			return false;
		
		org.apache.commons.mail.Email email = new SimpleEmail();
		email.setHostName(this.hostName);
		email.setSmtpPort(this.smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
		email.setSSLOnConnect(this.sslConect);
		email.setStartTLSEnabled(this.startTLS);
		email.setDebug(this.debug);
		
		
		email.setFrom(this.fromEmail, this.fromNome);
		email.setSubject(this.assunto);
		email.setMsg(this.texto);
		email.addTo(this.toEmail, this.toNome);
		
		printDebug();
		
		email.send();
		
		return true;
	}
	
	public boolean sendHtmlEmail(String assunto, String texto, String from, String to) throws EmailException, MalformedURLException{
		if(!getConfig())
			return false;
		
		HtmlEmail email = new HtmlEmail();
		email.setHostName(this.hostName);
		email.setSmtpPort(this.smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
		email.setSSLOnConnect(this.sslConect);
		email.setStartTLSEnabled(this.startTLS);
		email.setDebug(this.debug);
		
		
		email.setFrom(from);
		email.setSubject(assunto);
		email.addTo(to);
		
		email.setHtmlMsg(texto);
		
		email.setTextMsg("Seu servidor de e-mail n�o suporta mensagem HTML");
		
		if(this.debug)
			System.out.println(texto);
		
		printDebug();
		
		email.send();
		return true;
	}
	
	
	public boolean sendHtmlEmail(StringBuffer msg) throws EmailException, MalformedURLException{
		if(!getConfig())
			return false;
		
		HtmlEmail email = new HtmlEmail();
		email.setHostName(this.hostName);
		email.setSmtpPort(this.smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
		email.setSSLOnConnect(this.sslConect);
		email.setStartTLSEnabled(this.startTLS);
		email.setDebug(this.debug);
		email.setFrom(this.fromEmail, this.fromNome);
		
		email.setSubject(this.assunto);
		email.addTo(this.toEmail, this.toNome);

		if(usaAssinatura)
			msg.append(this.assinaturaHtml);
			
		email.setHtmlMsg(msg.toString());
		
		email.setTextMsg("Seu servidor de e-mail n�o suporta mensagem HTML");
		
		if(this.debug)
			System.out.println(msg.toString());
		
		printDebug();
		
		email.send();
		return true;
	}
	
	public boolean sendEmailLinkAcesso() throws EmailException, MalformedURLException{
		if(!getConfig())
			return false;
		
		HtmlEmail email = new HtmlEmail();
		email.setHostName(this.hostName);
		email.setSmtpPort(this.smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
		email.setSSLOnConnect(this.sslConect);
		email.setStartTLSEnabled(this.startTLS);
		email.setDebug(this.debug);
		
		
		email.setFrom(this.fromEmail, this.fromNome);
		email.setSubject(this.assunto);
		email.addTo(this.toEmail, this.toNome);
		
		StringBuffer msg = new StringBuffer();
		
		msg.append("<?xml version='1.0' encoding='UTF-8' ?> ");
		msg.append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' ");
		msg.append("'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd' ");
		msg.append("<html> <body> ");
		
		msg.append("<h3>").append(msg1).append("</h3> ");
		
		msg.append("<br><br> ");
		
		msg.append("<a href='http://").append(this.link).append("'>").append(this.descLink).append("</a>");
		
		msg.append("<br><br> ");
		
		msg.append(assinaturaHtml);
		
		msg.append("</html> </body> ");
		
		email.setHtmlMsg(msg.toString());
		
		email.setTextMsg("Seu servidor de e-mail n�o suporta mensagem HTML");
		
		if(this.debug)
			System.out.println(msg.toString());
		
		printDebug();
		
		email.send();
		return true;
	}
	
	public boolean sendEmailAvisoSorteio(String nomeArquivoAnexo, List<SorteioResultado> sorteioResultadoList, User user){
		if(!getConfig())
			return false;
		
		
		File f = new File(nomeArquivoAnexo);
		int  idexList = 0;
		
		
		EmailAttachment attachment = new EmailAttachment();  
        attachment.setPath(f.getPath()); 									// Obtem o caminho do arquivo  
        attachment.setName(f.getName()); 									// Obtem o nome do arquivo
        attachment.setDescription(prop.getProperty("emailDescArqAnexo"));	// Como vai estar escrino o nome do arquivo em anexo
        attachment.setDisposition(EmailAttachment.ATTACHMENT);  
        
        try {
        	// Se foi informado o usuario
			if(user != null && user.getEmail() != null && !user.getEmail().isEmpty()){
				// Create the email message  
	        	MultiPartEmail email = new MultiPartEmail();
				email.setHostName(this.hostName);
				email.setSmtpPort(this.smtpPort);
				email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
				email.setSSLOnConnect(this.sslConect);
				email.setStartTLSEnabled(this.startTLS);
				email.setDebug(this.debug);
				email.setFrom(this.fromEmail, this.fromNome);
				
				email.setSubject(prop.getProperty("emailInscAssunto"));
				email.setMsg(prop.getProperty("emailInscMsg") + "\n\n" + prop.getProperty("emailInscmMg2") + "\n\n" + prop.getProperty("assinaturaSimples"));
				email.addBcc(user.getEmail(), user.getName());
				
				// add the attachment  
				email.attach(attachment);  
	
				// send the email  
				email.send();
			}
			else{
				if(sorteioResultadoList != null && !sorteioResultadoList.isEmpty()){
					while(idexList < sorteioResultadoList.size()){
			        	// Create the email message  
			        	MultiPartEmail email = new MultiPartEmail();
						email.setHostName(this.hostName);
						email.setSmtpPort(this.smtpPort);
						email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
						email.setSSLOnConnect(this.sslConect);
						email.setStartTLSEnabled(this.startTLS);
						email.setDebug(this.debug);
						email.setFrom(this.fromEmail, this.fromNome);
						
						email.setSubject(prop.getProperty("emailInscAssunto"));
						email.setMsg(prop.getProperty("emailInscMsg") + "\n\n" + prop.getProperty("emailInscmMg2") + "\n\n" + prop.getProperty("emailInscmMg3"));
						
						// add the attachment  
						email.attach(attachment);
						
						// Se foi informado o a lista do resultado
						
						if(this.teste){
							email.addBcc("brancao.86@gmail.com", "Brancao");
							email.addBcc("parralego@yahoo.com.br", "Parralego");
							email.addBcc("dti@avmpmpr.org.br", "DTI");
							idexList = sorteioResultadoList.size();	// Para sair do laco principal
							email.send();
						}
						else{
							for(; idexList < sorteioResultadoList.size(); idexList++){
								// Se o email est� cadastrado
								if(sorteioResultadoList.get(idexList).getInscricao().getUser().getEmail() != null && !sorteioResultadoList.get(idexList).getInscricao().getUser().getEmail().isEmpty()){
									email.addBcc(sorteioResultadoList.get(idexList).getInscricao().getUser().getEmail(), sorteioResultadoList.get(idexList).getInscricao().getUser().getName());
								}
								
								//Quando chegar no numero maximo de destinatario ou for o ultimo registro entao envia o email
								if(idexList != 0 && idexList % this.numMaxDestinatario == 0 || idexList == (sorteioResultadoList.size()-1)){
									// send the email  
									email.send();
									idexList++;
									break;	// Para voltar para while
								}
							}
						}
					}
				}			  
        	}
        } catch (EmailException e) {  
        	e.printStackTrace();
        	return false;
        }
		return true;
	}
	
	public boolean sendHtmlEmailWithAnexo(String assunto, String texto, String nomeArquivoAnexo, User user){
		if(!getConfig())
			return false;
		
		
		File f = new File(nomeArquivoAnexo);
		
		
		EmailAttachment attachment = new EmailAttachment();  
        attachment.setPath(f.getPath()); 									// Obtem o caminho do arquivo  
        attachment.setName(f.getName()); 									// Obtem o nome do arquivo
        attachment.setDescription(prop.getProperty("emailDescArqAnexo"));	// Como vai estar escrino o nome do arquivo em anexo
        attachment.setDisposition(EmailAttachment.ATTACHMENT);  
        
        try {
        	// Se foi informado o usuario
			if(user != null && user.getEmail() != null && !user.getEmail().isEmpty()){
				// Create the email message  
	        	MultiPartEmail email = new MultiPartEmail();
				email.setHostName(this.hostName);
				email.setSmtpPort(this.smtpPort);
				email.setAuthenticator(new DefaultAuthenticator(this.user, this.senha));
				email.setSSLOnConnect(this.sslConect);
				email.setStartTLSEnabled(this.startTLS);
				email.setDebug(this.debug);
				email.setFrom(this.fromEmail, this.fromNome);
				
				email.setSubject(assunto);
				email.setMsg(texto);
				email.addBcc(user.getEmail(), user.getName());
				
				// add the attachment  
				email.attach(attachment);  
	
				// send the email  
				email.send();
			}
        } catch (EmailException e) {  
        	e.printStackTrace();
        	return false;
        }
		return true;
	}



	public String getHostName() {
		return hostName;
	}



	public void setHostName(String hostName) {
		this.hostName = hostName;
	}



	public int getSmtpPort() {
		return smtpPort;
	}



	public void setSmtpPort(int smtpPort) {
		this.smtpPort = smtpPort;
	}



	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public String getSenha() {
		return senha;
	}



	public void setSenha(String senha) {
		this.senha = senha;
	}



	public String getFromNome() {
		return fromNome;
	}



	public void setFromNome(String fromNome) {
		this.fromNome = fromNome;
	}



	public String getFromEmail() {
		return fromEmail;
	}



	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}



	public String getToNome() {
		return toNome;
	}



	public void setToNome(String toNome) {
		this.toNome = toNome;
	}



	public String getToEmail() {
		return toEmail;
	}



	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}



	public String getAssunto() {
		return assunto;
	}



	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}



	public String getTexto() {
		return texto;
	}



	public void setTexto(String texto) {
		this.texto = texto;
	}



	public boolean isSslConect() {
		return sslConect;
	}



	public void setSslConect(boolean sslConect) {
		this.sslConect = sslConect;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getMsg1() {
		return msg1;
	}

	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}

	public String getAssinaturaHtml() {
		return assinaturaHtml;
	}

	public void setAssinaturaHtml(String assinaturaHtml) {
		this.assinaturaHtml = assinaturaHtml;
	}

	public String getDescLink() {
		return descLink;
	}

	public void setDescLink(String descLink) {
		this.descLink = descLink;
	}

	public boolean isTeste() {
		return teste;
	}

	public void setTeste(boolean teste) {
		this.teste = teste;
	}

	public int getNumMaxDestinatario() {
		return numMaxDestinatario;
	}

	public void setNumMaxDestinatario(int numMaxDestinatario) {
		this.numMaxDestinatario = numMaxDestinatario;
	}

	public boolean isUsaAssinatura() {
		return usaAssinatura;
	}

	public void setUsaAssinatura(boolean usaAssinatura) {
		this.usaAssinatura = usaAssinatura;
	}
	
	

}
