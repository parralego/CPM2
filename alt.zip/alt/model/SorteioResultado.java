package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.SorteioResultadoStatus;

@Table (name = "SORTEIO_RESULTADO")
@Entity
@NamedQueries({
		@NamedQuery(name = "SorteioResultado.findSorteioResultadoBySorteio"		, query = "SELECT R FROM SorteioResultado R inner join fetch R.inscricao as I inner join fetch I.sorteio as S WHERE S.id= :sorteioId order by ordem"	),
		@NamedQuery(name = "SorteioResultado.findSorteioResultadoByUnidade"		, query = "SELECT R FROM SorteioResultado R inner join fetch R.inscricao as I inner join fetch I.sorteio as S inner join fetch S.unidade as U WHERE U.id= :unidadeId"	),
		@NamedQuery(name = "SorteioResultado.findSorteioResultadoByUser"		, query = "SELECT R FROM SorteioResultado R inner join fetch R.inscricao as I inner join fetch I.user as U WHERE U.id = :userId"						)})

public class SorteioResultado implements Serializable{
	private static final long serialVersionUID = 1L;
	public static final String FIND_SORTEIORESUTLADO_BY_SORTEIO 	= "SorteioResultado.findSorteioResultadoBySorteio";
	public static final String FIND_SORTEIORESUTLADO_BY_UNIDADE 	= "SorteioResultado.findSorteioResultadoByUnidade";
	public static final String FIND_SORTEIORESUTLADO_BY_USER 		= "SorteioResultado.findSorteioResultadoByUser";
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="inscricao_id")
	private Inscricao 		inscricao;
	
	@ManyToOne
	@JoinColumn(name="sorteio_quarto_id")
	private SorteioQuarto	sorteioQuarto;
	
	@Enumerated(EnumType.STRING)
	private SorteioResultadoStatus status;
	
	private int 	ordem;
	private int 	motivoCancel;
	private String 	obsCancel;
	private String 	obs;

	
	@ManyToOne
	@JoinColumn(name="user_sessao_id")
	private User userSessao; 
	
	private Date dtCad;
	private Date dtAlt;
	
	
	public Inscricao getInscricao() {
		return inscricao;
	}
	public void setInscricao(Inscricao inscricao) {
		this.inscricao = inscricao;
	}
	public SorteioQuarto getSorteioQuarto() {
		return sorteioQuarto;
	}
	public void setSorteioQuarto(SorteioQuarto sorteioQuarto) {
		this.sorteioQuarto = sorteioQuarto;
	}
	public SorteioResultadoStatus getStatus() {
		return status;
	}
	public void setStatus(SorteioResultadoStatus status) {
		this.status = status;
	}
	public int getOrdem() {
		return ordem;
	}
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}
	public int getMotivoCancel() {
		return motivoCancel;
	}
	public void setMotivoCancel(int motivoCancel) {
		this.motivoCancel = motivoCancel;
	}
	public String getObsCancel() {
		return obsCancel;
	}
	public void setObsCancel(String obsCancel) {
		this.obsCancel = obsCancel;
	}
	
	public User getUserSessao() {
		return userSessao;
	}
	public void setUserSessao(User userSessao) {
		this.userSessao = userSessao;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getObs() {
		return obs;
	}
	public void setObs(String obs) {
		this.obs = obs;
	}
}
