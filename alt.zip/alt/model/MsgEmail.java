package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table (name = "MSG_EMAIL")
@Entity
public class MsgEmail implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public 	static final int  MSG_EMAIL_CARTEIRINHA	= 1;
	public 	static final int  MSG_AVISO_SORTEADO	= 2;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String descricao;
	private String assunto;
	private String texto;
	
	@ManyToOne
	@JoinColumn(name="user_sessao_id")
	private User userSessao; 
	private Date dtCad;
	private Date dtAlt;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getAssunto() {
		return assunto;
	}
	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public User getUserSessao() {
		return userSessao;
	}
	public void setUserSessao(User userSessao) {
		this.userSessao = userSessao;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
}	
