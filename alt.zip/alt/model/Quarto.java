package com.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.QuartoStatus;

@Entity
@Table(name = "QUARTO")
@NamedQuery(name = "Quarto.findQuartoByUnidade"	, query = "SELECT Q FROM Quarto Q left join fetch Q.unidade as U WHERE U.id= :unidadeId")
public class Quarto implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	public static final String FIND_QUARTO_BY_UNIDADE 	= "Quarto.findQuartoByUnidade";
	public static final int   QUARTO_LIVRE = 99;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String bloco;
	private String nome;
	
	private String andar;
	private int    qtdeOcupacao;
	
	@Enumerated(EnumType.STRING)
	private QuartoStatus status;
	
	private String obs;
	
	@ManyToOne
	private Unidade unidade;
	
	@ManyToOne 
	@JoinColumn(name="tipo_quarto_id")
	private TipoQuarto tipoQuarto;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBloco() {
		return bloco;
	}

	public void setBloco(String bloco) {
		this.bloco = bloco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAndar() {
		return andar;
	}

	public void setAndar(String andar) {
		this.andar = andar;
	}

	public int getQtdeOcupacao() {
		return qtdeOcupacao;
	}

	public void setQtdeOcupacao(int qtdeOcupacao) {
		this.qtdeOcupacao = qtdeOcupacao;
	}

	public QuartoStatus getStatus() {
		return status;
	}

	public void setStatus(QuartoStatus status) {
		this.status = status;
	}

	public Unidade getUnidade() {
		return unidade;
	}

	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public TipoQuarto getTipoQuarto() {
		return tipoQuarto;
	}

	public void setTipoQuarto(TipoQuarto tipoQuarto) {
		this.tipoQuarto = tipoQuarto;
	}

	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}
}
