package com.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.PostoStatus;
import com.defines.TipoFone;

@Entity
@Table(name = "UNIDADE")
@NamedQuery(name = "Unidade.findUnidadeByIdWithTipoUser", query = "select p from Unidade p left join fetch p.tipoUsuarios where p.id = :unidadeId")
public class Unidade implements Serializable {
	
	private static final long serialVersionUID = 1L;
	public static final String FIND_UNIDADE_BY_ID_WITH_TIPO_USERS = "Unidade.findUnidadeByIdWithTipoUser";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String nome;
	private String email;
	
	@Enumerated(EnumType.STRING)
	private PostoStatus status;
	
	@Enumerated(EnumType.STRING)
	private TipoFone tipoFone1;
	
	private String numFone1;
	
	@Enumerated(EnumType.STRING)
	private TipoFone tipoFone2;
	
	private String numFone2;
	
	private String codigoPostal;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String municipio;
	private String uf;  
	
	
	
	@ManyToMany
    @JoinTable(name="join_unidade_tipo_user", joinColumns=
    {@JoinColumn(name="unidade_id")}, inverseJoinColumns=
      {@JoinColumn(name="tipo_user_id")})
	private List<TipoUser> tipoUsuarios;
	
	
	@Override
	public int hashCode() {
		return getId();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof User) {
			Unidade unidade = (Unidade) obj;
			return unidade.getId() == id;
		}

		return false;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<TipoUser> getTipoUsuarios() {
		return tipoUsuarios;
	}

	public void setTipoUsuarios(List<TipoUser> tipoUsuarios) {
		this.tipoUsuarios = tipoUsuarios;
	}

	public PostoStatus getStatus() {
		return status;
	}

	public void setStatus(PostoStatus status) {
		this.status = status;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public TipoFone getTipoFone1() {
		return tipoFone1;
	}

	public void setTipoFone1(TipoFone tipoFone1) {
		this.tipoFone1 = tipoFone1;
	}

	public String getNumFone1() {
		return numFone1;
	}

	public void setNumFone1(String numFone1) {
		this.numFone1 = numFone1;
	}

	public TipoFone getTipoFone2() {
		return tipoFone2;
	}

	public void setTipoFone2(TipoFone tipoFone2) {
		this.tipoFone2 = tipoFone2;
	}

	public String getNumFone2() {
		return numFone2;
	}

	public void setNumFone2(String numFone2) {
		this.numFone2 = numFone2;
	}
	
	
	
}
