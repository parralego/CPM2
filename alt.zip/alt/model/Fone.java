package com.model;

import java.io.Serializable;

//@Table (name = "FONE")
//@Entity
public class Fone implements Serializable {
	private static final long serialVersionUID = 1L;

//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private int cod_pais;
	private int cod_area;
	private int numero;
	
//	@ManyToOne
//	private FoneTipo tipo;
	
	public Fone (int cod_pais, int cod_area, int numero){
		this.cod_pais	= cod_pais;
		this.cod_area	= cod_area;
		this.numero		= numero;
	}
	
	public String getAsString() {
        return "" + cod_pais + " (" + cod_area + ") " + numero ;
            
    }
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCod_pais() {
		return cod_pais;
	}

	public void setCod_pais(int cod_pais) {
		this.cod_pais = cod_pais;
	}

	public int getCod_area() {
		return cod_area;
	}

	public void setCod_area(int cod_area) {
		this.cod_area = cod_area;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	

//	public FoneTipo getTipo() {
//		return tipo;
//	}
//
//	public void setTipo(FoneTipo tipo) {
//		this.tipo = tipo;
//	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	} 
	
	
}