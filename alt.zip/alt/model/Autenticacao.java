package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.AutenticacaoStatus;
import com.util.Tools;

@Table (name = "AUTENTICACAO")
@Entity
@NamedQuery(name = "Autenticacao.findByCodigo", query = "select A from Autenticacao A left join fetch A.user as U WHERE A.codigo = :codigo AND U.cpf = :cpf")
public class Autenticacao implements Serializable {
		private static final long serialVersionUID = 1L;
		public static final String FIND_AUTENTICACAO_BY_CODIGO = "Autenticacao.findByCodigo";
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int id;
		
		private String codigo;
		private Date dtSolicitacao;
		
		@Enumerated(EnumType.STRING)
		private AutenticacaoStatus status;
		
		@ManyToOne
		@JoinColumn(name="user_id")
		private User user;
		
		public String gerarCodigoAcesso(){
			Tools tools = new Tools();
			return tools.convertLongToString(tools.getRandomLong(1000000, 1000000000));
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getCodigo() {
			return codigo;
		}

		public void setCodigo(String codigo) {
			this.codigo = codigo;
		}

		public Date getDtSolicitacao() {
			return dtSolicitacao;
		}

		public void setDtSolicitacao(Date dtSolicitacao) {
			this.dtSolicitacao = dtSolicitacao;
		}

		public AutenticacaoStatus getStatus() {
			return status;
		}

		public void setStatus(AutenticacaoStatus status) {
			this.status = status;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		} 
		
		
		

}
