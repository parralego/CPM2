package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.DefaultStatus;
import com.defines.Sexo;

@Entity
@Table(name = "DEPENDENTE")
@NamedQuery(name = "Dedependente.findDependenteByUser"	, query = "SELECT D FROM Dependente D left join fetch D.user as U WHERE U.id= :userId")
public class Dependente implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	public static final String FIND_DEPENDENTE_BY_USER 	= "Dedependente.findDependenteByUser";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String nome;
	private Date   dtNascimento;
	private String rg;
	private String cpf;
	
	@Enumerated(EnumType.STRING)
	private Sexo  sexo;
	
	@ManyToOne 
	@JoinColumn(name="user_id")
	private User user;
	
	@ManyToOne 
	@JoinColumn(name="parentesco_id")
	private Parentesco parentesco ;

	@Enumerated(EnumType.STRING)
	private DefaultStatus status;
	
	private Date   dtCad;
	private Date   dtAlt;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getDtNascimento() {
		return dtNascimento;
	}
	public void setDtNascimento(Date dtNascimento) {
		this.dtNascimento = dtNascimento;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Parentesco getParentesco() {
		return parentesco;
	}
	public void setParentesco(Parentesco parentesco) {
		this.parentesco = parentesco;
	}
	public DefaultStatus getStatus() {
		return status;
	}
	public void setStatus(DefaultStatus status) {
		this.status = status;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
}
