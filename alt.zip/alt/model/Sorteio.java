package com.model;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.defines.SorteioStatus;
import com.util.Tools;


@Table (name = "SORTEIO")
@Entity
@NamedQueries({
	@NamedQuery(name = "Sorteio.findSorteioByTipoUser", query = "select p from Sorteio p left join fetch p.tipoUsers as tu where tu.id = :tipoUserId order by p.id" ),
	@NamedQuery(name = "Sorteio.findSorteioByUnidade" , query = "SELECT S FROM Sorteio S inner join fetch S.unidade as U WHERE U.id = :unidadeId"					)})
public class Sorteio implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String FIND_SORTEIO_BY_TIPO_USER = "Sorteio.findSorteioByTipoUser";
	public static final String FIND_SORTEIO_BY_UNIDADE = "Sorteio.findSorteioByUnidade";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String descricao;
	private String img;
	private int numDiarias;
	private String estadia;
	private Date dtSorteio;
	private Date dtInicioInscricao;
	private Date dtFinalInscricao;
	private Date dtInicioPagamento;
	private Date dtFinalPagamento;
	private Date dtInicioSuplente;
	private Date dtFinalSumplente;
	private int qtdMaxInscricao;
	
	@Enumerated(EnumType.STRING)
	private SorteioStatus status;
	
	@ManyToOne
	@JoinColumn(name="unidade_id")
	private Unidade unidade;
	
	@OneToMany(mappedBy = "sorteio", targetEntity = Estadia.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Estadia> estadias; 
	
	@OneToMany(mappedBy = "sorteio", targetEntity = NumSort.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<NumSort> numerosSorteados;
	
	@ManyToMany(
	        targetEntity=TipoUser.class,
	        cascade={CascadeType.PERSIST, CascadeType.MERGE}
    )
    @JoinTable(
        name="JOIN_SORTEIO_TIPO_USER",
        joinColumns=@JoinColumn(name="sorteio_id"),
        inverseJoinColumns=@JoinColumn(name="tipo_user_id")
    )
	private List<TipoUser> tipoUsers;
	
	public Sorteio(){
	}
	
	public Sorteio(int id, String desc, String img, int numDiarias, int qtdMaxInscricao, List<Estadia> estadias, String estadia,  String dtSorteio, String dtInicioPagamento, String dtFinalPagamento, String dtInicioSuplente, String dtFinalSuplente) throws ParseException{
		this.id = id;
		this.descricao = desc;
		this.img=img;
		this.numDiarias=numDiarias;
		this.estadia=estadia;
		this.qtdMaxInscricao = qtdMaxInscricao;
		this.estadias = estadias;
		
		SimpleDateFormat sdf1= new SimpleDateFormat("dd/MM/yyyy");
		this.dtSorteio = sdf1.parse(dtSorteio);
		this.dtInicioPagamento = sdf1.parse(dtInicioPagamento);
		this.dtFinalPagamento = sdf1.parse(dtFinalPagamento);
		this.dtInicioSuplente = sdf1.parse(dtInicioSuplente);
		this.dtFinalSumplente = sdf1.parse(dtFinalSuplente);
	}
	
	public String getPeriodoPagamento(){
		Tools tools = new Tools();
		
		return tools.convertDateToString(this.dtInicioPagamento, "dd/MM") + " a " + tools.convertDateToString(this.dtFinalPagamento, "dd/MM");
	}
	
	public String getPeriodoSuplente(){
		SimpleDateFormat sdf1= new SimpleDateFormat("dd/MM");
		return sdf1.format(this.dtInicioSuplente) + " a " + sdf1.format(this.dtFinalSumplente);
	}
	
	public String getPeriodoEstadias(){
		Tools tools = new Tools();
		String sBuffer = new String();
		
		for(Estadia estadia : this.estadias){
			sBuffer += sBuffer = "(" + tools.convertDateToString(estadia.getDtInicio(), "dd/MM") + " a " +
					          		   tools.convertDateToString(estadia.getDtFinal() , "dd/MM") + ") "; 
		}
		
		return sBuffer;
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getNumDiarias() {
		return numDiarias;
	}

	public void setNumDiarias(int numDiarias) {
		this.numDiarias = numDiarias;
	}

	public String getEstadia() {
		return estadia;
	}

	public void setEstadia(String estadia) {
		this.estadia = estadia;
	}

	public Date getDtSorteio() {
		return dtSorteio;
	}

	public void setDtSorteio(Date dtSorteio) {
		this.dtSorteio = dtSorteio;
	}

	public Date getDtInicioPagamento() {
		return dtInicioPagamento;
	}

	public void setDtInicioPagamento(Date dtInicioPagamento) {
		this.dtInicioPagamento = dtInicioPagamento;
	}

	public Date getDtFinalPagamento() {
		return dtFinalPagamento;
	}

	public void setDtFinalPagamento(Date dtFinalPagamento) {
		this.dtFinalPagamento = dtFinalPagamento;
	}

	public Date getDtInicioSuplente() {
		return dtInicioSuplente;
	}

	public void setDtInicioSuplente(Date dtInicioSuplente) {
		this.dtInicioSuplente = dtInicioSuplente;
	}

	public Date getDtFinalSumplente() {
		return dtFinalSumplente;
	}

	public void setDtFinalSumplente(Date dtFinalSumplente) {
		this.dtFinalSumplente = dtFinalSumplente;
	}

	public int getQtdMaxInscricao() {
		return qtdMaxInscricao;
	}

	public void setQtdMaxInscricao(int qtdMaxInscricao) {
		this.qtdMaxInscricao = qtdMaxInscricao;
	}

	public List<Estadia> getEstadias() {
		return estadias;
	}

	public void setEstadias(List<Estadia> estadias) {
		this.estadias = estadias;
	}

	public Date getDtInicioInscricao() {
		return dtInicioInscricao;
	}

	public void setDtInicioInscricao(Date dtInicioInscricao) {
		this.dtInicioInscricao = dtInicioInscricao;
	}

	public Date getDtFinalInscricao() {
		return dtFinalInscricao;
	}

	public void setDtFinalInscricao(Date dtFinalInscricao) {
		this.dtFinalInscricao = dtFinalInscricao;
	}

	public List<TipoUser> getTipoUsers() {
		return tipoUsers;
	}

	public void setTipoUsers(List<TipoUser> tipoUsers) {
		this.tipoUsers = tipoUsers;
	}

	public Unidade getUnidade() {
		return unidade;
	}

	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public SorteioStatus getStatus() {
		return status;
	}

	public void setStatus(SorteioStatus status) {
		this.status = status;
	}

	public List<NumSort> getNumerosSorteados() {
		return numerosSorteados;
	}

	public void setNumerosSorteados(List<NumSort> numerosSorteados) {
		this.numerosSorteados = numerosSorteados;
	}
	
	
}
