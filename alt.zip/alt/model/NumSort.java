package com.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.PostoStatus;

@Table (name = "NUMEROS_SORTEADOS")
@Entity
@NamedQuery(name = "NumSort.findNumSortBySorteio"	, query = "SELECT N FROM NumSort N left join fetch N.sorteio as S WHERE S.id= :sorteioId")
public class NumSort implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final String FIND_NUMSORT_BY_SORTEIO 	= "NumSort.findNumSortBySorteio";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	
	@ManyToOne
	@JoinColumn(name="sorteio_id")
	private Sorteio sorteio; 
	
	private int 	ordem;
	
	private int 	numero;
	
	@Enumerated(EnumType.STRING)
	private PostoStatus status;
	
	public NumSort(){
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public int getOrdem() {
		return ordem;
	}

	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public PostoStatus getStatus() {
		return status;
	}

	public void setStatus(PostoStatus status) {
		this.status = status;
	}
	
	
}
