package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.Sexo;
import com.defines.StatusDefault;
import com.defines.TipoHospede;

@Table (name = "SORTEIO_HOSPEDE")
@Entity
@NamedQueries({
		@NamedQuery(name = "SorteioHospede.findSorteioHospedeBySorteioResultado", query = "SELECT H FROM SorteioHospede H inner join fetch H.sorteioResultado as R WHERE R.id= :sorteioId"),
		@NamedQuery(name = "SorteioHospede.findSorteioHospedeByUser"			, query = "SELECT H FROM SorteioHospede H inner join fetch H.sorteioResultado as R inner join fetch R.inscricao as I inner join fetch I.user as U WHERE U.id = :userId")})

public class SorteioHospede implements Serializable{
	private static final long serialVersionUID = 1L;
	public static final String FIND_SORTEIO_HOSPEDE_BY_SORTEIO_RESULTADO= "SorteioHospede.findSorteioHospedeBySorteioResultado";
	public static final String FIND_SORTEIO_HOSPEDE_BY_USER 			= "SorteioHospede.findSorteioHospedeByUser";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="sorteio_resultado_id")
	private SorteioResultado	sorteioResultado;
	
	
	private String 	nome;
	private String  rg;
	private String  cpf;
	private Date 	dtNascimento;
	
	@Enumerated(EnumType.STRING)
	private Sexo  	sexo;
	
	@Enumerated(EnumType.STRING)
	private TipoHospede tipo;
	
	@Enumerated(EnumType.STRING)
	private StatusDefault status;
	
	private Date dtCad;
	private Date dtAlt;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public SorteioResultado getSorteioResultado() {
		return sorteioResultado;
	}
	public void setSorteioResultado(SorteioResultado sorteioResultado) {
		this.sorteioResultado = sorteioResultado;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Date getDtNascimento() {
		return dtNascimento;
	}
	public void setDtNascimento(Date dtNascimento) {
		this.dtNascimento = dtNascimento;
	}
	public TipoHospede getTipo() {
		return tipo;
	}
	public void setTipo(TipoHospede tipo) {
		this.tipo = tipo;
	}
	public StatusDefault getStatus() {
		return status;
	}
	public void setStatus(StatusDefault status) {
		this.status = status;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}
	
	
}
