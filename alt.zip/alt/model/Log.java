package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.defines.TipoLog;

@Table (name = "LOG")
@Entity
public class Log implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="user_sessao_id")
	private User userSessao; 
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user; 
	
	@Enumerated(EnumType.STRING)
	private TipoLog	tipoLog;
	
	private String obs;
	private Date dtCad;
	private Date dtAlt;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public User getUserSessao() {
		return userSessao;
	}
	public void setUserSessao(User userSessao) {
		this.userSessao = userSessao;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public String getObs() {
		return obs;
	}
	public void setObs(String obs) {
		this.obs = obs;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
	public TipoLog getTipoLog() {
		return tipoLog;
	}
	public void setTipoLog(TipoLog tipoLog) {
		this.tipoLog = tipoLog;
	}
}
