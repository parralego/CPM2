package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.defines.StatusDefault;

@Table (name = "TEMPORADA")
@Entity
public class Temporada implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String 	descricao;
	private Date 	dtInicio;
	private Date 	dtFinal;
	private int  	qtdDiasEstadia;
	
	@Enumerated(EnumType.STRING)
	private StatusDefault	status;
	
	private Date dtCad;
	private Date dtAlt;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public Date getDtInicio() {
		return dtInicio;
	}
	public void setDtInicio(Date dtInicio) {
		this.dtInicio = dtInicio;
	}
	public Date getDtFinal() {
		return dtFinal;
	}
	public void setDtFinal(Date dtFinal) {
		this.dtFinal = dtFinal;
	}
	public int getQtdDiasEstadia() {
		return qtdDiasEstadia;
	}
	public void setQtdDiasEstadia(int qtdDiasEstadia) {
		this.qtdDiasEstadia = qtdDiasEstadia;
	}
	public StatusDefault getStatus() {
		return status;
	}
	public void setStatus(StatusDefault status) {
		this.status = status;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
}
