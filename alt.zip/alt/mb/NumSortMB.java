package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.defines.PostoStatus;
import com.defines.SorteioStatus;
import com.facade.InscricaoFacade;
import com.facade.NumSortFacade;
import com.facade.SorteioFacade;
import com.model.Agrupamento;
import com.model.Inscricao;
import com.model.NumSort;
import com.model.Sorteio;


@ViewScoped
@ManagedBean
public class NumSortMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<NumSort> numSorts;
	private NumSortFacade numSortFacade;
	
	private Sorteio sorteio;
	private SorteioFacade sorteioFacade;
	
	private List<Inscricao> inscricoes;
	private InscricaoFacade inscricaoFacade;
	
	private List<Agrupamento> agrupInscricoes;
	private int totalInscritos;
	
	private boolean botaoGerarNumeros = true;
	
	
	@PostConstruct
	public void init(){
		this.acao = 1;
	}
	
	
	public void show(Sorteio sorteio){
		reset();
		
		this.sorteio = sorteio;
		buscaInscricoes();
		
		this.numSorts = getNumSortFacade().findNumSortBySorteio(this.sorteio.getId());
		
		if(this.numSorts == null || this.numSorts.isEmpty())
			this.acao = 1;
		else
			this.acao = 3;
	}

	
	public void gerarListaSorteio(){
		if(!this.sorteio.getStatus().equals(SorteioStatus.ENCERRADO)){
			tools.msgAviso("Para gerar os n�meros sorteados o Sorteio deve estar ENCERRADO.");
			return;
		}
		
		numSorts = new ArrayList<NumSort>();  
		
		NumSort numSort = new NumSort();
		
        
		for (int i = 1; i <= this.totalInscritos; i++) {
			numSort.setNumero(i);
			numSorts.add(numSort);
			
			numSort = new NumSort();
        } 
		
        Collections.shuffle(numSorts);
        
        for (int i = 0; i < numSorts.size(); i++) {
        	numSorts.get(i).setOrdem(i);
        	numSorts.get(i).setSorteio(this.sorteio);
        	numSorts.get(i).setStatus(PostoStatus.ATIVO);
        	
        	numSort = numSorts.get(i);
//			System.out.println(numSort.getNumero() + " " +  numSort.getOrdem());
		} 
        botaoGerarNumeros = false;
	}
	
	public void buscaInscricoes(){
		if(this.sorteio == null)
			return;
		
		inscricoes = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		if(inscricoes == null){
			tools.msgAviso("N�o existem inscri��es realizadas para esse per�odo");
			return;
		}
		
		agrupInscricoes = new ArrayList<Agrupamento>();
		int iBuffer;
		
		totalInscritos = inscricoes.size();
		
		while (!inscricoes.isEmpty()){
			// Armazenar o tamnho atual da lista
			iBuffer = inscricoes.size();
			
			
			Agrupamento agrup = new Agrupamento();
			
			// Armazenar o tipo de usuario
			agrup.setDescricao(inscricoes.get(0).getUser().getTipoUser().getTipo());
			
			// Remover todos os registros do tipo de usuario atual
			inscricoes.removeIf(f -> f.getUser().getTipoUser() == (inscricoes.get(0).getUser().getTipoUser()));
			
			// Setar a quantidade de registros encontrados para o tipo de usuario atual (Tamanho da LIsta Inicial - Tamanho da Lista Atual
			agrup.setCount(iBuffer - inscricoes.size());
			
			agrupInscricoes.add(agrup);
		}
		
		
		return;
	}
	
		
	public void salvar(){
		
		if(numSorts == null || numSorts.isEmpty()){
			tools.msgAviso("Favor gerar os n�meros sorteados.");
			keepDialogOpen();
			return ;
		}
		
		// Atualizar sorteio para SORTEADO
		this.sorteio.setStatus(SorteioStatus.SORTEADO);
		this.sorteio.setNumerosSorteados(this.numSorts);
		
		try {
			getNumSortFacade().createNumSortList(this.numSorts);
			System.out.println("Numero  inserida com sucesso");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao inserir autenticaca");
			e.printStackTrace();
			tools.msgErro("ERRO ao inserir os n�meros sorteados.");
			return;
		}
		
		
		try {
			sorteio.setStatus(SorteioStatus.SORTEADO);
			getSorteioFacade().updateSorteio(sorteio);
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar sorteio para sorteado");
			tools.msgAviso("Erro ao atualizar sorteio.");
			e.printStackTrace();
			return;
		}
		
		tools.msgAviso("N�meros sorteados inseridos com sucesso.");
		return;
	}
	

	public boolean createNumSort(NumSort numSort) {
		try {
			getNumSortFacade().createNumSort(numSort);
			System.out.println("Numero  inserida com sucesso");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao inserir autenticaca");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public void reset() {
		numSorts = null;
		botaoGerarNumeros = true;
	}
	
	
	public NumSortFacade getNumSortFacade() {
		if (numSortFacade == null) {
			numSortFacade = new NumSortFacade();
		}

		return numSortFacade;
	}

	public InscricaoFacade getInscricaoFacade() {
		if (inscricaoFacade == null) {
			inscricaoFacade = new InscricaoFacade();
		}

		return inscricaoFacade;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<NumSort> getNumSorts() {
		return numSorts;
	}

	public void setNumSorts(List<NumSort> numSorts) {
		this.numSorts = numSorts;
	}

	public List<Inscricao> getInscricoes() {
		return inscricoes;
	}

	public void setInscricoes(List<Inscricao> inscricoes) {
		this.inscricoes = inscricoes;
	}


	public List<Agrupamento> getAgrupInscricoes() {
		return agrupInscricoes;
	}


	public void setAgrupInscricoes(List<Agrupamento> agrupInscricoes) {
		this.agrupInscricoes = agrupInscricoes;
	}


	public int getTotalInscritos() {
		return totalInscritos;
	}


	public void setTotalInscritos(int totalInscritos) {
		this.totalInscritos = totalInscritos;
	}


	public SorteioFacade getSorteioFacade() {
		if(sorteioFacade == null)
			sorteioFacade = new SorteioFacade();
		
		return sorteioFacade;
	}


	public void setSorteioFacade(SorteioFacade sorteioFacade) {
		this.sorteioFacade = sorteioFacade;
	}


	public boolean isBotaoGerarNumeros() {
		return botaoGerarNumeros;
	}


	public void setBotaoGerarNumeros(boolean botaoGerarNumeros) {
		this.botaoGerarNumeros = botaoGerarNumeros;
	}
	
	
	
}