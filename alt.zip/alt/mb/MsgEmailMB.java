package com.mb;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.facade.MsgEmailFacade;
import com.model.MsgEmail;

@ViewScoped
@ManagedBean
public class MsgEmailMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;


	private MsgEmail 		msgEmail;
	private List<MsgEmail> 	msgEmailList;
	private MsgEmailFacade 	msgEmailFacade;



	public void show(){
		load();
		return;
	}

	public String cadastrar(){
		setAcao(1);
		reset();
		return null;
	}

	public String alterar(MsgEmail msgEmail){
		setMsgEmail(msgEmail);
		setAcao(2);
		return null;
	}

	public String detalhar(MsgEmail msgEmail){
		setMsgEmail(msgEmail);
		setAcao(3);
		return null;
	}

	public boolean validar(){
		if(msgEmail.getDescricao().isEmpty()){
			tools.msgErro("O campo Descri��o � obrigat�rio.");
			return false;
		}
		
		if(msgEmail.getAssunto().isEmpty()){
			tools.msgErro("O campo Assunto � obrigat�rio.");
			return false;
		}
		
		if(msgEmail.getTexto().isEmpty()){
			tools.msgErro("O campo Texto � obrigat�rio.");
			return false;
		}
		return true;
	}


	public void salvar(){
		if(!validar()){
			keepDialogOpen();
			return;
		}	

		try {
			this.msgEmail.setUserSessao(tools.getUserSession());
			
			if(this.acao == 1){	// INCLUSAO
				this.msgEmail.setDtCad(new Date());
				getMsgEmailFacade().create(this.msgEmail);
				System.out.println("Mensagem cadastrada com sucesso");
			}
			else{				// ALTERACAO
				this.msgEmail.setDtAlt(new Date());
				getMsgEmailFacade().update(this.msgEmail);
				System.out.println("Mensagem alterada com sucesso");
			}

			if(acao == 1)
				msgEmailList.add(msgEmail);

			closeDialog();
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao cadastrar a mensagem");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar a mensagem.");
			return;
		}
		return;
	}


	public void delete(MsgEmail msgEmail) {
		if(msgEmail.getId() == MsgEmail.MSG_EMAIL_CARTEIRINHA 				||
		   msgEmail.getId() == MsgEmail.MSG_PADRAO_VALIDACAO_NOVOS_SOCIOS 	||
		   msgEmail.getId() == MsgEmail.MSG_AVISO_SORTEADO 		 			){
			keepDialogOpen();
			tools.msgAviso("N�o � permitido deletar essa mensagem");
			return;
		}
		try {
			getMsgEmailFacade().delete(msgEmail);
			closeDialog();
			tools.msgAviso("Mensagem deletada com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar MsgEmail");
			e.printStackTrace();
		}
	}


	


	public List<MsgEmail> getAll() {
		if (msgEmailList == null) {
			load();
		}

		return msgEmailList;
	}

	private void load() {
		msgEmailList = getMsgEmailFacade().listAll();
	}

	public void reset() {
		msgEmail = new MsgEmail();
	}

	
	//
	// GETs and SETs
	//
	public MsgEmail getMsgEmail() {
		return msgEmail;
	}

	public void setMsgEmail(MsgEmail msgEmail) {
		this.msgEmail = msgEmail;
	}

	public List<MsgEmail> getMsgEmailList() {
		return msgEmailList;
	}

	public void setMsgEmailList(List<MsgEmail> msgEmailList) {
		this.msgEmailList = msgEmailList;
	}

	public MsgEmailFacade getMsgEmailFacade() {
		if(msgEmailFacade == null)
			msgEmailFacade = new MsgEmailFacade();
		return msgEmailFacade;
	}

	public void setMsgEmailFacade(MsgEmailFacade msgEmailFacade) {
		this.msgEmailFacade = msgEmailFacade;
	}
}