package com.mb;

import java.net.MalformedURLException;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.mail.EmailException;

import com.defines.AutenticacaoStatus;
import com.defines.UserStatus;
import com.facade.UserFacade;
import com.model.Autenticacao;
import com.model.User;

@ViewScoped
@ManagedBean
public class LoginMB extends AbstractMB {
	@ManagedProperty(value = UserMB.INJECTION_NAME)
	private UserMB userMB;

	private String cpf;
	private String email;
	private String password;
	private String chaveAcesso;
	private String cpfLink;
	private String tipoLogin;
	private boolean teste = true;
	private boolean loginByEmail;
	
	private User user;
	
	
	@PostConstruct
	public void init(){

		if(teste){
//			cpf="060.222.879-44";
			tipoLogin="senha";
//			cpfLink="060.222.879-44";
//			chaveAcesso = "813971274";
//			chaveAcesso = null;
		}
	}
	
	/****************************************************************************************************
	 * Nome: login()
	 * Descricao: 1 - Logar no sistema via link de acesso com CPF e TOKEN
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public String loginByLink(){

		if(chaveAcesso != null){
			AutenticacaoMB autenticacaoMB = new AutenticacaoMB();
			Autenticacao aut = autenticacaoMB.findByCodigo(cpfLink, chaveAcesso);
			
			if(aut.getStatus().equals(AutenticacaoStatus.ATIVO)){
				if(getUser().getId() == 0){
					UserFacade userFacade = new UserFacade();
					this.user = userFacade.recuperaEmail(cpfLink);
				}
				
				userMB.setUser(this.user);
				
				// AUTENTICA O USUARIO NA SESSAO
				FacesContext context = FacesContext.getCurrentInstance();
				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
				request.getSession().setAttribute("user", this.user);

				if(user.isAdmin())
					return "/pages/protected/index.xhtml";
				else
					return "/pages/protected/indexSocio.xhtml";
			}
			else if(aut.getStatus().equals(AutenticacaoStatus.CANCELADO)){
				tools.msgAviso("Chave de acesso [" + chaveAcesso +"] cancelada.");
				return "";
			}else{
				tools.msgAviso("Chave de acesso [" + chaveAcesso +"] inv�lida.");
				return "";
			}
		}
		return"";
	}
	
	
	/****************************************************************************************************
	 * Nome: login()
	 * Descricao: 1 - Logar no sistema via Usuario e Senha
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public String login() {
		tipoLogin="senha";
		
		if(!validar())
			return null;
		
		UserFacade userFacade = new UserFacade();

		user = userFacade.isValidLogin(cpf, email, password);
		
		if(user != null){
			userMB.setUser(this.user);
			
			// AUTENTICA O USUARIO NA SESSAO
			FacesContext context = FacesContext.getCurrentInstance();
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
			request.getSession().setAttribute("user", user);
			
			if(user.isAdmin())
				return "/pages/protected/index.xhtml";
			else
				return "/pages/protected/indexSocio.xhtml";
		}

//		tools.msgAviso("Dados Incorretos");
		return null;
	}
	
	
	/****************************************************************************************************
	 * Nome: loginByEmail()
	 * Descricao: 1 - Reponsavel por fazer a identificacao do usuario com base no CPF informado
	 *            2 - Gerar token de autenticacao e gravalo na base de dados
	 *            3 - Enviar email com o link comporto pelo token gerado e o CPF informado.
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public void loginByEmail(){
		tipoLogin="email";
		
		if(!validar())
			return;
		
		// Recupera dados do USUARIO
		if(getUserLogin() == null)
			return;
		
		// Verifica se o email digitado � igual o email cadastradao
		if(!user.getEmail().equals(this.email)){
			
			// So permite digitar outro email diferente se o usuario estiver INATIVO
			if(!user.getStatus().equals(UserStatus.INATIVO)){
				tools.msgAviso("O Email informado " + this.email + " � diferente do email cadastrado no sistema " + user.getEmail());
				return ;
			}
		}
		
		// Gerar codigo de autenticaca��o.
		AutenticacaoMB autenticacaoMB = new AutenticacaoMB();
		String codigo = autenticacaoMB.gravarAutenticacao(user);
		
		if(codigo == null){
			tools.msgAviso("Erro ao gerar a autentica��o");
			return ;
		}
		
		
		System.out.println("Codigo de Autenticao gerado:" + codigo);
		
		String msgCodigo = null;
		
		// RECUPERAR PORPRIEDADES PARA ENVIO DE EMAIL
		if(this.email != null){
			try {
				msgCodigo = tools.getUrl() + "?cpf=" + user.getCpf() + "&codigo=" + codigo;
				if(tools.sendHtmlEmail(null, null, user.getName(), this.email, msgCodigo) == false){
					tools.msgAviso("ERRO ao enviar email com o link de acesso!");
					return;
				}
			} catch (MalformedURLException | EmailException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				tools.msgAviso("ERRO ao enviar email com o link de acesso!");
				return;
			}
			
			
			if(user.getStatus().equals(UserStatus.INATIVO)) {
				tools.msgAviso("Identificamos que esse � seu primeiro acesso, voc� receber� um email com um link para atualizar o seu cadastro.");
			}
			
			tools.msgAviso("Email de ACESSO enviado com SUCESSO para o endere�o: " + this.email);
			return;
		}
	}



	/****************************************************************************************************
	 * Nome: lembrarEmail()
	 * Descricao: 1 - Com base no CPF informado, acessar a base de dados e verificar qual o email cadastrado
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public void lembrarEmail(){
		if(getUserLogin() == null)
			return;
		
		if(getUserLogin().getEmail() == null || getUserLogin().getEmail().isEmpty()){
			tools.msgAviso("N�o existe um email cadastrado para seu CPF " + this.cpf + ", favor informar seu email.") ;
			return;
		}
		
		if (!tools.validarEmail(getUserLogin().getEmail())){
			tools.msgAviso("O Email informado no seu cadastro (" + getUserLogin().getEmail() + ") � inv�lido, favor informar um Email v�lido.");
			return;
		}
		
		tools.msgAviso("O email cadastrado para o CPF " + this.cpf + " � " + user.getEmail()) ;
		setEmail(user.getEmail());
		return;
	}
	
	/****************************************************************************************************
	 * Nome: lembrarEmail()
	 * Descricao: 1 - Com base no CPF informado, acessar a base de dados e recuperar a senha cadastrada
	 * 			  2 - Enviar um email com a senha recueprada
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public void lembrarSenha(){
		if(getUserLogin() == null)
			return;
		
		String msgEmail = "Sua senha de acesso ao novo portal da AVM � " + getUser().getPassword();
		
		if(!tools.sendSimpleEmail("Recupera��o de Senha", msgEmail, getUser().getName(), getUser().getEmail(), null))
			return;
		
		tools.msgAviso("Sua senha foi enviada para o email " + user.getEmail()) ;
		return;
	}
	
	/****************************************************************************************************
	 * Nome: lembrarEmail()
	 * Descricao: 1 - Aplicar as regras do controle 
	 * Criacao: Cl�udio Parralego  
	 * Data: 18/07/2016 
	 ****************************************************************************************************/
	public boolean validar(){
		if(!tools.validarCpfCnpj(cpf, "cpf")){
			tools.msgAviso("CPF inv�lido");
			return false;
		}
		
		if(this.tipoLogin.equals("email")){
			if(email.isEmpty()){
				tools.msgAviso("O campo email � obrigat�rio");
				return false;
			}
			
			if (!tools.validarEmail(email)){
				tools.msgAviso("Email inv�lido");
				return false;
			}
		}		
		
		if(this.tipoLogin.equals("senha")){
			if(password.isEmpty()){
				tools.msgAviso("O campo senha � obrigat�rio");
				return false;
			}
		}
		
		return true;
	}
	
	public String showPgInscricao(){
		return "/pages/public/frmUserNovo.xhtml";
	}
	
	
	
	//
	// GETs e SETs
	//
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setUserMB(UserMB userMB) {
		this.userMB = userMB;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	
	public boolean tipoLoginIsSenha(){
		return tipoLogin.equals("senha");
	}
	public boolean tipoLoginIsLink(){
		return tipoLogin.equals("link");
	}


	public String getChaveAcesso() {
		return chaveAcesso;
	}


	public void setChaveAcesso(String chaveAcesso) {
		this.chaveAcesso = chaveAcesso;
	}


	public String getCpfLink() {
		return cpfLink;
	}


	public void setCpfLink(String cpfLink) {
		this.cpfLink = cpfLink;
	}
	public UserFacade getUserFacade (){
		return new UserFacade();
	}

	public boolean isTeste() {
		return teste;
	}

	public void setTeste(boolean teste) {
		this.teste = teste;
	}

	public boolean isLoginByEmail() {
		return loginByEmail;
	}

	public void setLoginByEmail(boolean loginByEmail) {
		this.loginByEmail = loginByEmail;
	}

	public User getUser() {
		if(user == null)
			user = new User();
		
		return user;
	}
	
	public User getUserLogin(){
		if(getUser().getId() == 0 || (this.cpf != null && !getUser().getCpf().equals(this.cpf))){
			if(!tools.validarCpfCnpj(cpf,"cpf")){
				tools.msgAviso("CPF inv�lido");
				return null;
			}
			
			UserFacade userFacade = new UserFacade();
			this.user = userFacade.recuperaEmail(cpf);
			
			if(user == null){
				tools.msgAviso("Usu�rio n�o encontrado");
				return null;
			}
		}
		return user;
	}
}
