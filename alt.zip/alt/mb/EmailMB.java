package com.mb;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.Pattern;

import org.apache.commons.mail.EmailException;

import com.facade.MsgEmailFacade;
import com.model.MsgEmail;
import com.util.Email;

@ViewScoped
@ManagedBean
public class EmailMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String assunto;
	private String texto;
	
	@Pattern(regexp=".+@.+\\.[a-z]+", message ="Email invalido!")
	private String from;
	
	@Pattern(regexp=".+@.+\\.[a-z]+", message ="Email invalido!")
	private String to;
	
	private List<String> toList;
	
	private MsgEmail		msgEmail;
	private MsgEmailFacade	msgEmailFacade;
	
	
	@PostConstruct
	public void init(){
		acao=1;
	}
	
	public void showWithTo(String to){
		acao=1;
		this.to = to;
		this.from = tools.getUserSession().getEmail();
	}
	
	public void showWithTo(String to, int msgPadraoId){
		acao=1;
		this.to = to;
		this.from = tools.getUserSession().getEmail();
		
		this.msgEmail = getMsgEmailFacade().find(msgPadraoId);
	}
	
	public boolean validar(){
		if(this.to.isEmpty()){
			tools.msgAviso("O campo destinat�rio � obrigat�rio");
			return false;
		}
		
		if(this.assunto.isEmpty()){
			tools.msgAviso("O campo assunto � obrigat�rio");
			return false;
		}
		
		if(this.texto.isEmpty()){
			tools.msgAviso("O campo texto � obrigat�rio");
			return false;
		}

		return true;
	}
	
	public void sendEmailHtml(){
		if(!validar()){
			keepDialogOpen();
			return;
		}
			
		Email email = new Email();
		
		try {
			email.sendHtmlEmail(this.assunto, this.texto, this.from, this.to);
			tools.msgAviso("Email enviado com sucesso.");
			reset();
			closeDialog();
		} catch (MalformedURLException e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao enviar email.");
			e.printStackTrace();
		} catch (EmailException e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao enviar email.");
			e.printStackTrace();
		}
	}
	
	public void setMsgPadrao(){
		this.assunto= this.msgEmail.getAssunto();
		this.texto 	= this.msgEmail.getTexto();
	}
	
	public void reset(){
		this.to = "";
		this.texto = "";
		this.assunto = "";
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public List<String> getToList() {
		return toList;
	}

	public void setToList(List<String> toList) {
		this.toList = toList;
	}

	public MsgEmail getMsgEmail() {
		return msgEmail;
	}

	public void setMsgEmail(MsgEmail msgEmail) {
		this.msgEmail = msgEmail;
	}

	public MsgEmailFacade getMsgEmailFacade() {
		if(msgEmailFacade == null)
			msgEmailFacade = new MsgEmailFacade();
		return msgEmailFacade;
	}

	public void setMsgEmailFacade(MsgEmailFacade msgEmailFacade) {
		this.msgEmailFacade = msgEmailFacade;
	}
}