package com.mb;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.Pattern;

import org.apache.commons.mail.EmailException;

import com.util.Email;

@ViewScoped
@ManagedBean
public class EmailMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String assunto;
	private String texto;
	
	@Pattern(regexp=".+@.+\\.[a-z]+", message ="Email invalido!")
	private String from;
	
	@Pattern(regexp=".+@.+\\.[a-z]+", message ="Email invalido!")
	private String to;
	
	private List<String> toList;
	
	
	@PostConstruct
	public void init(){
		acao=1;
	}
	
	public void showWithTo(String to){
		acao=1;
		this.to = to;
		this.from = tools.getUserSession().getEmail();
	}
	
	public void sendEmailHtml(){
		Email email = new Email();
		
		try {
			email.sendHtmlEmail(this.assunto, this.texto, this.from, this.to);
			tools.msgAviso("Email enviado com sucesso.");
			closeDialog();
		} catch (MalformedURLException e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao enviar email.");
			e.printStackTrace();
		} catch (EmailException e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao enviar email.");
			e.printStackTrace();
		}
	}
	
	public void reset(){
		this.to = "";
		this.texto = "";
		this.assunto = "";
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public List<String> getToList() {
		return toList;
	}

	public void setToList(List<String> toList) {
		this.toList = toList;
	}
}