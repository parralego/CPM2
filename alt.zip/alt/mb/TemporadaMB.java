package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.defines.StatusDefault;
import com.facade.TemporadaFacade;
import com.model.Temporada;

@ViewScoped
@ManagedBean
public class TemporadaMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Temporada 		temporada;
	private List<Temporada> temporadaList;
	private TemporadaFacade facade;
	
		
	 @PostConstruct
	 public void init(){
		acao=1;
		getAll();
	}
	public void alterar(Temporada temporada){
		setTemporada(temporada);
		setAcao(2);
		
		return;
	}
	
	public void detalhar(Temporada temporada){
		setTemporada(temporada);
		setAcao(3);
		return;
	}
	
	public boolean validar(){
		if(this.temporada.getDtFinal() != null && tools.comparaData(this.temporada.getDtFinal(), new Date()) < 0){
			keepDialogOpen();
			tools.msgAviso("A data final n�o pode ser uma data passada");
			return false;
		}
		
		return true;
	}
	
	public void salvar(){
		if(!validar())
			return;
		
		if(this.acao == 2)	// Se for modo update
			update();
		else
			create();
	}
	
	public void create() {
		try {
			temporada.setDtCad(new Date());
			getFacade().create(temporada);
			closeDialog();
			tools.msgAviso("Temporada inserida com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir a temporada");
			e.printStackTrace();
		}
	}
	
	public void update() {
		try {
			temporada.setDtAlt(new Date());
			getFacade().update(temporada);
			closeDialog();
			tools.msgAviso("Temporada atualizada com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar o Temporada");
			e.printStackTrace();
		}
	}
	
	public void delete(Temporada temporada) {
		try {
			getFacade().delete(temporada);
			closeDialog();
			tools.msgAviso("Temporada deletada com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar temporada");
			e.printStackTrace();
		}
	}
		
	public List<StatusDefault> completeTextStatus(String query) {
		List<StatusDefault> results = new ArrayList<StatusDefault>();
		StatusDefault[] roleList = StatusDefault.values();
        
        for(int i=0; i < roleList.length; i++){
        	results.add(roleList[i]);
        }
        return results;
    }
	
	
	public List<Temporada> getAll() {
		if (temporadaList == null) {
			load();
		}

		return temporadaList;
	}

	private void load() {
		this.temporadaList = getFacade().listAll();
	}

	public void reset() {
		temporada = new Temporada();
	}
	
	//
	// GETs and SETs
	//
	public Temporada getTemporada() {
		return temporada;
	}
	public void setTemporada(Temporada temporada) {
		this.temporada = temporada;
	}
	public List<Temporada> getTemporadaList() {
		return temporadaList;
	}
	public void setTemporadaList(List<Temporada> temmporadaList) {
		this.temporadaList = temmporadaList;
	}
	public TemporadaFacade getFacade() {
		if (facade == null) {
			facade = new TemporadaFacade();
		}
		return facade;
	}
	public void setFacade(TemporadaFacade facade) {
		this.facade = facade;
	}	
}