package com.mb;

import org.primefaces.context.RequestContext;

import com.util.JSFMessageUtil;
import com.util.Tools;

public class AbstractMB {
	private static final String KEEP_DIALOG_OPENED = "KEEP_DIALOG_OPENED";
	protected static final String FORM_INDEX="/pages/protected/index.xhtml";
	
	protected int acao;
	protected String formCadastro;
	protected String outcomeFrom;
	protected Tools tools;

	public AbstractMB() {
		super();
		getTools();
	}
	
	public String homePage(){
		if(tools.getUserSession().isAdmin())
			return "/pages/protected/index";
		
		return "/pages/protected/indexSocio";
	}

	protected void displayErrorMessageToUser(String message) {
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendErrorMessageToUser(message);
	}
	
	protected void displayInfoMessageToUser(String message) {
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendInfoMessageToUser(message);
	}
	
	protected void closeDialog(){
		getRequestContext().addCallbackParam(KEEP_DIALOG_OPENED, false);
	}
	
	protected void keepDialogOpen(){
		getRequestContext().addCallbackParam(KEEP_DIALOG_OPENED, true);
	}
	
	protected RequestContext getRequestContext(){
		return RequestContext.getCurrentInstance();
	}

	public int getAcao() {
		return acao;
	}

	public void setAcao(int acao) {
		this.acao = acao;
	}
	
	public void reset(){
		
	}
	
	public String cadastrar(){
		this.acao = 1;
		reset();
		return formCadastro;
	}
	
	public String alterar(){
		this.acao = 2;
		return formCadastro;
	}
	
	public String detalhar(){
		this.acao = 3;
		return formCadastro;
	}

	public String getOutcomeFrom() {
		return outcomeFrom;
	}

	public void setOutcomeFrom(String outcomeFrom) {
		this.outcomeFrom = outcomeFrom;
	}

	public Tools getTools() {
		if(tools==null)
			tools= new Tools();
		return tools;
	}

	public void setTools(Tools tools) {
		this.tools = tools;
	}
	
	
	
}