package com.mb;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.defines.InscricaoStatus;
import com.facade.InscricaoFacade;
import com.facade.UserFacade;
import com.model.Inscricao;
import com.model.Sorteio;
import com.model.User;


@ViewScoped
@ManagedBean
public class InscricaoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String  		cpfInscricao;
	
	private Inscricao 		inscricao;
	private List<Inscricao> inscricoes;
	private InscricaoFacade inscricaoFacade;
	
	private User    		user;
	private UserFacade 		userFacade;
	
	@PostConstruct
	public void init(){
		setUser(new User());
		
		// Se for USUARIO PADRAO ENTAO ATRIBUI O USUARIO DA SESSAO PARA O USUARIO DA INSCRICAO
		if(tools.getUserSession().isUser()){
			setUser(tools.getUserSession()); 
			cpfInscricao=getUser().getCpf();
			setAcao(2);
		}
		else{
			setAcao(1);
		}
	}
	
	public void cancelar(Inscricao inscricao){
		if(inscricao == null)
			return;
		
		setInscricao(inscricao);
		
		// Soh deixa cancelar inscricoes ativas
		if(!this.inscricao.getStatus().equals(InscricaoStatus.ATIVO)){
			tools.msgAviso("N�o � poss�vel cancelar essa inscri��o, a mesma ja foi efetivada");
			return;
		}
		
		this.inscricao.setStatus(InscricaoStatus.CANCELADO);
		getInscricao().setUserSessao(tools.getUserSession());
		this.inscricao.setDtAlt(new Date());
		
		try {
			getInscricaoFacade().updateInscricao(this.inscricao);
			tools.msgAviso("Inscri��o cancelada com sucesso.");
			resetInscricao();
		} catch (Exception e) {
			tools.msgAviso("Erro ao cancelar inscri��o.");
			e.printStackTrace();
		}
	}
	
	public List<Inscricao> allByUser(){
		if(getUser() == null || getUser().getId() == 0)
			return null;
		
		List<Inscricao> list = getInscricaoFacade().listAllInscricaoByUser(getUser().getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(InscricaoStatus.CANCELADO));
		
		return list;
	}
	
	public List<Inscricao> allByUser(User user){
		if(user == null)
			return null;
		
		List<Inscricao> list = getInscricaoFacade().listAllInscricaoByUser(user.getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(InscricaoStatus.CANCELADO));
		
		return list;
	}
	
	public void buscarSocio(){
		
		// SE O CPF NAO MUDOU NAO BUSCA NOVAMENTE
		if(getUser().getCpf() == null || !getUser().getCpf().equals(cpfInscricao)){
			user = getUserFacade().findByEmail(cpfInscricao);
		}
	}
	
	
	public void verInscricoes(Sorteio sorteio){
		if(sorteio == null)
			return;
		
		inscricoes = listInscricaoBySorteio(sorteio.getId());
	}
	
	
	
	
	public boolean validar(){
		if(getInscricao().getSorteio() == null){
			displayInfoMessageToUser("O sorteio n�o foi selecionado.");
			return false;
		}
		
		if(getInscricao().getUser() == null){
			displayInfoMessageToUser("O s�cio n�o foi selecionado.");
			return false;
		}
		
		return true;
	}
	
	public String salvar(User user, Sorteio sorteios){
		
		getInscricao().setUser(user);
		getInscricao().setSorteio(sorteios);
		getInscricao().setStatus(InscricaoStatus.ATIVO);
		getInscricao().setUserSessao(tools.getUserSession());
		getInscricao().setDtCad(new Date());
		getInscricao().setDtAlt(new Date());
		
		if(validar())
			createInscricao();
		
		return FORM_INDEX;
	}
	
//	public void 

	public void createInscricao() {
		try {
			getInscricaoFacade().createInscricao(inscricao);
			closeDialog();
			loadInscricoes();
			resetInscricao();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir inscri��o.");
			e.printStackTrace();
		}
	}
	
	public void updateInscricao() {
		try {
			getInscricaoFacade().updateInscricao(inscricao);
			closeDialog();
			loadInscricoes();
			resetInscricao();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar inscri��o.");
			e.printStackTrace();
		}
	}
	
	public void deleteInscricao() {
		try {
			getInscricaoFacade().deleteInscricao(inscricao);
			closeDialog();
			loadInscricoes();
			resetInscricao();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar inscri��o.");
			e.printStackTrace();
		}
	}
	
	public boolean verificaInscricao(User user, int idUnidade){
		inscricoes = allByUser(user);
		
		for(Inscricao insc : inscricoes){
			if(insc.getUser().getId()== user.getId() && insc.getSorteio().getUnidade().getId() == idUnidade)
				return false;
		}
		
		return true;
	}
	
	public List<Inscricao> listInscricaoBySorteio(int sorteioId) {
		List<Inscricao> list;
		
		list = getInscricaoFacade().findInscricaoBySorteio(sorteioId);
		
		if(list.isEmpty())
			return null;
		
		list.removeIf(f -> f.getStatus().equals(InscricaoStatus.CANCELADO) );
		
		return list;
	}

	public List<Inscricao> getAllInscricoes() {
		if (inscricoes == null) {
			loadInscricoes();
		}

		return inscricoes;
	}

	private void loadInscricoes() {
		inscricoes = getInscricaoFacade().listAll();
	}

	public void resetInscricao() {
		inscricao = new Inscricao();
	}

	public String getCpfInscricao() {
		return cpfInscricao;
	}

	public void setCpfInscricao(String cpfInscricao) {
		this.cpfInscricao = cpfInscricao;
	}

	public User getUser() {
		if(user == null)
			user = new User();
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserFacade getUserFacade() {
		if (userFacade == null) {
			userFacade = new UserFacade();
		}
		return userFacade;
	}

	public void setUserFacade(UserFacade userFacade) {
		this.userFacade = userFacade;
	}
	
	public InscricaoFacade getInscricaoFacade() {
		if (inscricaoFacade == null) {
			inscricaoFacade = new InscricaoFacade();
		}

		return inscricaoFacade;
	}

	public Inscricao getInscricao() {
		if (inscricao == null) {
			inscricao = new Inscricao();
		}

		return inscricao;
	}

	public void setInscricao(Inscricao inscricao) {
		this.inscricao = inscricao;
	}

	public List<Inscricao> getInscricoes() {
		return inscricoes;
	}

	public void setInscricoes(List<Inscricao> inscricoes) {
		this.inscricoes = inscricoes;
	}	
	
}