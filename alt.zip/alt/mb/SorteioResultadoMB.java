package com.mb;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.mail.EmailException;

import com.dao.Conexao;
import com.defines.InscricaoStatus;
import com.defines.QuartoStatus;
import com.defines.SorteioResultadoStatus;
import com.defines.SorteioStatus;
import com.facade.InscricaoFacade;
import com.facade.MotivoCancelamentoFacade;
import com.facade.MsgEmailFacade;
import com.facade.NumSortFacade;
import com.facade.SorteioFacade;
import com.facade.SorteioQuartoFacade;
import com.facade.SorteioResultadoFacade;
import com.facade.UserFacade;
import com.model.Inscricao;
import com.model.MotivoCancelamento;
import com.model.MsgEmail;
import com.model.NumSort;
import com.model.Quarto;
import com.model.Sorteio;
import com.model.SorteioQuarto;
import com.model.SorteioResultado;
import com.model.TipoQuarto;
import com.model.User;
import com.util.Email;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;


@ViewScoped
@ManagedBean
public class SorteioResultadoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final int  ACAO_CHANGE_QUARTO = 4;
	private static final int  ACAO_CANCELAR = 5;
	
	private String  		cpfSorteioResultado;
	
	private Sorteio					sorteio;
	private SorteioResultado 		sorteioResultado;
	private List<SorteioResultado> 	sorteioResultadoList;
	private SorteioResultadoFacade 	sorteioResutladoFacade;
	
	private SorteioResultado 		sorteioResultadoPrimeiroSuplente;
	
	private List<Inscricao> 		inscricaoList;
	private InscricaoFacade			inscricaoFacade;
	
	private List<NumSort> 			numSortList;
	private NumSortFacade 			numSortFacade;
	
	private User    				user;
	private UserFacade 				userFacade;
	
	private SorteioQuarto 			sorteioQuarto;
	private List<SorteioQuarto> 	sorteioQuartoList;
	private SorteioQuartoFacade		sorteioQuartoFacade;
	
	private MotivoCancelamento 			motivoCancelamento;
	private List<MotivoCancelamento> 	motivoCancelamentoList;
	private MotivoCancelamentoFacade 	motivoCancelamentoFacade;
	
	private String 						nomeArquivoAnexo;
	
	private boolean 					botaoEmailVisible;
	
	@PostConstruct
	public void init(){
		setAcao(1);
		setBotaoEmailVisible(true);
	}
	
	public void show(Sorteio sorteio){
		this.sorteio = sorteio;
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
		
		// Se jah existe resultado cadastrado
		if(sorteioResultadoList != null && !sorteioResultadoList.isEmpty()){
			this.acao = 3;
			return;
		}
			
		this.acao = 1;
		
		// Recuperas as incricoes do sorteio passado por parametro
		inscricaoList = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		if(inscricaoList == null){
			tools.msgAviso("N�o existem inscri��es realizadas para esse per�odo");
			return;
		}
		
		// Recuperas os quartos do sorteio passado por parametro
		this.sorteioQuartoList = getSorteioQuartoFacade().findSorteioQuartoBySorteio(sorteio.getId());
		if(sorteioQuartoList == null || sorteioQuartoList.isEmpty()){
			closeDialog();
			tools.msgErro("Os quartos ainda n�o foram cadastrados para esse sorteio.");
			return;
		}
		
		// Recuperas os numeros sorteados do sorteio passado por parametro
		this.numSortList = getNumSortFacade().findNumSortBySorteio(sorteio.getId());
		if(numSortList == null || numSortList.isEmpty()){
			tools.msgErro("Os n�meros de sorteio ainda n�o foram cadastrados para esse sorteio.");
			return;
		}
		
		
		// Determina o motivo do cancelamento
		if(motivoCancelamentoList == null || motivoCancelamentoList.isEmpty()){
			motivoCancelamentoList = getMotivoCancelamentoFacade().listAll();
		}
		for(int i = 0; i < motivoCancelamentoList.size(); i++){
			if(motivoCancelamentoList.get(i).getId() == 1){	// SOCIO JAH SORTEADO NA MESMA TEMPORADA E NA MESMA UNIDADE
				this.motivoCancelamento = motivoCancelamentoList.get(i); 
				break;
			}
		}
		
		
		sorteioResultadoList = new ArrayList<SorteioResultado>();
		SorteioResultado sorteioResultado;
		
		User userSessao = tools.getUserSession();
		Date dtCad = new Date();
		
		// Percorrrer todos os numeros sorteados do sorteio por ordem de sorteio
		for(int i = 0; i < this.numSortList.size(); i++){
			
			// Percorrrer todas as inscricoes do sorteio
			for(int j = 0; j < this.inscricaoList.size(); j++){
				
				// ACHOU NUMERO SORTEADO
				if(this.inscricaoList.get(j).getNumSort() == this.numSortList.get(i).getNumero()){
					
					// inicializar varivavel do resultado do sorteio
					sorteioResultado = new SorteioResultado();
					sorteioResultado.setInscricao(this.inscricaoList.get(j));
					sorteioResultado.setOrdem(i);
					sorteioResultado.setUserSessao(userSessao);
					sorteioResultado.setDtCad(dtCad);
					sorteioResultado.setDtAlt(dtCad);
					
					sorteioResultado.setStatus(SorteioResultadoStatus.SUPLENTE);
					sorteioResultado.setSorteioQuarto(null);
					
					// Se a inscricao estiver suspensa eh porque o socio jah foi soteado em outro sorteio
					if(this.inscricaoList.get(j).getStatus().equals(InscricaoStatus.SUSPENSO)){
						sorteioResultado.setStatus(SorteioResultadoStatus.CANCELADO);
					}
					else{
						// Procurar um quarto compativel (pelo tipo de quarto)
						for(int x = 0; x < this.sorteioQuartoList.size(); x++){
							if(this.inscricaoList.get(j).getUser().getTipoQuarto().getId() == this.sorteioQuartoList.get(x).getTipoQuarto().getId() ||
							   this.sorteioQuartoList.get(x).getTipoQuarto().getId() == Quarto.QUARTO_LIVRE){
								
								if(!this.sorteioQuartoList.get(x).getStatus().equals(QuartoStatus.ATIVO)){
									System.out.println("Quarto " + this.sorteioQuartoList.get(x).getQuarto().getNome() +" n�o ativo");
									continue;
								}
								
								if(this.sorteioQuartoList.get(x).getTipoQuarto().getId() == Quarto.QUARTO_LIVRE)
									sorteioResultado.setObs("Quarto Livre");
								else
									sorteioResultado.setObs("Quarto Patente");
								
								sorteioResultado.setSorteioQuarto(this.sorteioQuartoList.get(x));
								sorteioResultado.setStatus(SorteioResultadoStatus.SORTEADO);
								
								this.sorteioQuartoList.remove(x);	// Remover o quarto jah alocado da lista de quartos
								break;
							}
						}
					}
					this.inscricaoList.remove(j);	// Remover a inscricao jah alocada da lista de inscricoes
					sorteioResultadoList.add(sorteioResultado);
					break;
				}
			}
		}
	}
	
	public void showConsulta(Sorteio sorteio){
		this.acao = 3;
		this.sorteio = sorteio;
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
	}
	
	public void showConsultaByUser(){
		this.acao = 3;
		
		setUser(new User());
		
		// Se for USUARIO PADRAO ENTAO ATRIBUI O USUARIO DA SESSAO PARA O USUARIO DA INSCRICAO
		if(tools.getUserSession().isUser()){
			setUser(tools.getUserSession()); 
			setAcao(2);
		}
		else{
			setAcao(1);
		}
		
		sorteioResultadoList = getSorteioResultadoFacade().listAllSorteioResultadoByUser(getUser().getId());
	}
	
	public void showChangeQuarto(SorteioResultado sorteioResultado){
		this.acao = ACAO_CHANGE_QUARTO;
		this.sorteioResultado = sorteioResultado;
		
		sorteioQuartoList = listAllQuartoLivre();
	}
	
	public void showCancelar(SorteioResultado sorteioResultado){
		this.acao = ACAO_CANCELAR;
		this.sorteioResultado = sorteioResultado;
		
		for(int i = 0; i < sorteioResultadoList.size(); i++){
			if(sorteioResultadoList.get(i).getStatus().equals(SorteioResultadoStatus.SUPLENTE)){	
				sorteioResultadoPrimeiroSuplente = sorteioResultadoList.get(i);	// QUando achar o primeiro supelnte para o for
				break;
			}
		}
		
		if(sorteioResultadoPrimeiroSuplente == null){
			tools.msgAviso("N�o existe suplentes para esse sorteio.");
			return;
		}
	}
	
	
	public void showCarteirinha(SorteioResultado sorteioResultado){
		this.sorteioResultado = sorteioResultado;
		
		if(sorteioResultado.getInscricao().getUser().getEmail() == null || sorteioResultado.getInscricao().getUser().getEmail().isEmpty())
			setBotaoEmailVisible(false);
		else
			setBotaoEmailVisible(true);
		
		// Recupera a logo pra imprimir na carteirinha
		String s = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "resources/images/" + "logo_avm01.png";
		InputStream is;
		try {
			is = new BufferedInputStream(new FileInputStream(s));
		} catch (FileNotFoundException e) {
			tools.msgErro("Erro ao recuperar logo da carteirinha");
			e.printStackTrace();
			return;
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioResultadoId", sorteioResultado.getId());
		parameters.put("logo", is);
		parameters.put("logo", null);	// Retirar
		
		String nomeRelat = "CarteirinhaColonia"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		this.nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "resources/demo/" 	+ nomeRelat + ".pdf";
		
//		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";

		try {
			JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
			JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
			JasperExportManager.exportReportToPdfFile(printReport, this.nomeArquivoAnexo);
		} catch (JRException e) {
			tools.msgErro("Erro ao gerar as carteirinhas");
			e.printStackTrace();
			return;
		}
	}
	

	
	
	public void salvar(){
		
		if(this.sorteioResultadoList == null || this.sorteioResultadoList.isEmpty()){
			tools.msgAviso("N�o existe resultado de sorteio.");
			return ;
		}
		
		
		// MARCAR TODAS AS INCRICOES DE SOCIOS SORTEADOS COMO CANCELADAS
		List<Inscricao> incricoesComSorteio = new ArrayList<Inscricao>();
		List<Inscricao> incricoesDaUnidade = getInscricaoFacade().listAllInscricaoByUnidade(this.sorteio.getUnidade().getId(), this.sorteio.getId());
		
		if(incricoesDaUnidade != null && !incricoesDaUnidade.isEmpty()){
			for(int i =0; i < sorteioResultadoList.size(); i++){
				// SE O SOCIO JAH FOR SORTEADO
				if(sorteioResultadoList.get(i).getStatus().equals(SorteioResultadoStatus.SORTEADO)){
					for(int j = 0; j < incricoesDaUnidade.size(); j++){
						
						// SE ACHAR UMA INSCCRICAO ATIVA PARA A MESMA UNIDADE ONDE JAH FOI SORTEADO
						if(sorteioResultadoList.get(i).getInscricao().getUser().getId() == incricoesDaUnidade.get(j).getUser().getId() ){
							incricoesDaUnidade.get(j).setStatus(InscricaoStatus.SUSPENSO);
							incricoesComSorteio.add(incricoesDaUnidade.get(j));	// ADICIONA NA LISTA PARA CANCELAR A INSCRICAO
							System.out.println("Inscricao CANCELADA pois o socio j� foi sorteado");
							System.out.println(incricoesDaUnidade.get(j).getId() + "-" + incricoesDaUnidade.get(j).getUser().getCpf() + "-" + incricoesDaUnidade.get(j).getSorteio().getDescricao());
						}
					}
				}
			}
		}
		
		
		
		// CANCELAR RESULTADO DE SORTEIO DE SOCIOS Q ESTAVA SUPLESNTES E FORAM SORTEADOS NO SORTEIO ATUAL
		List<SorteioResultado> sorteioResultadoListUnidadeComSorteio = new ArrayList<SorteioResultado>(); 
		List<SorteioResultado> sorteioResultadoListUnidade 			 = getSorteioResultadoFacade().findSorteioResultadoByUnidade(sorteio.getUnidade().getId());
		
		if(sorteioResultadoListUnidade != null && !sorteioResultadoListUnidade.isEmpty()){
			for(int i =0; i < sorteioResultadoList.size(); i++){
				if(sorteioResultadoList.get(i).getStatus().equals(SorteioResultadoStatus.SORTEADO)){
					for(int j= 0; j < sorteioResultadoListUnidade.size(); j++){
						if(sorteioResultadoList.get(i).getInscricao().getUser().getId() == sorteioResultadoListUnidade.get(j).getInscricao().getUser().getId() ){
							
							// SE FOR SUPLENTE E O SOCIO FOI SORTEADO ENTAO CANCELA A SUPENCIA
							if(sorteioResultadoListUnidade.get(j).getStatus().equals(SorteioResultadoStatus.SUPLENTE)){
								sorteioResultadoListUnidade.get(j).setStatus(SorteioResultadoStatus.CANCELADO);	// MARCA PARA CENCELADO
								sorteioResultadoListUnidade.get(j).setMotivoCancelamento(motivoCancelamento);	// JAH SORTEADO
								sorteioResultadoListUnidade.get(j).setObsCancel("Sorcio ja sorteado " + sorteio.getDescricao());
								sorteioResultadoListUnidadeComSorteio.add(sorteioResultadoListUnidade.get(j));		// ADICIONA NA LISTA PARA CANCELAR A O RESULTADO DO SORTEIO
								
								System.out.println("Inscricao CANCELADA pois o socio j� foi sorteado");
								System.out.println(sorteioResultadoListUnidade.get(j).getId() + "-" + sorteioResultadoListUnidade.get(j).getInscricao().getUser().getCpf() + "-" + sorteioResultadoListUnidade.get(j).getInscricao().getSorteio().getDescricao());
							}
						}
					}
				}
			}
		}
		
		
		// ADICIONAR O RESULTADO DE SORTEIO NA TABELA SORTEIO_RESULTADO
		try {
			getSorteioResultadoFacade().createSorteioResultadoList(this.sorteioResultadoList);
			System.out.println("Resultado do sorteio cadastrado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao cadastrar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// ATUALIZA TODAS AS INCRICOES DO SORTEIO PARA SORTEADO
		inscricaoList = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		for(int i = 0; i < inscricaoList.size(); i++){
			// SE A INSCRICAO ESTIVER SUSPENSA ENTAO NAO ATUALIZA PARA SORTEADO
			if(!inscricaoList.get(i).getStatus().equals(InscricaoStatus.SUSPENSO))
				inscricaoList.get(i).setStatus(InscricaoStatus.SORTEADO);
		}
		
		try {
			getInscricaoFacade().updateInscricaoList(this.inscricaoList);
			System.out.println("Inscricoes atualizadas com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar inscricoes para SORTEADO");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		
		// ATUALIZAR TODAS AS ICRICOES ATIVAS DE SOCIOS JAH SORTEADOS PARA SUSPENSA 
		try {
			getInscricaoFacade().updateInscricaoList(incricoesComSorteio);
			System.out.println("Inscricoes atualizadas com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar inscricoes para SUSPENSA");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// CANCELAR TODAS AS SUPLENCIAS DE SOCIOS SORTEADOS NO SORTEIO ATUAL
		try {
			getSorteioResultadoFacade().updateSorteioResultadoList(sorteioResultadoListUnidadeComSorteio);
			System.out.println("Resultado do sorteio cadastrado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao cadastrar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// ATAULIZAR SORTEIO PARA PROCESSADO
		try {
			SorteioFacade sorteioFacade = new SorteioFacade();
			sorteio.setStatus(SorteioStatus.PROCESSADO);
			sorteioFacade.updateSorteio(sorteio);
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar sorteio para processado");
			tools.msgAviso("Erro ao atualizar sorteio.");
			e.printStackTrace();
			return;
		}
		
		tools.msgAviso("Resultado do sorteio cadastrado com sucesso.");
		
		return;
	}
	
	public void salvarChangeQuarto(){
		if(sorteioQuarto == null || sorteioQuarto.getId() == 0){
			tools.msgAviso("Voc� deve selecionar um quarto.");
			keepDialogOpen();
			return;
		}
		
		
		// Setar novos valores para o quarto ANTIGO
		SorteioQuarto sorteioQuartoOld = new SorteioQuarto();
		sorteioQuartoOld = sorteioResultado.getSorteioQuarto();
		sorteioQuartoOld.setStatus(QuartoStatus.ATIVO);
		sorteioQuartoOld.setTipoQuarto(new TipoQuarto(Quarto.QUARTO_LIVRE, "LIVRE"));
		sorteioQuartoOld.setObs("Quarto Alterado para " + sorteioQuarto.getQuarto().getNome());		
		
		// Setar novos valores para o quarto NOVO
		this.sorteioQuarto.setStatus(QuartoStatus.ATIVO);
		this.sorteioQuarto.setTipoQuarto(new TipoQuarto(Quarto.QUARTO_LIVRE, "LIVRE"));
		this.sorteioQuarto.setObs("Realocado para o antigo quarto" + sorteioQuartoOld.getQuarto().getNome());
		
		this.sorteioResultado.setSorteioQuarto(this.sorteioQuarto);
		this.sorteioResultado.setUserSessao(tools.getUserSession());
		this.sorteioResultado.setDtAlt(new Date());
		
		
		// Criar Lista Para atualizar os quartos
		List<SorteioQuarto> sorteioQuartoUpdate = new ArrayList<SorteioQuarto>();
		sorteioQuartoUpdate.add(sorteioQuartoOld);
		sorteioQuartoUpdate.add(this.sorteioQuarto);
		
		// ATUALIZAR OS QUARTOS (ANTERIOR e NOVO)
		try {
			getSorteioQuartoFacade().updateSorteioQuartoList(sorteioQuartoUpdate);
			System.out.println("salvarChageQuarto - Quartos Atualizado com sucesso");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("salvarChageQuarto - Erro ao atualizar quartos");
			e.printStackTrace();
			tools.msgErro("ERRO ao alterar o quarto.");
			return;
		}
		
		// ALTERAR O QUARTO NA TABELA SORTEIO_RESULTADO
		try {
			getSorteioResultadoFacade().updateSorteioResultado(this.sorteioResultado);
			System.out.println("salvarChageQuarto - Resultado do sorteio alterado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("salvarChageQuarto - Erro ao alterar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao alterar o quarto.");
			return;
		}
		
		tools.msgAviso("Quarto alterado com sucesso.");
	}
	
	
	public void salvarCancelar(){
		if(motivoCancelamento == null || motivoCancelamento.getId() == 0){
			tools.msgAviso("Voc� deve selecionar o motivo do cancelamento.");
			keepDialogOpen();
			return;
		}
		
		if(sorteioResultado.getObsCancel() == null || sorteioResultado.getObsCancel().isEmpty()){
			tools.msgAviso("O campo observa��o � obrigat�rio.");
			keepDialogOpen();
			return;
		}
		
		// Primeiro Passo - Alterar o tipo de quarto para Livre
		this.sorteioQuarto = sorteioResultado.getSorteioQuarto();
		this.sorteioQuarto.setStatus(QuartoStatus.ATIVO);
		this.sorteioQuarto.setTipoQuarto(new TipoQuarto(Quarto.QUARTO_LIVRE, "LIVRE"));
		this.sorteioQuarto.setObs("Realocado para suplente que entou no lugar de " + sorteioResultado.getInscricao().getUser().getName());
		
		// Segundo Passo - Alocar o quarto liberado para o premeiro suplente (APENAS SE EXISTIR SUPENTE)
		if(this.sorteioResultadoPrimeiroSuplente != null){
			this.sorteioResultadoPrimeiroSuplente.setSorteioQuarto(this.sorteioQuarto);
			this.sorteioResultadoPrimeiroSuplente.setStatus(SorteioResultadoStatus.SORTEADO2);
			this.sorteioResultadoPrimeiroSuplente.setObs("Suplente entrou no lugar de " + sorteioResultado.getInscricao().getUser().getName());
			
			this.sorteioResultadoPrimeiroSuplente.setUserSessao(tools.getUserSession());
			this.sorteioResultadoPrimeiroSuplente.setDtAlt(new Date());			
		}
		
		// Terceiro Passo - Cancelar o resultado do registro selecioando para cancelamento
		this.sorteioResultado.setSorteioQuarto(null);
		this.sorteioResultado.setStatus(SorteioResultadoStatus.CANCELADO);
		this.sorteioResultado.setMotivoCancelamento(this.motivoCancelamento);
		this.sorteioResultado.setObs("CANCELADO - Substituido por " + sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getName());
		
		this.sorteioResultado.setUserSessao(tools.getUserSession());
		this.sorteioResultado.setDtAlt(new Date());
		
		
		// ATUALIZAR OS QUARTOS (ANTERIOR e NOVO)
		try {
			getSorteioQuartoFacade().updateSorteioQuarto(sorteioQuarto);
			System.out.println("salvarCancelar - Quartos Atualizado com sucesso");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("salvarCancelar - Erro ao atualizar quartos");
			e.printStackTrace();
			tools.msgErro("ERRO ao cancelar resultado do sorteio.");
			return;
		}
		
		// ALTERAR O QUARTO NA TABELA SORTEIO_RESULTADO
		List<SorteioResultado> sorteioResultadoListUpdate = new ArrayList<SorteioResultado>();
		sorteioResultadoListUpdate.add(sorteioResultado);
		
		if(this.sorteioResultadoPrimeiroSuplente != null)
			sorteioResultadoListUpdate.add(sorteioResultadoPrimeiroSuplente);
			
		try {
			getSorteioResultadoFacade().updateSorteioResultadoList(sorteioResultadoListUpdate);
			System.out.println("salvarCancelar - Resultado do sorteio alterado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("salvarCancelar - Erro ao alterar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao cancelar resultado do sorteio.");
			return;
		}
		
		
		
		// Se o usuario tiver email cadatrado
		if(!this.sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getEmail().isEmpty()){
			Email email = new Email();
			email.setToEmail(this.sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getEmail());
			email.setToNome(this.sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getName());
			email.setAssunto("Aviso de Sorteio para Col�nia de F�rias");
			email.setUsaAssinatura(true);
			

			StringBuffer msg = new StringBuffer();
			
			msg.append("<?xml version='1.0' encoding='UTF-8' ?> ");
			msg.append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' ");
			msg.append("'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd' ");
			msg.append("<html> <body> ");
			
			msg.append("<h3>");
			msg.append("Estimado ").append(this.sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getTipoUser().getTipo()).append(" ").append(this.sorteioResultadoPrimeiroSuplente.getInscricao().getUser().getName()).append("<br>");
			msg.append("Informamos que houve desistencia no sorteio abaixo e o sr/a que estava como suplente agora assumiu a vaga.");
			msg.append("<br><br> ");
			msg.append("Unidade: ").append(this.sorteioResultadoPrimeiroSuplente.getInscricao().getSorteio().getUnidade().getNome()).append("<br>");
			msg.append("Per�odo: ").append(this.sorteioResultadoPrimeiroSuplente.getInscricao().getSorteio().getDescricao()).append("<br>");
			msg.append("Bloco: ").append(this.sorteioResultadoPrimeiroSuplente.getSorteioQuarto().getQuarto().getBloco()).append("<br>");
			msg.append("Andar: ").append(this.sorteioResultadoPrimeiroSuplente.getSorteioQuarto().getQuarto().getAndar()).append("<br>");
			msg.append("Quarto: ").append(this.sorteioResultadoPrimeiroSuplente.getSorteioQuarto().getQuarto().getNome()).append("<br>");
			msg.append("</h3> ");
			
			msg.append("<br><br> ");
			
			msg.append("Favor entrar em contato com a AVM para efetuar o pagamento e garantir sua reserva.");
			
			msg.append("<br><br> ");
			
			msg.append("</html> </body> ");
			
			
			try {
				email.sendHtmlEmail(msg);
				tools.msgAviso("Email de aviso enviado com sucesso.");
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (EmailException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

		
		tools.msgAviso("Resultado do Sorteio Cancelado com sucesso.");
	}
	
	public void enviarEmailResultSorteio(Sorteio sorteio, int tipoEnvio) throws JRException{
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
		
		if(sorteioResultadoList == null){
			tools.msgAviso("N�o existe resultado de sorteio, o email n�o ser� enviado");
			return;
		}
		
		// Remover os cancelados da lista de email
		sorteioResultadoList.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		if(sorteioResultadoList.isEmpty()){
			tools.msgAviso("N�o existe resultado de sorteio, o email n�o ser� enviado");
			return;
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteio.getId());
		
		String nomeRelat = "RelatorioResultadoSorteio"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";
					
		JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
		JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		
		Email email = new Email();
		boolean teste=false;
		 
		if(tipoEnvio == 1) // LISTA DE SORTEADOS
			teste = email.sendEmailAvisoSorteio(nomeArquivoAnexo, sorteioResultadoList, null);
		else if (tipoEnvio == 2) // Usuario logado
			teste = email.sendEmailAvisoSorteio(nomeArquivoAnexo, null, tools.getUserSession());
		
		if(!teste){
			tools.msgErro("ERRO ao enviar email.");
			return;
		}
		
		tools.msgAviso("Email Enviado com sucesso.");
	}
	
	public void enviarEmailCarteirinha(){
		MsgEmailFacade msgEmailFacede = new MsgEmailFacade();
		MsgEmail msgEmail = msgEmailFacede.find(MsgEmail.MSG_EMAIL_CARTEIRINHA);
		
		if(msgEmail == null){
			tools.msgErro("Erro ao recuperar mensagem padrao de email.");
			return;
		}
		
		Email email = new Email();
		 
		if(!email.sendHtmlEmailWithAnexo(msgEmail.getAssunto(), msgEmail.getTexto(), this.nomeArquivoAnexo, getSorteioResultado().getInscricao().getUser())){
			tools.msgErro("ERRO ao enviar email.");
			return;
		}
		
		tools.msgAviso("Email Enviado com sucesso.");
	}
	
	public List<SorteioQuarto> listAllQuartoLivre(){
		if(this.acao != ACAO_CHANGE_QUARTO)
			return null;
		
		if(this.sorteio == null)
			return null;
		
		
		if(this.sorteioQuartoList == null || this.sorteioQuartoList.isEmpty()){
			sorteioQuartoList = getSorteioQuartoFacade().findSorteioQuartoBySorteio(this.sorteio.getId());
		}
		
		if(this.sorteioQuartoList == null || this.sorteioQuartoList.isEmpty()){
			tools.msgAviso("N�o existe quartos cadastrados para esse sorteio.");
			return null;
		}
		
		// So deixar quartos ativos
		sorteioQuartoList.removeIf(p -> !p.getStatus().equals(QuartoStatus.ATIVO));
		
		// Remover os quartos jah alocados
		for(SorteioResultado sorteioResutlado : sorteioResultadoList){
			if(sorteioResutlado.getStatus().equals(SorteioResultadoStatus.SORTEADO) || sorteioResutlado.getStatus().equals(SorteioResultadoStatus.SORTEADO2) )
				sorteioQuartoList.removeIf(p -> p.getId() == sorteioResutlado.getSorteioQuarto().getId());  			
		}
		
		if(sorteioQuartoList == null || sorteioQuartoList.isEmpty()){
			tools.msgAviso("N�o h� quarto livre para esse sorteio");
			return null;
		}
		
		return sorteioQuartoList;
	}
	
	
	
	public List<MotivoCancelamento> completeMotivoCancelamento(String query) {
       List<MotivoCancelamento> results = new ArrayList<MotivoCancelamento>();
       
       if(motivoCancelamentoList == null){
    	   motivoCancelamentoList = getMotivoCancelamentoFacade().listAll();
       }
       
       for (MotivoCancelamento tipoUser : motivoCancelamentoList) {
			if (tipoUser.getDescricao().toLowerCase().contains(query.toLowerCase())) {
				results.add(tipoUser);
			}
		}
        
       return results;
   }
	
	
	public List<SorteioResultado> allProcessados(){
		List<SorteioResultado> list = getSorteioResultadoFacade().listAll();
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public List<SorteioResultado> allByUser(){
		if(getUser() == null || getUser().getId() == 0)
			return null;
		
		List<SorteioResultado> list = getSorteioResultadoFacade().listAllSorteioResultadoByUser(getUser().getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public List<SorteioResultado> allByUser(User user){
		if(user == null)
			return null;
		
		List<SorteioResultado> list = getSorteioResultadoFacade().listAllSorteioResultadoByUser(user.getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public void buscarSocio(){
		
		// SE O CPF NAO MUDOU NAO BUSCA NOVAMENTE
		if(getUser().getCpf() == null || !getUser().getCpf().isEmpty()){
			user = getUserFacade().findByEmail(getUser().getCpf());
		}
		
		sorteioResultadoList = getSorteioResultadoFacade().listAllSorteioResultadoByUser(getUser().getId());
	}
	
	
	public void verInscricoes(Sorteio sorteio){
		if(sorteio == null)
			return;
		
		sorteioResultadoList = listSorteioResultadoBySorteio(sorteio.getId());
	}
	
	public List<SorteioResultado> listSorteioResultadoBySorteio(int sorteioId) {
		List<SorteioResultado> list;
		
		list = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteioId);
		
		if(list.isEmpty())
			return null;
		
		list.removeIf(f -> f.getStatus().equals(SorteioResultadoStatus.CANCELADO) );
		
		return list;
	}

	//
	// GETs e SETs
	//
	public InscricaoFacade getInscricaoFacade(){
		if(this.inscricaoFacade == null) 
			this.inscricaoFacade = new InscricaoFacade();
		
		return this.inscricaoFacade;
	}
	
	public SorteioQuartoFacade getSorteioQuartoFacade() {
		if (sorteioQuartoFacade == null)
			sorteioQuartoFacade = new SorteioQuartoFacade();

		return sorteioQuartoFacade;
	}
	
	public NumSortFacade getNumSortFacade() {
		if(numSortFacade == null)
			numSortFacade = new NumSortFacade();
		
		return numSortFacade;
	}
	
	

	public String getCpfSorteioResultado() {
		return cpfSorteioResultado;
	}

	public void setCpfSorteioResultado(String cpfSorteioResultado) {
		this.cpfSorteioResultado = cpfSorteioResultado;
	}

	public User getUser() {
		if(user == null)
			user = new User();
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserFacade getUserFacade() {
		if (userFacade == null) {
			userFacade = new UserFacade();
		}
		return userFacade;
	}

	public void setUserFacade(UserFacade userFacade) {
		this.userFacade = userFacade;
	}
	
	public SorteioResultadoFacade getSorteioResultadoFacade() {
		if (sorteioResutladoFacade == null) {
			sorteioResutladoFacade = new SorteioResultadoFacade();
		}

		return sorteioResutladoFacade;
	}

	public SorteioResultado getSorteioResultado() {
		if (sorteioResultado == null) {
			sorteioResultado = new SorteioResultado();
		}

		return sorteioResultado;
	}
	
	public MotivoCancelamentoFacade getMotivoCancelamentoFacade() {
		if(motivoCancelamentoFacade == null)
			motivoCancelamentoFacade = new MotivoCancelamentoFacade();
		
		return motivoCancelamentoFacade;
	}

	public void setSorteioResultado(SorteioResultado inscricao) {
		this.sorteioResultado = inscricao;
	}

	public List<SorteioResultado> getInscricoes() {
		return sorteioResultadoList;
	}

	public void setInscricoes(List<SorteioResultado> inscricoes) {
		this.sorteioResultadoList = inscricoes;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<SorteioResultado> getSorteioResultadoList() {
		return sorteioResultadoList;
	}

	public void setSorteioResultadoList(List<SorteioResultado> sorteioResultadoList) {
		this.sorteioResultadoList = sorteioResultadoList;
	}

	public SorteioQuarto getSorteioQuarto() {
		return sorteioQuarto;
	}

	public void setSorteioQuarto(SorteioQuarto sorteioQuarto) {
		this.sorteioQuarto = sorteioQuarto;
	}

	public List<MotivoCancelamento> getMotivoCancelamentoList() {
		return motivoCancelamentoList;
	}

	public void setMotivoCancelamentoList(List<MotivoCancelamento> motivoCancelamentoList) {
		this.motivoCancelamentoList = motivoCancelamentoList;
	}

	public void setMotivoCancelamentoFacade(MotivoCancelamentoFacade motivoCancelamentoFacade) {
		this.motivoCancelamentoFacade = motivoCancelamentoFacade;
	}

	public MotivoCancelamento getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(MotivoCancelamento motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public SorteioResultado getSorteioResultadoPrimeiroSuplente() {
		return sorteioResultadoPrimeiroSuplente;
	}

	public void setSorteioResultadoPrimeiroSuplente(SorteioResultado sorteioResultadoPrimeiroSuplente) {
		this.sorteioResultadoPrimeiroSuplente = sorteioResultadoPrimeiroSuplente;
	}

	public List<SorteioQuarto> getSorteioQuartoList() {
		return sorteioQuartoList;
	}

	public void setSorteioQuartoList(List<SorteioQuarto> sorteioQuartoList) {
		this.sorteioQuartoList = sorteioQuartoList;
	}

	public boolean isBotaoEmailVisible() {
		return botaoEmailVisible;
	}

	public void setBotaoEmailVisible(boolean botaoEmailVisible) {
		this.botaoEmailVisible = botaoEmailVisible;
	}
	
}