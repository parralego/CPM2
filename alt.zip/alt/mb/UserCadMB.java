package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import com.defines.Role;
import com.defines.TipoLog;
import com.defines.UserStatus;
import com.facade.LogFacade;
import com.facade.UserFacade;
import com.model.Log;
import com.model.MsgEmail;
import com.model.User;

@SessionScoped
@ManagedBean(name="userCadMB")
public class UserCadMB extends AbstractMB implements Serializable {
	public static final String INJECTION_NAME = "#{userMB}";
	private static final long serialVersionUID = 1L;
	
	private String password2;

	private User user;
	private List<User> users;
	private List<User> userValidaoList;
	private UserFacade facade;
	
	private CepMB cepMB;
	
	private boolean cpfReadOnly;
	
	private boolean titular;
	
	private String motivRecuHeader;
	private String motivRecuMotivo;
	private int recusaAcao;

	
	 @PostConstruct
	 public void init(){
//		Tools tools = new Tools();
		
//		user = tools.getUserSession();
		setFormCadastro();
		cpfReadOnly=false;
		acao=1;
	}
	
	public UserFacade getFacade() {
		if (facade == null) {
			facade = new UserFacade();
		}

		return facade;
	}
	
	
	public void setFormCadastro(){
		formCadastro = "/pages/protected/defaultUser/frmCadUsuario.xhtml";
	}
	
	
	public String alterar(User user){
		setUser(user);
		setAcao(2);
		
		if(tools.getUserSession().isAdmin())
			cpfReadOnly=false;
		else
			cpfReadOnly=true;
		
		return formCadastro;
	}
	
	public String detalhar(User user){
//		setOutcomeFrom(from);
		setUser(user);
		setAcao(3);
		cpfReadOnly=true;
		return formCadastro;
	}
	
	public boolean validar(){
		if(this.user.getDtAlt() == null && (this.user.getPassword() != null && this.user.getPassword().isEmpty())){
			keepDialogOpen();
			tools.msgAviso("Sua senha n�o se enquadra no padrao de seguran�a, favor cadastar novamente.");
			return false;
		}
		
		if( (this.user.getDtCad() != null && tools.comparaData(this.user.getDtCad(), "20161101", "yyyyMMdd") < 0) ||
			(this.user.getDtAlt() != null && tools.comparaData(this.user.getDtAlt(), "20161101", "yyyyMMdd") < 0) ){
			if(tools.decriptar(this.user.getPassword()).equals(this.password2) == false){
				keepDialogOpen();
				tools.msgAviso("A Senha n�o s�o iguais");
				return false;
			}
		}
		else{
			if(this.user.getPassword().equals(this.password2) == false){
				keepDialogOpen();
				tools.msgAviso("A Senha n�o s�o iguais");
				return false;
			}
		}
		
		
		if( !tools.validarCpfCnpj(getUser().getCpf(), "CPF" ) ){
			return false;
		}
		
		if(!tools.validarEmail(getUser().getEmail())){
			tools.msgAviso("Email inv�lido");
			return false;
		}
		
		if(!getUser().getNumFone1().isEmpty() && getUser().getTipoFone1().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 1 deve ser informado");
			return false;
		}
		
		if(!getUser().getNumFone2().isEmpty() && getUser().getTipoFone2().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 2 deve ser informado");
			return false;
		}
		
		return true;
	}
	
	public void salvar(){
		if(!validar())
			return;
		
		// Seta o usuario pra ATIVO quando o usuario logado for socio
		if(tools.getUserSession().isUser())
			user.setStatus(UserStatus.ATIVO);

		
		if(this.acao == 2)	// Se for modo update
			update();
		else
			create();
	}
	
	public void create() {
		try {
			user.setDtCad(new Date());
			getFacade().create(user);
			closeDialog();
			tools.msgAviso("Usu�rio inserido com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void update() {
		try {
			user.setDtAlt(new Date());
			getFacade().update(user);
			closeDialog();
			tools.msgAviso("Usu�rio atualizado com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void delete(User user) {
		try {
			getFacade().delete(user);
			closeDialog();
			tools.msgAviso("Usu�rio deletado com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar usua�rio");
			e.printStackTrace();
		}
	}
	
	//
	// FUNCOES DA TELA DE VALIDAR NOVOS USUARIO - INICIO
	//
	public List<User> userListValidacao(){
		if(userValidaoList == null){
			List<UserStatus> statusList = new ArrayList<UserStatus>();
			
			statusList.add(UserStatus.VALIDACAO);
			statusList.add(UserStatus.PEDENTE_VALIDACAO);
			statusList.add(UserStatus.CAD_PARCIAL);
			
			userValidaoList = getFacade().listAllByStatus(statusList);
		}
			 
		
		return userValidaoList; 
	}
	
	public boolean tratarValidacao(){
		User user = tools.getUserSession(); 
		if(user.getRole().equals(Role.ADMIN)		|| 
		   user.getRole().equals(Role.CADASTRO) 	||
		   user.getRole().equals(Role.FINANCEIRO) 	)
			return true;
		return false;
	}
	
	public void verSenhaAutorizacao(){
		if(user.getRole().equals(Role.CADASTRO))
			tools.msgDialog("Informa��o Confidencial", "Senha: " + this.user.getSenhaAutDebito());
		else
			tools.msgDialog("Informa��o Confidencial", "A senha foi cadastrada.");
	}
	
	public void aprovarUser(User user){
		user.setStatus(UserStatus.ATIVO);
		
		Log log = new Log();
		
		log.setUserSessao(tools.getUserSession());
		log.setUser(user);
		log.setTipoLog(TipoLog.USER_APROVAR);
		log.setDtCad(new Date());
		log.setObs("Aprovado OK");
		
		
		try {
			getFacade().update(user);
			
			LogFacade logFacade = new LogFacade();
			logFacade.createLog(log);
			
			// Remover usuario processado da lista da tela
			userValidaoList.remove(user);
			
			resetMotivoRecusa();
			
			tools.msgAviso("Usu�rio liberado com sucesso");
		} catch (Exception e) {
			tools.msgErro("Erro ao liberar usua�rio");
			e.printStackTrace();
		}
	}
	
	public void recusarUser(User user){
		this.user = user;
		this.recusaAcao 	= 2;	// RECUSAR
		this.motivRecuHeader= "Recusar S�cio: " + user.getName();
		
	}
	
	public void criarPendenciaUser(User user){
		this.user = user;
		this.recusaAcao 	= 1;	// RECUSAR
		this.motivRecuHeader= "Criar pend�ncia S�cio: " + user.getName();
		
	}
	
	public void recusarOrCriarPendencia(){
		Log log = new Log();
		String msgOk;
		
		if(this.recusaAcao == 1){	// CRIAR PENDENCIA
			user.setStatus(UserStatus.PEDENTE_VALIDACAO);
			log.setTipoLog(TipoLog.USER_PENDENCIA);
			msgOk = "Pend�ncia criada com sucesso!";
		}
		else{
			user.setStatus(UserStatus.RECUSADO);
			log.setTipoLog(TipoLog.USER_RECUSAR);
			msgOk = "Usu�rio recusado com sucesso";
		}
		
		log.setUserSessao(tools.getUserSession());
		log.setUser(user);
		log.setDtCad(new Date());
		log.setObs(this.motivRecuMotivo);
		
		
		try {
			getFacade().update(user);
			
			LogFacade logFacade = new LogFacade();
			logFacade.createLog(log);
			
			tools.msgAviso(msgOk);
		} catch (Exception e) {
			tools.msgErro("Erro ao recusar usua�rio");
			e.printStackTrace();
		}
		
	}
	
	public void resetMotivoRecusa(){
		this.motivRecuMotivo="";
		this.user = new User();
	}
	
	public int getMsgEmailId(){
		return MsgEmail.MSG_PADRAO_VALIDACAO_NOVOS_SOCIOS;
	}
	
	//
	// FUNCOES DA TELA DE VALIDAR NOVOS USUARIO - FINAL
	//

	
	
	public List<Role> completeTextTipoUser(String query) {
		List<Role> results = new ArrayList<Role>();
        Role[] roleList = Role.values();
        
        for(int i=0; i < roleList.length; i++){
        	results.add(roleList[i]);
        }
        return results;
    }
	
	public List<String> completeTextTipoStatus(String query) {
        List<String> results = new ArrayList<String>();
        
        results.add(UserStatus.ATIVO.toString());
        results.add(UserStatus.BLOQUEADO.toString());
        results.add(UserStatus.INATIVO.toString());
        results.add(UserStatus.PENDENTE_ATIVACAO.toString());
        results.add(UserStatus.PENDENTE_ATUALIZACAO.toString());
        results.add(UserStatus.VALIDACAO.toString());
         
        return results;
    }

	
	public void buscaCEP(){
		getCepMB().getCep().setCodigoPostal(this.user.getCodigoPostal());
		cepMB.buscaCEP();
		
		this.user.setLogradouro(cepMB.getCep().getLogradouro());
		this.user.setMunicipio(cepMB.getCep().getMunicipio());
		this.user.setBairro(cepMB.getCep().getBairro());
		this.user.setUf(cepMB.getCep().getUf());
	}

	public List<User> getAll() {
		if (users == null) {
			load();
		}

		return users;
	}

	private void load() {
		users = getFacade().listAll();
	}

	public void reset() {
		user = new User();
	}
	

	public boolean isAdmin() {
		return user.isAdmin();
	}

	public boolean isDefaultUser() {
		return user.isUser();
	}

	public String logOut() {
		getRequest().getSession().invalidate();
		return "/pages/public/login.xhtml";
	}

	private HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public User getUser() {
		if(user == null)
			user = new User();
		
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public boolean isTitular() {
		return titular;
	}

	public void setTitular(boolean titular) {
		this.titular = titular;
	}	
	
	public CepMB getCepMB() {
		if (cepMB == null) {
			cepMB = new CepMB();
		}
		return cepMB;
	}

	public void setCepMB(CepMB cepMB) {
		this.cepMB = cepMB;
	}

	public boolean isCpfReadOnly() {
		return cpfReadOnly;
	}

	public void setCpfReadOnly(boolean cpfReadOnly) {
		this.cpfReadOnly = cpfReadOnly;
	}

	public String getMotivRecuHeader() {
		return motivRecuHeader;
	}

	public void setMotivRecuHeader(String motivRecuHeader) {
		this.motivRecuHeader = motivRecuHeader;
	}

	public String getMotivRecuMotivo() {
		return motivRecuMotivo;
	}

	public void setMotivRecuMotivo(String motivRecuMotivo) {
		this.motivRecuMotivo = motivRecuMotivo;
	}

	public int getRecusaAcao() {
		return recusaAcao;
	}

	public void setRecusaAcao(int recusaAcao) {
		this.recusaAcao = recusaAcao;
	}

	public List<User> getUserValidaoList() {
		return userValidaoList;
	}

	public void setUserValidaoList(List<User> userValidaoList) {
		this.userValidaoList = userValidaoList;
	}
}