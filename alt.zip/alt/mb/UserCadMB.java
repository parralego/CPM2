package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import com.defines.Role;
import com.defines.TipoLog;
import com.defines.UserStatus;
import com.facade.LogFacade;
import com.facade.UserFacade;
import com.model.Log;
import com.model.User;

@SessionScoped
@ManagedBean(name="userCadMB")
public class UserCadMB extends AbstractMB implements Serializable {
	public static final String INJECTION_NAME = "#{userMB}";
	private static final long serialVersionUID = 1L;
	
	private String password2;

	private User user;
	private List<User> users;
	private UserFacade facade;
	
	private CepMB cepMB;
	
	private boolean cpfReadOnly;
	
	private boolean titular;

	
	 @PostConstruct
	 public void init(){
//		Tools tools = new Tools();
		
//		user = tools.getUserSession();
		setFormCadastro();
		cpfReadOnly=false;
		acao=1;
	}
	
	public UserFacade getFacade() {
		if (facade == null) {
			facade = new UserFacade();
		}

		return facade;
	}
	
	
	public void setFormCadastro(){
		formCadastro = "/pages/protected/defaultUser/frmCadUsuario.xhtml";
	}
	
	
	public String alterar(User user){
		setUser(user);
		setAcao(2);
		
		if(tools.getUserSession().isAdmin())
			cpfReadOnly=false;
		else
			cpfReadOnly=true;
		
		return formCadastro;
	}
	
	public String detalhar(User user){
//		setOutcomeFrom(from);
		setUser(user);
		setAcao(3);
		cpfReadOnly=true;
		return formCadastro;
	}
	
	public boolean validar(){
		if(this.user.getPassword().equals(this.password2) == false){
			keepDialogOpen();
			tools.msgAviso("A Senha n�o s�o iguais");
			return false;
		}
		
		
		if( !tools.validarCpfCnpj(getUser().getCpf(), "CPF" ) ){
			return false;
		}
		
		if(!tools.validarEmail(getUser().getEmail())){
			tools.msgAviso("Email inv�lido");
			return false;
		}
		
		if(!getUser().getNumFone1().isEmpty() && getUser().getTipoFone1().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 1 deve ser informado");
			return false;
		}
		
		if(!getUser().getNumFone2().isEmpty() && getUser().getTipoFone2().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 2 deve ser informado");
			return false;
		}
		
		return true;
	}
	
	public void salvar(){
		if(!validar())
			return;
		
		// Seta o usuario pra ATIVO quando o usuario logado for socio
		if(tools.getUserSession().isUser())
			user.setStatus(UserStatus.ATIVO);

		
		if(this.acao == 2)	// Se for modo update
			update();
		else
			create();
	}
	
	public void create() {
		try {
			getFacade().create(user);
			closeDialog();
			tools.msgAviso("Usu�rio inserido com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void update() {
		try {
			getFacade().update(user);
			closeDialog();
			tools.msgAviso("Usu�rio atualizado com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void delete(User user) {
		try {
			getFacade().delete(user);
			closeDialog();
			tools.msgAviso("Usu�rio deletado com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar usua�rio");
			e.printStackTrace();
		}
	}
	
	//
	// FUNCOES DA TELA DE VALIDAR NOVOS USUARIO - INICIO
	//
	public List<User> userListValidacao(){
		return getFacade().listAllByStatus(UserStatus.VALIDACAO);
	}
	
	public boolean tratarValidacao(){
		if(tools.getUserSession().isAdmin())
			return true;
		return false;
	}
	
	public void verSenhaAutorizacao(){
		tools.msgDialog("Informa��o Confidencial", "Senha: " + this.user.getSenhaAutDebito());
	}
	
	public void aprovarUser(User user){
		user.setStatus(UserStatus.ATIVO);
		
		Log log = new Log();
		
		log.setUserSessao(tools.getUserSession());
		log.setUser(user);
		log.setTipoLog(TipoLog.USER_APROVAR);
		log.setDtCad(new Date());
		log.setObs("Aprovado OK");
		
		
		try {
			getFacade().update(user);
			
			LogFacade logFacade = new LogFacade();
			logFacade.createLog(log);
			
			tools.msgAviso("Usu�rio liberado com sucesso");
		} catch (Exception e) {
			tools.msgErro("Erro ao liberar usua�rio");
			e.printStackTrace();
		}
	}
	
	public void recusarUser(User user){
		user.setStatus(UserStatus.RECUSADO);
		
		Log log = new Log();
		
		log.setUserSessao(tools.getUserSession());
		log.setUser(user);
		log.setTipoLog(TipoLog.USER_RECUSAR);
		log.setDtCad(new Date());
		log.setObs("REcusado");
		
		
		try {
			getFacade().update(user);
			
			LogFacade logFacade = new LogFacade();
			logFacade.createLog(log);
			
			tools.msgAviso("Usu�rio recusado com sucesso");
		} catch (Exception e) {
			tools.msgErro("Erro ao recusar usua�rio");
			e.printStackTrace();
		}
	}
	
	//
	// FUNCOES DA TELA DE VALIDAR NOVOS USUARIO - FINAL
	//

	
	
	public List<String> completeTextTipoUser(String query) {
        List<String> results = new ArrayList<String>();
        
        results.add(Role.ADMIN.toString());
        results.add(Role.USER.toString());
         
        return results;
    }
	
	public List<String> completeTextTipoStatus(String query) {
        List<String> results = new ArrayList<String>();
        
        results.add(UserStatus.ATIVO.toString());
        results.add(UserStatus.BLOQUEADO.toString());
        results.add(UserStatus.INATIVO.toString());
        results.add(UserStatus.PENDENTE_ATIVACAO.toString());
        results.add(UserStatus.PENDENTE_ATUALIZACAO.toString());
         
        return results;
    }

	
	public void buscaCEP(){
		getCepMB().getCep().setCodigoPostal(this.user.getCodigoPostal());
		cepMB.buscaCEP();
		
		this.user.setLogradouro(cepMB.getCep().getLogradouro());
		this.user.setMunicipio(cepMB.getCep().getMunicipio());
		this.user.setBairro(cepMB.getCep().getBairro());
		this.user.setUf(cepMB.getCep().getUf());
		
	}

	public List<User> getAll() {
		if (users == null) {
			load();
		}

		return users;
	}

	private void load() {
		users = getFacade().listAll();
	}

	public void reset() {
		user = new User();
	}
	

	public boolean isAdmin() {
		return user.isAdmin();
	}

	public boolean isDefaultUser() {
		return user.isUser();
	}

	public String logOut() {
		getRequest().getSession().invalidate();
		return "/pages/public/login.xhtml";
	}

	private HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public User getUser() {
		if(user == null)
			user = new User();
		
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public boolean isTitular() {
		return titular;
	}

	public void setTitular(boolean titular) {
		this.titular = titular;
	}	
	
	public CepMB getCepMB() {
		if (cepMB == null) {
			cepMB = new CepMB();
		}
		return cepMB;
	}

	public void setCepMB(CepMB cepMB) {
		this.cepMB = cepMB;
	}

	public boolean isCpfReadOnly() {
		return cpfReadOnly;
	}

	public void setCpfReadOnly(boolean cpfReadOnly) {
		this.cpfReadOnly = cpfReadOnly;
	}
}