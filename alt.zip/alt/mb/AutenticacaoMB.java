package com.mb;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ViewScoped;

import com.defines.AutenticacaoStatus;
import com.facade.AutenticacaoFacade;
import com.model.Autenticacao;
import com.model.User;


@ViewScoped
public class AutenticacaoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private Autenticacao inscricao;
	private List<Autenticacao> inscricaos;
	private AutenticacaoFacade inscricaoFacade;
	
	public AutenticacaoFacade getAutenticacaoFacade() {
		if (inscricaoFacade == null) {
			inscricaoFacade = new AutenticacaoFacade();
		}

		return inscricaoFacade;
	}

	public Autenticacao getAutenticacao() {
		if (inscricao == null) {
			inscricao = new Autenticacao();
		}

		return inscricao;
	}

	public void setAutenticacao(Autenticacao inscricao) {
		this.inscricao = inscricao;
	}
	
	public Autenticacao findByCodigo(String cpf, String codigoAutenticacao){
		return getAutenticacaoFacade().findByCodigo(cpf, codigoAutenticacao);
	}
	
	public String gravarAutenticacao(User user){
		String codigo;
		getAutenticacao().setUser(user);
		getAutenticacao().setDtSolicitacao(new Date());
		getAutenticacao().setStatus(AutenticacaoStatus.ATIVO);
		getAutenticacao().setCodigo(getAutenticacao().gerarCodigoAcesso());
		
		codigo=getAutenticacao().getCodigo();
		
		createAutenticacao();
		return codigo;
	}

	public void createAutenticacao() {
		try {
			getAutenticacaoFacade().createAutenticacao(inscricao);
			System.out.println("Autenticacao inserida com sucesso");
			resetAutenticacao();
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao inserir autenticaca");
			e.printStackTrace();
		}
	}
	
	public void updateAutenticacao() {
		try {
			getAutenticacaoFacade().updateAutenticacao(inscricao);
			System.out.println("Autentica��o atualizada com sucesso");
			resetAutenticacao();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Erro ao atualizar autentica��o");
			e.printStackTrace();
		}
	}
	
	public void deleteAutenticacao() {
		try {
			getAutenticacaoFacade().deleteAutenticacao(inscricao);
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess");
			loadAutenticacaos();
			resetAutenticacao();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	

	public List<Autenticacao> getAllAutenticacaos() {
		if (inscricaos == null) {
			loadAutenticacaos();
		}

		return inscricaos;
	}

	private void loadAutenticacaos() {
		inscricaos = getAutenticacaoFacade().listAll();
	}

	public void resetAutenticacao() {
		inscricao = new Autenticacao();
	}
	
	
	
}