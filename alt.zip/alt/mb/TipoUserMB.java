package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.facade.TipoQuartoFacade;
import com.facade.TipoUserFacade;
import com.facade.UserOcupacaoFacade;
import com.model.TipoQuarto;
import com.model.TipoUser;
import com.model.UserOcupacao;


@ViewScoped
@ManagedBean(name="tipoUserMB")
public class TipoUserMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private TipoUser tipoUser;
	private List<TipoUser> tipoUsers;
	private TipoUserFacade tipoUserFacade;
	
	private List<UserOcupacao>	userOcupacaoList;
	private UserOcupacaoFacade  userOcupacaoFacade;
	
	private List<TipoQuarto>	tipoQuartoList;
	private TipoQuartoFacade  	tipoQuartoFacade;
	
	

	public void createTipoUser() {
		try {
			getTipoUserFacade().createTipoUser(tipoUser);
			closeDialog();
			displayInfoMessageToUser("Created With Sucess");
			loadTipoUsers();
			resetTipoUser();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void updateTipoUser() {
		try {
			getTipoUserFacade().updateTipoUser(tipoUser);
			closeDialog();
			displayInfoMessageToUser("Updated With Sucess");
			loadTipoUsers();
			resetTipoUser();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void deleteTipoUser() {
		try {
			getTipoUserFacade().deleteTipoUser(tipoUser);
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess");
			loadTipoUsers();
			resetTipoUser();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public List<TipoUser> getAllTipoUsers() {
		if (tipoUsers == null) {
			loadTipoUsers();
		}

		return tipoUsers;
	}

	private void loadTipoUsers() {
		tipoUsers = getTipoUserFacade().listAll();
	}

	public void resetTipoUser() {
		tipoUser = new TipoUser();
	}
	
	
	public List<TipoUser> completeText(String query) {
        List<TipoUser> results = new ArrayList<TipoUser>();
        
        if(tipoUsers == null){
        	tipoUserFacade = new TipoUserFacade();
        	tipoUsers = tipoUserFacade.listAll();
        }
        
        for (TipoUser tipoUser : tipoUsers) {
			if (tipoUser.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(tipoUser);
			}
		}
         
        return results;
    }
	
	public List<UserOcupacao> completeTextUserOcupacao(String query) {
        List<UserOcupacao> list = new ArrayList<UserOcupacao>();
        
        if(this.userOcupacaoList == null){
        	userOcupacaoList = getUserOcupacaoFacade().listAll();
        }
        
        for (UserOcupacao userOpupacao : userOcupacaoList) {
			if (userOpupacao.getTipo().toLowerCase().contains(query.toLowerCase())) {
				list.add(userOpupacao);
			}
		}
        return list;
    }
	
	public List<TipoQuarto> completeTextTipoQuarto(String query) {
        List<TipoQuarto> list = new ArrayList<TipoQuarto>();
        
        if(this.tipoQuartoList == null){
        	tipoQuartoList = getTipoQuartoFacade().listAll();
        }
        
        for (TipoQuarto tipoQuarto : tipoQuartoList) { 
			if (tipoQuarto.getTipo().toLowerCase().contains(query.toLowerCase())) {
				list.add(tipoQuarto);
			}
		}
        return list;
    }
	
	public TipoUserFacade getTipoUserFacade() {
		if (tipoUserFacade == null) {
			tipoUserFacade = new TipoUserFacade();
		}

		return tipoUserFacade;
	}

	public TipoUser getTipoUser() {
		if (tipoUser == null) {
			tipoUser = new TipoUser();
		}

		return tipoUser;
	}

	public void setTipoUser(TipoUser tipoUser) {
		this.tipoUser = tipoUser;
	}

	public List<UserOcupacao> getUserOcupacaoList() {
		return userOcupacaoList;
	}

	public void setUserOcupacaoList(List<UserOcupacao> userOcupacaoList) {
		this.userOcupacaoList = userOcupacaoList;
	}

	public UserOcupacaoFacade getUserOcupacaoFacade() {
		if(userOcupacaoFacade == null)
			userOcupacaoFacade = new UserOcupacaoFacade();
		return userOcupacaoFacade;
	}

	public void setUserOcupacaoFacade(UserOcupacaoFacade userOcupacaoFacade) {
		this.userOcupacaoFacade = userOcupacaoFacade;
	}

	public List<TipoQuarto> getTipoQuartoList() {
		return tipoQuartoList;
	}

	public void setTipoQuartoList(List<TipoQuarto> tipoQuartoList) {
		this.tipoQuartoList = tipoQuartoList;
	}

	public TipoQuartoFacade getTipoQuartoFacade() {
		if(tipoQuartoFacade == null)
			return new TipoQuartoFacade();
		return tipoQuartoFacade;
	}

	public void setTipoQuartoFacade(TipoQuartoFacade tipoQuartoFacade) {
		this.tipoQuartoFacade = tipoQuartoFacade;
	}
}