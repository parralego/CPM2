package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import com.defines.Role;
import com.facade.UserFacade;
import com.model.User;

@SessionScoped
@ManagedBean(name="userMB")
public class UserMB extends AbstractMB implements Serializable {
	public static final String INJECTION_NAME = "#{userMB}";
	private static final long serialVersionUID = 1L;
	
	private String password2;

	private User user;
	private List<User> users;
	private UserFacade facade;
	
	public UserFacade getFacade() {
		if (facade == null) {
			facade = new UserFacade();
		}

		return facade;
	}
	
	public String logOut() {
		getRequest().getSession().invalidate();
		return "/pages/public/login";
	}

	private HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}
	
	public boolean isAdmin() {
		return user.isAdmin();
	}

	public boolean isDefaultUser() {
		return user.isUser();
	}
	
	public List<String> completeTextTipoUser(String query) {
        List<String> results = new ArrayList<String>();
        
        results.add(Role.ADMIN.toString());
        results.add(Role.USER.toString());
         
        return results;
    }
	
	
	public List<User> getAll() {
		if (users == null) {
			load();
		}

		return users;
	}

	private void load() {
		users = getFacade().listAll();
	}

	public void reset() {
		user = new User();
	}
	

		public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}	
}