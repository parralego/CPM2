package com.mb;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;

import com.defines.DefaultStatus;
import com.facade.DependenteFacade;
import com.facade.ParentescoFacade;
import com.facade.TipoDocFacade;
import com.facade.UserDocFacade;
import com.model.Dependente;
import com.model.Parentesco;
import com.model.TipoDoc;
import com.model.User;
import com.model.UserDoc;

@ViewScoped
@ManagedBean
public class DependenteMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;


	private Dependente 		 	dependente;
	private List<Dependente> 	dependenteList;
	private DependenteFacade 	dependenteFacade;

	private List<Parentesco> 	parentescoList;
	private ParentescoFacade 	parentescoFacade;

	private User 				user;


	//
	//
	//
	private UserDoc				userDoc;
	private List<UserDoc> 		userDocList;
	private UserDocFacade 		userDocFacade;

	private List<TipoDoc> 		tipoDocList;
	private TipoDocFacade 		tipoDocFacade;
	
	private UploadedFile 		file;
	
	private DefaultStreamedContent download;


	
	//
	//
	//
	public void showUserDocList(User user){
		userDoc = new UserDoc();
		
		this.user 			= user;
		this.userDocList	= getUserDocFacade().findUserDocByUser(this.user.getId());
		
		return;
	}
	
	public String cadastrarDoc(){
		setAcao(1);
		resetDoc();
		return null;
	}
	
	public void loadDoc() {
		this.userDocList	= getUserDocFacade().findUserDocByUser(this.user.getId());
	}

	public void resetDoc() {
		userDoc = new UserDoc();
		this.dependente = new Dependente();
		this.dependente.setUser(user);
	}

	public void salvarUserDoc(){
		try {
			if(this.userDoc.getImagem() == null){
				tools.msgAviso("� necess�rio anexar um arquivo.");
				return;
			}
			
			this.userDoc.setUser(this.user);
			this.userDoc.setDtCad(new Date());
			this.userDoc.setDtAlt(new Date()); 
			
			getUserDocFacade().create(this.userDoc);
			System.out.println("UserDoc inserido com sucesso");

			userDocList.add(this.userDoc);
			closeDialog();
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao gravar documento");
			e.printStackTrace();
			tools.msgErro("ERRO ao gravar documento.");
			return;
		}

		tools.msgAviso("Documento salvo com sucesso.");
		return;
	}
	
	public void deleteUserDoc(UserDoc userDoc) {
		try {
			getUserDocFacade().delete(userDoc);
			closeDialog();
			tools.msgAviso("Documento deletado com sucesso");
			this.userDocList	= getUserDocFacade().findUserDocByUser(this.user.getId());
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar Documento");
			e.printStackTrace();
		}
	}
	
	public void handleFileUpload(FileUploadEvent event) {
		 byte[] file = new byte[event.getFile().getContents().length];
         System.arraycopy(event.getFile().getContents(),0,file,0,event.getFile().getContents().length);
         userDoc.setImagem(file);
         userDoc.setExtensao(event.getFile().getFileName().substring(event.getFile().getFileName().lastIndexOf("."), event.getFile().getFileName().length()));
    }

	
	public void setDownload(DefaultStreamedContent download) {
	    this.download = download;
	}

	public DefaultStreamedContent getDownload() throws Exception {
	    System.out.println("GET = " + download.getName());
	    return download;
	}
	
	public void prepDownload(UserDoc userDoc) throws Exception {
	    InputStream input = new ByteArrayInputStream(userDoc.getImagem());
	    String fileName = userDoc.getNome() + userDoc.getExtensao();
	    setDownload(new DefaultStreamedContent(input, fileName, fileName));
	    
	    System.out.println("ok");
	}
	
	
	public List<TipoDoc> completeTextTipoDoc(String query) {
		List<TipoDoc> results = new ArrayList<TipoDoc>();

		if(this.tipoDocList == null){
			tipoDocList = getTipoDocFacade().listAll();
		}

		for (TipoDoc tipoDoc : this.tipoDocList) {
			if (tipoDoc.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(tipoDoc);
			}
		}

		return results;
	}


	//
	//
	//

	public void showList(User user){
		this.user = user;
		this.dependenteList = getDependenteFacade().findDependenteByUser(user.getId());
		return;
	}


	public void setFormCadastro(){
		formCadastro = "/pages/protected/defaultUser/frmCadUsuario.xhtml";
	}

	public String cadastrar(){
		setAcao(1);
		reset();
		return null;
	}

	public String alterar(Dependente dependente){
		setDependente(dependente);
		setAcao(2);
		return null;
	}

	public String detalhar(Dependente dependente){
		setDependente(dependente);
		setAcao(3);
		return null;
	}

	public boolean validar(){
		if(dependente.getParentesco().getTipo().equals("C�NJUGE")){
			for(int i = 0; i < dependenteList.size(); i++){
				// Soh Permite Cadastrar um dependente tipo conjuge
				if(dependenteList.get(i).getParentesco().getTipo().equals("C�NJUGE") &&
						dependenteList.get(i).getId() != dependente.getId()                ){
					tools.msgErro("J� existe um c�njuge cadastrado.");
					return false;
				}
			}
		}

		if(dependente.getParentesco().getTipo().equals("PAIS")){
			int iCont = 0;

			for(int i = 0; i < dependenteList.size(); i++){
				// Procurar quantos PAIS jah estao cadastrados
				if(dependenteList.get(i).getParentesco().getTipo().equals("PAIS") &&
						dependenteList.get(i).getId() != dependente.getId()            ){
					iCont ++;
				}

				if(iCont == 2){	// Soh permite cadastrar 2 Depentende tipo PAIS	
					tools.msgErro("J� existe dois pais cadastrado.");
					return false;
				}
			}
		}

		return true;
	}


	public void salvar(){
		if(!validar()){
			keepDialogOpen();
			return;
		}	

		try {
			if(this.acao == 1){	// INCLUSAO
				getDependenteFacade().create(this.dependente);
				System.out.println("Dependente inserido com sucesso");
			}
			else{				// ALTERACAO
				getDependenteFacade().update(this.dependente);
				System.out.println("Dependente alterado com sucesso");
			}

			if(acao == 1)
				dependenteList.add(dependente);

			closeDialog();
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao inserir autenticaca");
			e.printStackTrace();
			tools.msgErro("ERRO ao inserir os n�meros sorteados.");
			return;
		}

		tools.msgAviso("Dependente salvo com sucesso.");

		return;
	}


	public void delete(Dependente dependente) {
		try {
			getDependenteFacade().delete(dependente);
			closeDialog();
			tools.msgAviso("Dependente deletado com sucesso");
			load();
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao deletar Dependente");
			e.printStackTrace();
		}
	}


	public List<Parentesco> completeTextParentesco(String query) {
		List<Parentesco> results = new ArrayList<Parentesco>();

		if(parentescoList == null){
			parentescoList = getParentescoFacade().listAll();
		}

		for (Parentesco parentesco : parentescoList) {
			if (parentesco.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(parentesco);
			}
		}

		return results;
	}

	public List<String> completeTextStatus(String query) {
		List<String> results = new ArrayList<String>();

		results.add(DefaultStatus.ATIVO.toString());
		results.add(DefaultStatus.BLOQUEADO.toString());
		results.add(DefaultStatus.INATIVO.toString());

		return results;
	}


	public List<Dependente> getAll() {
		if (dependenteList == null) {
			load();
		}

		return dependenteList;
	}

	private void load() {
		dependenteList = getDependenteFacade().findDependenteByUser(this.user.getId());
	}

	public void reset() {
		dependente = new Dependente();
		this.dependente = new Dependente();
		this.dependente.setUser(user);
	}



	//
	// GETs and SETs
	//
	public DependenteFacade getDependenteFacade() {
		if (dependenteFacade == null) {
			dependenteFacade = new DependenteFacade();
		}

		return dependenteFacade;
	}

	public ParentescoFacade getParentescoFacade() {
		if (parentescoFacade == null) {
			parentescoFacade = new ParentescoFacade();
		}

		return parentescoFacade;
	}


	public Dependente getDependente() {
		return dependente;
	}


	public void setDependente(Dependente dependente) {
		this.dependente = dependente;
	}


	public List<Dependente> getDependenteList() {
		return dependenteList;
	}


	public void setDependenteList(List<Dependente> dependenteList) {
		this.dependenteList = dependenteList;
	}


	public List<Parentesco> getParentescoList() {
		return parentescoList;
	}


	public void setParentescoList(List<Parentesco> parentescoList) {
		this.parentescoList = parentescoList;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public void setDependenteFacade(DependenteFacade dependenteFacade) {
		this.dependenteFacade = dependenteFacade;
	}


	public void setParentescoFacade(ParentescoFacade parentescoFacade) {
		this.parentescoFacade = parentescoFacade;
	}

	public UserDoc getUserDoc() {
		return userDoc;
	}


	public void setUserDoc(UserDoc userDoc) {
		this.userDoc = userDoc;
	}


	public List<UserDoc> getUserDocList() {
		return userDocList;
	}


	public void setUserDocList(List<UserDoc> userDocList) {
		this.userDocList = userDocList;
	}


	public UserDocFacade getUserDocFacade() {
		if(userDocFacade == null)
			userDocFacade = new UserDocFacade();
		return userDocFacade;
	}


	public void setUserDocFacade(UserDocFacade userDocFacade) {
		this.userDocFacade = userDocFacade;
	}


	public List<TipoDoc> getTipoDocList() {
		return tipoDocList;
	}


	public void setTipoDocList(List<TipoDoc> tipoDocList) {
		this.tipoDocList = tipoDocList;
	}


	public TipoDocFacade getTipoDocFacade() {
		if(tipoDocFacade == null)
			tipoDocFacade = new TipoDocFacade();
		return tipoDocFacade;
	}


	public void setTipoDocFacade(TipoDocFacade tipoDocFacade) {
		this.tipoDocFacade = tipoDocFacade;
	}


	public UploadedFile getFile() {
		return file;
	}


	public void setFile(UploadedFile file) {
		this.file = file;
	}

}