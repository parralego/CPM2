package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.FlowEvent;

import com.defines.UserStatus;
import com.facade.DependenteFacade;
import com.facade.MeioPgtoFacade;
import com.facade.ParentescoFacade;
import com.facade.TipoDocFacade;
import com.facade.UserDocFacade;
import com.facade.UserFacade;
import com.model.Dependente;
import com.model.MeioPgto;
import com.model.Parentesco;
import com.model.TipoDoc;
import com.model.TipoUser;
import com.model.User;
import com.model.UserDoc;

@ViewScoped
@ManagedBean
public class UserCadNovoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String password2;
	private String password2Aut;
	
	private String senhaBck;
	private String senhaAutBck;

	private User 				user;
	private UserFacade 			userFacade;
	
	private UserDoc				userDoc;
	private List<UserDoc>		userDocList;
	private UserDocFacade		userDocFacade;
	
	private Dependente			dependente;
	private List<Dependente>	dependenteList;
	private DependenteFacade	dependenteFacade;
	
	
	private List<Parentesco> 	parentescoList;
	private ParentescoFacade 	parentescoFacade;
	
	private List<TipoDoc> 		tipoDocList;
	private TipoDocFacade 		tipoDocFacade;
	
	private List<MeioPgto>		meioPgtoList;
	private MeioPgtoFacade		meioPgtoFacade;

	
	private CepMB 				cepMB;
	
	private boolean skip;
	private boolean primeiraVez;
	private boolean aceitaTermos;

	
	 @PostConstruct
	 public void init(){
		 getUser().setCpf("060.222.879-44");
		acao=1;
		primeiraVez=true;
		aceitaTermos=false;
	}
	 
	public String onFlowProcess(FlowEvent event) {
		if(skip) {
            skip = false;   //reset in case user goes back
            return "confirm";
        }
        else {
        	if(event.getNewStep().equals("tab-pessoal") && primeiraVez){
        		if(!identificar())
        			return event.getOldStep();
        		
        		primeiraVez = false;
        	}
        	
        	if(event.getOldStep().equals("tab-pessoal")){
        		if(!validarDadosPessoais())
        			return event.getOldStep();
        	}else if(event.getOldStep().equals("tab-corporacao")){
        		if(!validarDadosCorporacao())
        			return event.getOldStep();
        	}
        	
            return event.getNewStep();
        }
	}
	
	public boolean identificar(){
		User userTemp = new User();
		userTemp = getUserFacade().findByEmail(this.user.getCpf());
		
		// Usuario NOVO
		if(userTemp == null)
			return true;
		
		if(userTemp.getStatus().equals(UserStatus.RECUSADO) ){
			tools.msgAviso("Seu cadastro foi recusado, para maiores informa��es entre em contato com a AVM-PR");
			return false;
		}
		
		// Usuario jah validado
		if(!userTemp.getStatus().equals(UserStatus.VALIDACAO) && 
		   !userTemp.getStatus().equals(UserStatus.PEDENTE_VALIDACAO)){
			tools.msgAviso("J� existe um Usu�rio cadastrado para o CPF informado, sendo assim entre direto no portal da AVM.");
			return false;
		}
		
		// Usuario em validacao
		this.user 			= userTemp;
		
		// Quarda a senha pra nao obrigar digitar de novo
		this.senhaBck 		= this.user.getPassword();
		this.senhaAutBck 	= this.user.getSenhaAutDebito();
				
		this.acao	= 2;
		
		dependenteList  = getDependenteFacade().findDependenteByUser(this.user.getId());
		userDocList		= getUserDocFacade().findUserDocByUser(this.user.getId()); 
		
		return true;
	}
	
	
	
	public void setFormCadastro(){
		formCadastro = "/pages/protected/defaultUser/frmCadUsuario.xhtml";
	}
	
	
	public String alterar(User user){
		setUser(user);
		setAcao(2);
		
		return formCadastro;
	}
	
	public boolean validarDadosPessoais(){
		if(this.user.getPassword().isEmpty()){
			user.setPassword(senhaBck);
			password2 = senhaBck;
		}
		
		if(this.user.getPassword().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O Campo senha da sess�o Dados Pessoais � obrigat�rio");
			return false;
		}
		
		if(this.user.getPassword().equals(this.password2) == false){
			keepDialogOpen();
			tools.msgAviso("A Senha da sess�o Dados Pessoais n�o s�o iguais");
			return false;
		}
		
		
		if( !tools.validarCpfCnpj(getUser().getCpf(), "CPF" ) ){
			keepDialogOpen();
			tools.msgAviso("O CPF � inv�lido");
			return false;
		}
		
		if(!tools.validarEmail(getUser().getEmail())){
			tools.msgAviso("Email inv�lido");
			return false;
		}
		
		if(!getUser().getNumFone1().isEmpty() && getUser().getTipoFone1().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 1 deve ser informado");
			return false;
		}
		
		if(!getUser().getNumFone2().isEmpty() && getUser().getTipoFone2().toString().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O campo tipo de Telefone 2 deve ser informado");
			return false;
		}
		return true;
	}
	
	public boolean validarDadosCorporacao(){
		if(this.user.getSenhaAutDebito().isEmpty()){
			user.setSenhaAutDebito(senhaAutBck);
			password2Aut = senhaAutBck;
		}
		
		if(this.user.getSenhaAutDebito().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("O Campo senha de autoriza��o � obrigat�rio");
			return false;
		}
		
		if(this.user.getSenhaAutDebito().equals(this.password2Aut) == false){
			keepDialogOpen();
			tools.msgAviso("A Senha de autoriza��o n�o s�o iguais");
			return false;
		}
		return true;
	}
	
	
	
	public String salvar(){
//		if(!validar())
//			return;
		
		// Remove os registros que jah estao gravado na base (id > 0) para nao gravar de novo
		this.dependenteList.removeIf(p -> p.getId() > 0);
		this.userDocList.removeIf(p -> p.getId() > 0);
		
		this.user.setStatus(UserStatus.VALIDACAO);
		this.user.setTipoUser(new TipoUser(1));
		
					
		
		if(this.acao == 2)	// Se for modo update
			update();
		else
			create();
		
		return "/pages/public/frmUserNovoConclusao";
	}
	
	public void create() {
		try {
			
			getUserFacade().create(this.user);
			
			if(!dependenteList.isEmpty())
				getDependenteFacade().createList(dependenteList);
			
			if(!userDocList.isEmpty())
				getUserDocFacade().createUserDocList(userDocList);
			
			closeDialog();
			tools.msgAviso("Usu�rio cadastrado com sucesso");
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void update() {
		try {
			getUserFacade().update(user);
			
			if(!dependenteList.isEmpty())
				getDependenteFacade().createList(dependenteList);
			
			if(!userDocList.isEmpty())
				getUserDocFacade().createUserDocList(userDocList);
			
			closeDialog();
			tools.msgAviso("Usu�rio atualizado com sucesso");
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void addDependente(){
		if(this.dependente.getNome().isEmpty()){
			tools.msgAviso("O campo nome � obrigat�rio");
			return;
		}
		
		if(this.dependente.getDtNascimento() == null){
			tools.msgAviso("O campo data de nascimento � obrigat�rio");
			return;
		}
		
		if(this.dependente.getSexo() == null){
			tools.msgAviso("O campo sexo � obrigat�rio");
			return;
		}
		
		if(this.dependente.getParentesco() == null){
			tools.msgAviso("O campo parentesco � obrigat�rio");
			return;
		}
		
		if(this.dependente.getStatus() == null){
			tools.msgAviso("O campo status � obrigat�rio");
			return;
		}
		
		if(getDependenteList() != null && !getDependenteList().isEmpty()){
			// Faz validacoes para o parentesco CONJUGE
			if(this.dependente.getParentesco().getTipo().equals("C�NJUGE")){
				for (int i = 0; i < getDependenteList().size(); i++){
					if(getDependenteList().get(i).getParentesco().getTipo().equals("C�NJUGE")){
						tools.msgAviso("J� existe um C�NJUGE cadastrado.");
						return;
					}
					
					if(getDependenteList().get(i).getParentesco().getTipo().equals("PAIS")){
						tools.msgAviso("Um C�NJUGE j� est� cadastrado, n�o � permitido cadastrar PAIS para s�cios casados.");
						return;
					}
				}
			}
			
			// Faz validacoes para o parentesco PAIS
			if(this.dependente.getParentesco().getTipo().equals("PAIS")){
				int iCont = 0;
				for (int i = 0; i < getDependenteList().size(); i++){
					if(getDependenteList().get(i).getParentesco().getTipo().equals("PAIS")){
						iCont ++;
						
						if(iCont > 2){
							tools.msgAviso("S� � permitido cadastrar DOIS dependentes do parentesco PAIS.");
							return;
						}
					}
					
					if(getDependenteList().get(i).getParentesco().getTipo().equals("C�NJUGE")){
						tools.msgAviso("N�o � permitido cadastrar um C�NJUGE quando j� houver um dependente com o parentesco PAIS");
						return;
					}
				}
			}
		}
		
		this.dependente.setUser(this.user);
		this.dependente.setDtCad(new Date());
		
		getDependenteList().add(this.dependente);
		this.dependente = new Dependente();
	}
	
	public void addUserDoc(){
		if(this.userDoc.getNome().isEmpty()){
			tools.msgAviso("O campo nome � obrigat�rio.");
			return;
		}
		
		if(this.userDoc.getTipoDoc() == null){
			tools.msgAviso("O campo tipo � obrigat�rio.");
			return;
		}
		
		if(this.userDoc.getImagem() == null){
			tools.msgAviso("� necess�rio adicionar uma imagem.");
			return;
		}
	
		this.userDoc.setUser(this.user);
		this.userDoc.setDtCad(new Date());
		
		getUserDocList().add(this.userDoc);
		this.userDoc = new UserDoc();
	}
	
	
	public void deleteDependente(Dependente dep){
		if(dependenteList.isEmpty())
			return;
		
		dependenteList.remove(dep);
	}
	
	public void deleteUserDoc(UserDoc userDoc){
		if(userDocList.isEmpty())
			return;
		
		userDocList.remove(userDoc);
	}
	
	public void handleFileUpload(FileUploadEvent event) {
		 byte[] file = new byte[event.getFile().getContents().length];
        System.arraycopy(event.getFile().getContents(),0,file,0,event.getFile().getContents().length);
        userDoc.setImagem(file);
        userDoc.setExtensao(event.getFile().getFileName().substring(event.getFile().getFileName().lastIndexOf("."), event.getFile().getFileName().length()));
   }
	
	public void buscaCEP(){
		getCepMB().getCep().setCodigoPostal(this.user.getCodigoPostal());
		cepMB.buscaCEP();
		
		this.user.setLogradouro(cepMB.getCep().getLogradouro());
		this.user.setMunicipio(cepMB.getCep().getMunicipio());
		this.user.setBairro(cepMB.getCep().getBairro());
		this.user.setUf(cepMB.getCep().getUf());
		
	}
	
	public List<MeioPgto> completeTextMeioPgto(String query) {
        List<MeioPgto> results = new ArrayList<MeioPgto>();
        
        
        if(meioPgtoList == null || meioPgtoList.isEmpty()){
        	meioPgtoList = getMeioPgtoFacade().listAll();
        }
        
        for (MeioPgto meioPgto : meioPgtoList) {
			if (meioPgto.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(meioPgto);
			}
		}
         
        return results;
    }
	
	//
	// GETs and SETs
	//
	public void reset() {
		user = new User();
		userDocList.clear();
		dependenteList.clear();
	}
	

	
	public String getPassword2() {
		return password2;
	}

	public User getUser() {
		if(user == null)
			user = new User();
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserFacade getUserFacade() {
		if(userFacade == null)
			userFacade = new UserFacade();
		return userFacade;
	}

	public void setUserFacade(UserFacade userFacade) {
		this.userFacade = userFacade;
	}

	public UserDoc getUserDoc() {
		if(userDoc == null)
			userDoc = new UserDoc();
		return userDoc;
	}

	public void setUserDoc(UserDoc userDoc) {
		this.userDoc = userDoc;
	}

	public UserDocFacade getUserDocFacade() {
		if(userDocFacade == null)
			userDocFacade = new UserDocFacade();
		
		return userDocFacade;
	}

	public void setUserDocFacade(UserDocFacade userDocFacade) {
		this.userDocFacade = userDocFacade;
	}

	public Dependente getDependente() {
		if(dependente == null)
			dependente = new Dependente();
		return dependente;
	}

	public void setDependente(Dependente dependente) {
		this.dependente = dependente;
	}

	public DependenteFacade getDependenteFacade() {
		if(dependenteFacade == null)
			dependenteFacade = new DependenteFacade();
		return dependenteFacade;
	}

	public void setDependenteFacade(DependenteFacade dependenteFacade) {
		this.dependenteFacade = dependenteFacade;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public CepMB getCepMB() {
		if (cepMB == null) {
			cepMB = new CepMB();
		}
		return cepMB;
	}

	public void setCepMB(CepMB cepMB) {
		this.cepMB = cepMB;
	}

		public boolean isSkip() {
		return skip;
	}

	public void setSkip(boolean skip) {
		this.skip = skip;
	}

	public List<Parentesco> getParentescoList() {
		return parentescoList;
	}

	public void setParentescoList(List<Parentesco> parentescoList) {
		this.parentescoList = parentescoList;
	}

	public ParentescoFacade getParentescoFacade() {
		if(parentescoFacade == null)
			parentescoFacade = new ParentescoFacade();
		
		return parentescoFacade;
	}

	public void setParentescoFacade(ParentescoFacade parentescoFacade) {
		this.parentescoFacade = parentescoFacade;
	}

	public List<TipoDoc> getTipoDocList() {
		return tipoDocList;
	}

	public void setTipoDocList(List<TipoDoc> tipoDocList) {
		this.tipoDocList = tipoDocList;
	}

	public TipoDocFacade getTipoDocFacade() {
		if(tipoDocFacade == null)
			tipoDocFacade = new TipoDocFacade();
		
		return tipoDocFacade;
	}

	public void setTipoDocFacade(TipoDocFacade tipoDocFacade) {
		this.tipoDocFacade = tipoDocFacade;
	}

	public List<Dependente> getDependenteList() {
		if(dependenteList == null)
			dependenteList = new ArrayList<Dependente>();
		return dependenteList;
	}

	public void setDependenteList(List<Dependente> dependenteList) {
		this.dependenteList = dependenteList;
	}

	public List<UserDoc> getUserDocList() {
		if(userDocList == null)
			userDocList = new ArrayList<UserDoc>();
		return userDocList;
	}

	public void setUserDocList(List<UserDoc> userDocList) {
		this.userDocList = userDocList;
	}

	public List<MeioPgto> getMeioPgtoList() {
		return meioPgtoList;
	}

	public void setMeioPgtoList(List<MeioPgto> meioPgtoList) {
		this.meioPgtoList = meioPgtoList;
	}

	public MeioPgtoFacade getMeioPgtoFacade() {
		if(meioPgtoFacade == null)
			meioPgtoFacade = new MeioPgtoFacade();
		return meioPgtoFacade;
	}

	public void setMeioPgtoFacade(MeioPgtoFacade meioPgtoFacade) {
		this.meioPgtoFacade = meioPgtoFacade;
	}

	public String getPassword2Aut() {
		return password2Aut;
	}

	public void setPassword2Aut(String password2Aut) {
		this.password2Aut = password2Aut;
	}

	public boolean isAceitaTermos() {
		return aceitaTermos;
	}

	public void setAceitaTermos(boolean aceitaTermos) {
		this.aceitaTermos = aceitaTermos;
	}	
	
}