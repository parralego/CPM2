package com.mb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
 
@ManagedBean
public class CheckboxViewMB {
 
    private List<String> tipoUsers;
    
 
    @PostConstruct
    public void init() {
    	if(tipoUsers == null){
    		tipoUsers = new ArrayList<String>();
    		
    		tipoUsers.add("Soldado");
        	tipoUsers.add("Cabo");
        	tipoUsers.add("Coronel");
        	tipoUsers.add("Sargento");
        	tipoUsers.add("Capit�o");
    	}
    	return;
    }


	public List<String> getTipoUsers() {
		return tipoUsers;
	}


	public void setTipoUsers(List<String> tipoUsers) {
		this.tipoUsers = tipoUsers;
	}  
}