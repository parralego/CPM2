package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.defines.StatusDefault;
import com.defines.TipoHospede;
import com.facade.DependenteFacade;
import com.facade.SorteioHospedeFacade;
import com.facade.UserFacade;
import com.model.Dependente;
import com.model.SorteioHospede;
import com.model.SorteioResultado;
import com.model.User;

@ViewScoped
@ManagedBean
public class SorteioHospedeMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
		
	private SorteioHospede			sorteioHospede;
	private List<SorteioHospede>	sorteioHospedeList;
	private SorteioHospedeFacade	sorteioHospedeFacade;
	
	private SorteioResultado 		sorteioResultado;
	
	private User 					user;
	private UserFacade 				userFacade;
	
	private List<String>			tipoHospedeList;
	
	private Dependente				dependente;
	private List<Dependente>		dependenteList;
	private DependenteFacade		dependenteFacade;
	
	private boolean					readOnly;
	
	
	@PostConstruct
	public void init(){
		acao=1;
	}
	
	public void show(SorteioResultado sorteioResultado){
		reset();
		this.sorteioResultado = sorteioResultado;
		
		// Carrega lista de pependente
		dependenteList 		= getDependenteFacade().findDependenteByUser(this.sorteioResultado.getInscricao().getUser().getId());
		
		
		// Cria a lista com o tipo de hospedes
		tipoHospedeList = new ArrayList<String>();
		if(dependenteList != null && !dependenteList.isEmpty()){
			for(int i = 0; i < dependenteList.size(); i++)
				tipoHospedeList.add(dependenteList.get(i).getNome());
		}
		tipoHospedeList.add("Convidado");
		
		// Carrega lista de hospedes
		sorteioHospedeList 	= getSorteioHospedeFacade().findSorteioHospedeBySorteioResultado(this.sorteioResultado.getId());
		if(this.sorteioHospedeList == null || this.sorteioHospedeList.isEmpty())
			this.acao = 1;
		else{
			// Remover da lista de Hospedes os hospedes jah cadastrados na base
			for(SorteioHospede hospede : sorteioHospedeList)
				tipoHospedeList.removeIf(p -> p.equals(hospede.getNome()));
			this.acao = 2;
		}
		
		readOnly=true;
	}
	
	public void onChangeTipoHospede() {
		// Procusa o nome selecionado na lista de dependente
    	for(Dependente dep : dependenteList){
    		if(dep.getNome().equals(this.sorteioHospede.getNome())){
    			this.sorteioHospede.setDtNascimento(dep.getDtNascimento());
    			this.sorteioHospede.setCpf(dep.getCpf());
    			this.sorteioHospede.setRg(dep.getRg());
    			this.sorteioHospede.setSexo(dep.getSexo());
    			this.sorteioHospede.setTipo(TipoHospede.DEPENDENTE);
    			this.sorteioHospede.setStatus(StatusDefault.ATIVO);
    			
    			readOnly = true;
    			return;
    		}
    	}
    	
    	// Se o tipo estiver igual a null eh pq nao encontrou na lista de dependente
    	if(this.sorteioHospede.getTipo() == null){
    		this.sorteioHospede.setTipo(TipoHospede.CONVIDADO);
    		this.sorteioHospede.setStatus(StatusDefault.ATIVO);
    		readOnly = false;
    	}
    }
	 
	
	
	public String alterar(User user){
		setUser(user);
		setAcao(2);
		
		return formCadastro;
	}
	
	public void addHospede(){
		int iMaxHospedes = this.sorteioResultado.getSorteioQuarto().getQuarto().getQtdeOcupacao();
		if(this.sorteioHospedeList.size()  >= iMaxHospedes - 1){	// o -1 eh pq tenho que considerar o titular
			tools.msgAviso("O n�mero m�ximo de hospedes para esse quarto � de " + tools.convertIntToString(iMaxHospedes));
			return;
		}
		
		if(this.sorteioHospede.getTipo() == null){
			tools.msgAviso("O campo tipo de h�spede � obrigat�rio");
			return;
		}
		
		if(this.sorteioHospede.getNome().isEmpty()){
			tools.msgAviso("O campo nome � obrigat�rio");
			return;
		}
		
		if(this.sorteioHospede.getDtNascimento() == null){
			tools.msgAviso("O campo data de nascimento � obrigat�rio");
			return;
		}
		
		if(this.sorteioHospede.getSexo() == null){
			tools.msgAviso("O campo sexo � obrigat�rio");
			return;
		}
		
		this.sorteioHospede.setSorteioResultado(this.sorteioResultado);
		
		tipoHospedeList.removeIf(p -> p.equals(this.sorteioHospede.getNome()));
		
		getSorteioHospedeList().add(this.sorteioHospede);
		this.sorteioHospede = new SorteioHospede();
	}
	
	
	public void delete(SorteioHospede hospede){
		if(getSorteioHospedeList().isEmpty())
			return;
		
		tipoHospedeList.add(hospede.getNome());
		getSorteioHospedeList().remove(hospede);
	}
	
	
	
	public void salvar(){
		if(getSorteioHospedeList().isEmpty()){
			keepDialogOpen();
			tools.msgAviso("� necess�rio adicionar ao menos um H�spede!");
			return;
		}
		
		// Remover da lista os hospedes que j� est�o cadatrados na base
		getSorteioHospedeList().removeIf(p -> p.getId() > 0);
		
		if(this.acao == 2)	// Se for modo update
			update();
		else
			create();
	}
	
	public void create() {
		try {
			if(!sorteioHospedeList.isEmpty())
				getSorteioHospedeFacade().createList(sorteioHospedeList);
			
			closeDialog();
			tools.msgAviso("H�spede(s) cadastrado(s) com sucesso");
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao inserir o usu�rio");
			e.printStackTrace();
		}
	}
	
	public void update() {
		try {
			if(!sorteioHospedeList.isEmpty())
				getSorteioHospedeFacade().createList(sorteioHospedeList);
			
			closeDialog();
			tools.msgAviso("H�spede(s) atualizado(s) com sucesso");
			reset();
		} catch (Exception e) {
			keepDialogOpen();
			tools.msgAviso("Erro ao atualizar o usu�rio");
			e.printStackTrace();
		}
	}
	
	
	
	
	//
	// GETs and SETs
	//
	public void reset() {
		this.sorteioHospede 	= new SorteioHospede();
		this.sorteioResultado 	= new SorteioResultado();
		
		if(sorteioHospedeList != null)
			sorteioHospedeList.clear();
		
		if(dependenteList != null)
			dependenteList.clear();
	}
	

	
	public User getUser() {
		if(user == null)
			user = new User();
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserFacade getUserFacade() {
		if(userFacade == null)
			userFacade = new UserFacade();
		return userFacade;
	}

	public void setUserFacade(UserFacade userFacade) {
		this.userFacade = userFacade;
	}

	
	public Dependente getDependente() {
		if(dependente == null)
			dependente = new Dependente();
		return dependente;
	}

	public void setDependente(Dependente dependente) {
		this.dependente = dependente;
	}

	public DependenteFacade getDependenteFacade() {
		if(dependenteFacade == null)
			dependenteFacade = new DependenteFacade();
		return dependenteFacade;
	}

	public void setDependenteFacade(DependenteFacade dependenteFacade) {
		this.dependenteFacade = dependenteFacade;
	}

	public List<Dependente> getDependenteList() {
		if(dependenteList == null)
			dependenteList = new ArrayList<Dependente>();
		return dependenteList;
	}

	public void setDependenteList(List<Dependente> dependenteList) {
		this.dependenteList = dependenteList;
	}

	public SorteioHospede getSorteioHospede() {
		return sorteioHospede;
	}

	public void setSorteioHospede(SorteioHospede sorteioHospede) {
		this.sorteioHospede = sorteioHospede;
	}

	public List<SorteioHospede> getSorteioHospedeList() {
		return sorteioHospedeList;
	}

	public void setSorteioHospedeList(List<SorteioHospede> sorteioHospedeList) {
		this.sorteioHospedeList = sorteioHospedeList;
	}

	public SorteioHospedeFacade getSorteioHospedeFacade() {
		if(sorteioHospedeFacade == null)
			sorteioHospedeFacade = new SorteioHospedeFacade();
		return sorteioHospedeFacade;
	}

	public void setSorteioHospedeFacade(SorteioHospedeFacade sorteioHospedeFacade) {
		this.sorteioHospedeFacade = sorteioHospedeFacade;
	}

	public List<String> getTipoHospedeList() {
		return tipoHospedeList;
	}

	public void setTipoHospedeList(List<String> tipoHospedeList) {
		this.tipoHospedeList = tipoHospedeList;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	
}