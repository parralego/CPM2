package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.defines.SorteioStatus;
import com.facade.InscricaoFacade;
import com.facade.QuartoFacade;
import com.facade.SorteioFacade;
import com.facade.SorteioQuartoFacade;
import com.model.Agrupamento;
import com.model.Inscricao;
import com.model.Quarto;
import com.model.Sorteio;
import com.model.SorteioQuarto;


@ViewScoped
@ManagedBean
public class SorteioQuartoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<SorteioQuarto> sorteioQuartos;
	private SorteioQuartoFacade sorteioQuartoFacade;
	
	private Sorteio sorteio;
	private SorteioFacade sorteioFacade;
	
	private List<Quarto> quartos;
	private QuartoFacade quartoFacade;
	
	private List<Inscricao> inscricoes;
	private InscricaoFacade inscricaoFacade;
	
	private List<Agrupamento> agrupInscricoes;
	private int totalInscritos;
	
	
	@PostConstruct
	public void init(){
		this.acao = 1;
	}
	
	
	public void show(Sorteio sorteio){
		reset();
		
		this.sorteio = sorteio;
		
		this.sorteioQuartos = getSorteioQuartoFacade().findSorteioQuartoBySorteio(sorteio.getId());
		if(sorteioQuartos == null || sorteioQuartos.isEmpty())
			this.acao = 1;
		else{
			quartos = new ArrayList<Quarto>();
			Quarto quarto = null;
			
			for(int i=0; i < sorteioQuartos.size(); i++){
				quarto = sorteioQuartos.get(i).getQuarto();
				quarto.setStatus(sorteioQuartos.get(i).getStatus());
				quarto.setObs(sorteioQuartos.get(i).getObs());
				quartos.add(quarto);
			}
			
			this.acao = 3;
		}
			
	}
	
		
	public void salvar(){
		
		if(sorteioQuartos == null || sorteioQuartos.isEmpty()){
			tools.msgAviso("Favor cadastrar os quartos para esse sorteio.");
			return ;
		}
		
		// Atualizar sorteio para SORTEADO
		this.sorteio.setStatus(SorteioStatus.SORTEADO);
		
		try {
			getSorteioQuartoFacade().createSorteioQuartoList(this.sorteioQuartos);
			System.out.println("Numero  inserida com sucesso");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao inserir autenticaca");
			e.printStackTrace();
			tools.msgErro("ERRO ao inserir os n�meros sorteados.");
			return;
		}
		
		

		
//		try {
//			getSorteioFacade().updateSorteio(this.sorteio);
//			System.out.println("Sorteio atualizado com sucesso");
//		} catch (Exception e) {
//			keepDialogOpen();
//			tools.msgAviso("Erro ao atualizar sorteio.");
//			e.printStackTrace();
//			return;
//		}
		
		
		tools.msgAviso("N�meros sorteados inseridos com sucesso.");
		
//		closeDialog();
//		loadInscricoes();
//		resetInscricao();
		
		return;
	}
	

	
	public void reset() {
		sorteioQuartos = null;
		quartos = null;
	}
	
	
	
	
	public SorteioQuartoFacade getSorteioQuartoFacade() {
		if (sorteioQuartoFacade == null)
			sorteioQuartoFacade = new SorteioQuartoFacade();

		return sorteioQuartoFacade;
	}

	public InscricaoFacade getInscricaoFacade() {
		if (inscricaoFacade == null)
			inscricaoFacade = new InscricaoFacade();

		return inscricaoFacade;
	}
	
	public SorteioFacade getSorteioFacade() {
		if(sorteioFacade == null)
			sorteioFacade = new SorteioFacade();
		
		return sorteioFacade;
	}



	public QuartoFacade getQuartoFacade() {
		if(quartoFacade == null)
			quartoFacade = new QuartoFacade();
		
		return quartoFacade;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<SorteioQuarto> getSorteioQuartos() {
		return sorteioQuartos;
	}

	public void setSorteioQuartos(List<SorteioQuarto> sorteioQuartos) {
		this.sorteioQuartos = sorteioQuartos;
	}

	public List<Inscricao> getInscricoes() {
		return inscricoes;
	}

	public void setInscricoes(List<Inscricao> inscricoes) {
		this.inscricoes = inscricoes;
	}


	public List<Agrupamento> getAgrupInscricoes() {
		return agrupInscricoes;
	}


	public void setAgrupInscricoes(List<Agrupamento> agrupInscricoes) {
		this.agrupInscricoes = agrupInscricoes;
	}


	public int getTotalInscritos() {
		return totalInscritos;
	}


	public void setTotalInscritos(int totalInscritos) {
		this.totalInscritos = totalInscritos;
	}


	public void setSorteioFacade(SorteioFacade sorteioFacade) {
		this.sorteioFacade = sorteioFacade;
	}


	public List<Quarto> getQuartos() {
		return quartos;
	}


	public void setQuartos(List<Quarto> quartos) {
		this.quartos = quartos;
	}

	public void setQuartoFacade(QuartoFacade quartoFacade) {
		this.quartoFacade = quartoFacade;
	}
	
	
	
}