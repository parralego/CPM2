package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.model.DualListModel;

import com.facade.UnidadeFacade;
import com.model.TipoUser;
import com.model.Unidade;
import com.sun.faces.context.flash.ELFlash;

@ViewScoped
@ManagedBean
public class UnidadeMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String SELECTED_PERSON = "selectedUnidade";

	private TipoUser tipoUser;
	private Unidade unidade;
	private Unidade unidadeWithTipoUsers;
	private Unidade unidadeWithTipoUsersForDetail;

	private List<Unidade> unidades;

	private UnidadeFacade unidadeFacade;
	
	
	private DualListModel<TipoUser> usuarioModel;
	
	private List<TipoUser> usuariosSelecionados = new ArrayList<TipoUser>();
	private List<TipoUser> usuarios 			= new ArrayList<TipoUser>();
	private List<TipoUser> perfilUsuarios;
	
	
	

	public String getFormCadastro(){
		return "/pages/protected/defaultUser/cadastro/cadUserForm";
	}
	
	public String getListaCadastro(){
		return "/pages/protected/defaultUser/cadastro/cadUserList";
	}
	
	
	
	public void alterar(Unidade unidade){
		setUnidade(unidade);
		setAcao(2);
	}
	
	public void detalhar(Unidade unidade){
		setUnidade(unidade);
		setAcao(3);
	}
	

	public void createUnidade() {
		try {
			getUnidadeFacade().create(unidade);
			closeDialog();
			displayInfoMessageToUser("Created With Sucess");
			load();
			resetUnidade();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public void updateUnidade() {
		try {
			getUnidadeFacade().update(unidade);
			closeDialog();
			displayInfoMessageToUser("Updated With Sucess");
			load();
			resetUnidade();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public void deleteUnidade() {
		try {
			getUnidadeFacade().delete(unidade);
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess");
			load();
			resetUnidade();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public void addTipoUserToUnidade() {
		try {
			getUnidadeFacade().addTipoUserToUnidade(tipoUser.getId(), unidadeWithTipoUsers.getId());
			closeDialog();
			displayInfoMessageToUser("Added With Sucess");
			reloadUnidadeWithTipoUsers();
			resetTipoUser();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public void removeTipoUserFromUnidade() {
		try {
			getUnidadeFacade().removeTipoUserFromUnidade(tipoUser.getId(), unidadeWithTipoUsers.getId());
			closeDialog();
			displayInfoMessageToUser("Removed With Sucess");
			reloadUnidadeWithTipoUsers();
			resetTipoUser();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	
	public Unidade getUnidadeWithTipoUsers() {
		if (unidadeWithTipoUsers == null) {
			unidade = (Unidade) ELFlash.getFlash().get(SELECTED_PERSON);
			unidadeWithTipoUsers = getUnidadeFacade().findUnidadeWithAllTipoUsers(unidade.getId());
		}

		return unidadeWithTipoUsers;
	}

	public void setUnidadeWithTipoUsersForDetail(Unidade unidade) {
		unidadeWithTipoUsersForDetail = getUnidadeFacade().findUnidadeWithAllTipoUsers(unidade.getId());
	}

	public Unidade getUnidadeWithTipoUsersForDetail() {
		if (unidadeWithTipoUsersForDetail == null) {
			unidadeWithTipoUsersForDetail = new Unidade();
			unidadeWithTipoUsersForDetail.setTipoUsuarios(new ArrayList<TipoUser>());
		}

		return unidadeWithTipoUsersForDetail;
	}

	public void resetUnidadeWithTipoUsersForDetail() {
		unidadeWithTipoUsersForDetail = new Unidade();
	}

	public String editUnidadeTipoUsers() {
		ELFlash.getFlash().put(SELECTED_PERSON, unidade);
		return "/pages/protected/defaultUser/unidadeTipoUsers/unidadeTipoUsers.xhtml";
	}	

	public UnidadeFacade getUnidadeFacade() {
		if (unidadeFacade == null) {
			unidadeFacade = new UnidadeFacade();
		}

		return unidadeFacade;
	}

	public Unidade getUnidade() {
		if (unidade == null) {
			unidade = new Unidade();
		}

		return unidade;
	}

	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public List<Unidade> getAll() {
		if (unidades == null) {
			load();
		}

		return unidades;
	}

	private void load() {
		unidades = getUnidadeFacade().list();
	}

	public void resetUnidade() {
		unidade = new Unidade();
	}

	public TipoUser getTipoUser() {
		if (tipoUser == null) {
			tipoUser = new TipoUser();
		}

		return tipoUser;
	}

	public void setTipoUser(TipoUser dog) {
		this.tipoUser = dog;
	}

	public void resetTipoUser() {
		tipoUser = new TipoUser();
	}

	private void reloadUnidadeWithTipoUsers() {
		unidadeWithTipoUsers = getUnidadeFacade().findUnidadeWithAllTipoUsers(unidade.getId());
	}
	
	public void reset(){
		unidade = new Unidade();
	}

	public List<Unidade> getUnidades() {
		return unidades;
	}

	public void setUnidades(List<Unidade> unidades) {
		this.unidades = unidades;
	}

	public DualListModel<TipoUser> getUsuarioModel() {
		return usuarioModel;
	}

	public void setUsuarioModel(DualListModel<TipoUser> usuarioModel) {
		this.usuarioModel = usuarioModel;
	}

	public List<TipoUser> getUsuariosSelecionados() {
		return usuariosSelecionados;
	}

	public void setUsuariosSelecionados(List<TipoUser> usuariosSelecionados) {
		this.usuariosSelecionados = usuariosSelecionados;
	}

	public List<TipoUser> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<TipoUser> usuarios) {
		this.usuarios = usuarios;
	}

	public List<TipoUser> getPerfilUsuarios() {
		return perfilUsuarios;
	}

	public void setPerfilUsuarios(List<TipoUser> perfilUsuarios) {
		this.perfilUsuarios = perfilUsuarios;
	}

	public void setUnidadeWithTipoUsers(Unidade unidadeWithTipoUsers) {
		this.unidadeWithTipoUsers = unidadeWithTipoUsers;
	}

	public void setUnidadeFacade(UnidadeFacade unidadeFacade) {
		this.unidadeFacade = unidadeFacade;
	}
	
	
}