package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.facade.UserSituacaoFacade;
import com.model.UserSituacao;


@ViewScoped
@ManagedBean(name="userSituacaoMB")
public class UserSituacaoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private UserSituacao userSituacao;
	private List<UserSituacao> userSituacaos;
	private UserSituacaoFacade userSituacaoFacade;
	
	public UserSituacaoFacade getUserSituacaoFacade() {
		if (userSituacaoFacade == null) {
			userSituacaoFacade = new UserSituacaoFacade();
		}

		return userSituacaoFacade;
	}

	public UserSituacao getUserSituacao() {
		if (userSituacao == null) {
			userSituacao = new UserSituacao();
		}

		return userSituacao;
	}

	public void setUserSituacao(UserSituacao userSituacao) {
		this.userSituacao = userSituacao;
	}

	public void createUserSituacao() {
		try {
			getUserSituacaoFacade().createUserSituacao(userSituacao);
			closeDialog();
			displayInfoMessageToUser("Created With Sucess");
			loadUserSituacaos();
			resetUserSituacao();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void updateUserSituacao() {
		try {
			getUserSituacaoFacade().updateUserSituacao(userSituacao);
			closeDialog();
			displayInfoMessageToUser("Updated With Sucess");
			loadUserSituacaos();
			resetUserSituacao();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void deleteUserSituacao() {
		try {
			getUserSituacaoFacade().deleteUserSituacao(userSituacao);
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess");
			loadUserSituacaos();
			resetUserSituacao();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public List<UserSituacao> getAllUserSituacaos() {
		if (userSituacaos == null) {
			loadUserSituacaos();
		}

		return userSituacaos;
	}

	private void loadUserSituacaos() {
		userSituacaos = getUserSituacaoFacade().listAll();
	}

	public void resetUserSituacao() {
		userSituacao = new UserSituacao();
	}
	
	
	public List<UserSituacao> completeText(String query) {
        List<UserSituacao> results = new ArrayList<UserSituacao>();
        
        if(userSituacaos == null){
        	userSituacaoFacade = new UserSituacaoFacade();
        	userSituacaos = userSituacaoFacade.listAll();
        }
        
        for (UserSituacao userSituacao : userSituacaos) {
			if (userSituacao.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(userSituacao);
			}
		}
         
        return results;
    }
}