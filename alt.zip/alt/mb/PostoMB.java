package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.facade.PostoFacade;
import com.model.Posto;


@ViewScoped
@ManagedBean(name="postoMB")
public class PostoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;

	private Posto posto;
	private List<Posto> postos;
	private PostoFacade postoFacade;
	
	public PostoFacade getPostoFacade() {
		if (postoFacade == null) {
			postoFacade = new PostoFacade();
		}

		return postoFacade;
	}

	public Posto getPosto() {
		if (posto == null) {
			posto = new Posto();
		}

		return posto;
	}

	public void setPosto(Posto posto) {
		this.posto = posto;
	}

	public void createPosto() {
		try {
			getPostoFacade().createPosto(posto);
			closeDialog();
			displayInfoMessageToUser("Created With Sucess");
			loadPostos();
			resetPosto();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void updatePosto() {
		try {
			getPostoFacade().updatePosto(posto);
			closeDialog();
			displayInfoMessageToUser("Updated With Sucess");
			loadPostos();
			resetPosto();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}
	
	public void deletePosto() {
		try {
			getPostoFacade().deletePosto(posto);
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess");
			loadPostos();
			resetPosto();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser("Ops, we could not create. Try again later");
			e.printStackTrace();
		}
	}

	public List<Posto> getAllPostos() {
		if (postos == null) {
			loadPostos();
		}

		return postos;
	}

	private void loadPostos() {
		postos = getPostoFacade().listAll();
	}

	public void resetPosto() {
		posto = new Posto();
	}
	
	
	public List<Posto> completeText(String query) {
        List<Posto> results = new ArrayList<Posto>();
        
        if(postos == null){
        	postoFacade = new PostoFacade();
        	postos = postoFacade.listAll();
        }
        
        for (Posto posto : postos) {
			if (posto.getDescricao().toLowerCase().contains(query.toLowerCase())) {
				results.add(posto);
			}
		}
         
        return results;
    }
}