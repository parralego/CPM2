package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.defines.TipoFone;
import com.util.Cep;

@SessionScoped
@ManagedBean
public class CepMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	private Cep cep;
	private boolean titular;
	private String[] tipoUserSelecionados;
	private int qtdeQuartos;
	private boolean camposEndReadOnly;
	
	
	public CepMB(){
		camposEndReadOnly = true;
	}
	
	public void buscaCEP(){
		if(cep.buscaCEP())
			camposEndReadOnly = true;
		else
			camposEndReadOnly = false;
	}

	public Cep getCep() {
		if (cep == null) {
			cep = new Cep();
		}

		return cep;
	}

	public void setCep(Cep cep) {
		this.cep = cep;
	}
	public void reset() {
		cep = new Cep();
	}
	public List<String> completeTextTipoUser(String query) {
		List<String> results = new ArrayList<String>();

		results.add("Soldado");
		results.add("Cabo");
		results.add("Coronel");
		results.add("Sargento");
		results.add("Capit�o");

		return results;
	}
	public List<TipoFone> completeTextTipoFone(String query) {
		List<TipoFone> results = new ArrayList<TipoFone>();

		results.add(TipoFone.CELULAR);
		results.add(TipoFone.RESIDENCIAL);
		results.add(TipoFone.COMERCIAL);
		results.add(TipoFone.RECADO);
		results.add(TipoFone.FAX);

		return results;
	}
	
	public void salvar(){
		displayErrorMessageToUser("Dados salvos com sucesso");
	}
	
	public void reset2(){
		displayErrorMessageToUser("Dados descartados");
	}

	public boolean isTitular() {
		return titular;
	}

	public void setTitular(boolean titular) {
		this.titular = titular;
	}

	public String[] getTipoUserSelecionados() {
		return tipoUserSelecionados;
	}

	public void setTipoUserSelecionados(String[] tipoUserSelecionados) {
		this.tipoUserSelecionados = tipoUserSelecionados;
	}

	public int getQtdeQuartos() {
		return qtdeQuartos;
	}

	public void setQtdeQuartos(int qtdeQuartos) {
		this.qtdeQuartos = qtdeQuartos;
	}

	public boolean isCamposEndReadOnly() {
		return camposEndReadOnly;
	}

	public void setCamposEndReadOnly(boolean camposEndReadOnly) {
		this.camposEndReadOnly = camposEndReadOnly;
	}
}
