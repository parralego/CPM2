package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import com.defines.InscricaoStatus;
import com.defines.QuartoStatus;
import com.defines.SorteioStatus;
import com.defines.UserStatus;
import com.facade.InscricaoFacade;
import com.facade.NumSortFacade;
import com.facade.QuartoFacade;
import com.facade.SorteioFacade;
import com.facade.SorteioQuartoFacade;
import com.facade.TipoQuartoFacade;
import com.facade.UserFacade;
import com.model.Agrupamento;
import com.model.Inscricao;
import com.model.NumSort;
import com.model.Quarto;
import com.model.Sorteio;
import com.model.SorteioQuarto;
import com.model.TipoQuarto;
import com.model.Unidade;
import com.model.User;
import com.util.Tools;

@ViewScoped
@ManagedBean
public class SorteioMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	private Sorteio sorteio;
	private User    user;
	private User    userCad;
	private SorteioFacade facade;
	private UserFacade userFacade;
	
	private List<Sorteio> sorteioListGrupo1;
	private List<Sorteio> sorteioListGrupo2;
	
	private List<Sorteio> sorteiosSelecionados;
	private List<Sorteio> sorteiosSelecionados2;
	private Sorteio sorteioSelecionado;
	
	private InscricaoMB		incricaoMB;
	private List<Inscricao> inscricoes;
	
	private String cpfInscricao;
	
	private boolean mostouMsgInscRealizada1 = false;
	private boolean mostouMsgInscRealizada2 = false;
	
	private boolean botaoInsc1 = false;
	private boolean botaoInsc2 = false;
	
	//
	//
	//
	private QuartoFacade quartoFacade;
	private List<Quarto> quartos;
	
	private List<SorteioQuarto> sorteioQuartoList;
	private SorteioQuartoFacade sorteioQuartoFacade;

	private TipoQuartoFacade tipoQuartorFacade;
	private List<TipoQuarto> tipoQuartoList; 
	
	private InscricaoFacade	inscricaoFacade;
	
	private int sortSelecioandoTotalInscritos;
	private List<Agrupamento> sortSelecioandoAgrupInscricoes;
	
	private List<NumSort> numSorts;
	private NumSortFacade numSortFacade;
	//
	//
	//
	
	@PostConstruct
	public void init(){
		setUser(new User());
		
		// Se for USUARIO PADRAO ENTAO ATRIBUI O USUARIO DA SESSAO PARA O USUARIO DA INSCRICAO
		if(tools.getUserSession().isUser()){
			setUser(tools.getUserSession()); 
			cpfInscricao=getUser().getCpf();
			buscaSorteiosByTpUser();
			setAcao(2);
		}
		else{
			setAcao(1);
		}
	}
	
	
	////////
	//TESTE - INICIO
	///////
	public TipoQuartoFacade getTipoQuartorFacade(){
		if(this.tipoQuartorFacade == null) 
			this.tipoQuartorFacade = new TipoQuartoFacade();
		
		return this.tipoQuartorFacade;
	}
	
	public InscricaoFacade getInscricaoFacade(){
		if(this.inscricaoFacade == null) 
			this.inscricaoFacade = new InscricaoFacade();
		
		return this.inscricaoFacade;
	}
	
	
	public QuartoFacade getQuartoFacade(){
		if(quartoFacade == null)
			quartoFacade = new QuartoFacade();
		
		return quartoFacade;
	}
	
	public SorteioQuartoFacade getSorteioQuartoFacade() {
		if (sorteioQuartoFacade == null)
			sorteioQuartoFacade = new SorteioQuartoFacade();

		return sorteioQuartoFacade;
	}
	
	public NumSortFacade getNumSortFacade() {
		if(numSortFacade == null)
			numSortFacade = new NumSortFacade();
		
		return numSortFacade;
	}
	
	
	public List<String> completeTextQuartoStatus() {
        List<String> results = new ArrayList<String>();
        
        results.add(QuartoStatus.ATIVO.toString());
        results.add(QuartoStatus.REFORMA.toString());
        results.add(QuartoStatus.RESERVADO.toString());
        results.add(QuartoStatus.INATIVO.toString());
         
        return results;
    }
	
	
	public void loadTipoQuarto() {
		if(this.tipoQuartoList != null)
			return;
		
		tipoQuartoList = getTipoQuartorFacade().listAll();
		return;
    }
	
	
	public void buscaInscricoes(){
		if(this.sorteioSelecionado == null)
			return;
		
		inscricoes = getInscricaoFacade().findInscricaoBySorteio(sorteioSelecionado.getId());
		if(inscricoes == null){
			tools.msgAviso("N�o existem inscri��es realizadas para esse per�odo");
			return;
		}
		
		this.sortSelecioandoAgrupInscricoes = new ArrayList<Agrupamento>();
		int iBuffer;
		
		sortSelecioandoTotalInscritos = inscricoes.size();
		
		while (!inscricoes.isEmpty()){
			// Armazenar o tamnho atual da lista
			iBuffer = inscricoes.size();
			
			
			Agrupamento agrup = new Agrupamento();
			
			// Armazenar o tipo de usuario
			agrup.setDescricao(inscricoes.get(0).getUser().getTipoQuarto().getTipo());
			
			// Remover todos os registros do tipo de usuario atual
			inscricoes.removeIf(f -> f.getUser().getTipoQuarto() == (inscricoes.get(0).getUser().getTipoQuarto()));
			
			// Setar a quantidade de registros encontrados para o tipo de usuario atual (Tamanho da LIsta Inicial - Tamanho da Lista Atual
			agrup.setCount(iBuffer - inscricoes.size());
			
			sortSelecioandoAgrupInscricoes.add(agrup);
		}
		
		
		return;
	}
	
	//
	// SORTEIO QUARTO - INICIO
	//
	public void listAllQuartoByUnidade(Unidade unidade){
		this.quartos = getQuartoFacade().findQuartoByUnidade(unidade.getId());
		
		this.sorteioQuartoList = new ArrayList<SorteioQuarto>();
		
		SorteioQuarto sorteioQuarto = null;
		for(int i=0; i < this.quartos.size(); i++){
			sorteioQuarto = new SorteioQuarto();
			
			sorteioQuarto.setSorteio(this.sorteioSelecionado);
			sorteioQuarto.setQuarto(this.quartos.get(i));
			sorteioQuarto.setStatus(this.quartos.get(i).getStatus());
			sorteioQuarto.setTipoQuarto(this.quartos.get(i).getTipoQuarto());
			sorteioQuarto.setObs(this.quartos.get(i).getObs());
			this.sorteioQuartoList.add(sorteioQuarto);
		}
	}
	
	public void sorteioQuartosShow(Sorteio sorteio){
		this.sorteioSelecionado = sorteio;
		buscaInscricoes();
		loadTipoQuarto();
		
		this.sorteioQuartoList = getSorteioQuartoFacade().findSorteioQuartoBySorteio(sorteio.getId());
		if(sorteioQuartoList == null || sorteioQuartoList.isEmpty())
			this.acao = 1;
		else{
			this.acao = 3;
		}
	}
	
	public void sorteioQuartosSalvar(){
		if(sorteioQuartoList == null || sorteioQuartoList.isEmpty()){
			tools.msgAviso("Os quartos devem ser cadastrados.");
			keepDialogOpen();
			return;
		}
		
		if(this.sorteioSelecionado.getStatus().equals(SorteioStatus.ABERTO)){
			tools.msgAviso("O sorteio n�o pode estar aberto para cadastrar os quartos");
			keepDialogOpen();
			return;
		}
		
		
		try {
			getSorteioQuartoFacade().createSorteioQuartoList(sorteioQuartoList);
			tools.msgAviso("Quartos salvo com sucesso.");
		} catch (Exception e) {
			tools.msgAviso("Erro ao cadastrar os quartos.");
			return;
		}
		
		return;
	}
	
	public void onRowEdit(RowEditEvent event) {
		 tools.msgAviso("Dados alterado");
	}
	     
   public void onRowCancel(RowEditEvent event) {
   	tools.msgAviso("Alteracao Cancelada");
   }
    
   public void onCellEdit(CellEditEvent event) {
       Object oldValue = event.getOldValue();
       Object newValue = event.getNewValue();
        
       if(newValue != null && !newValue.equals(oldValue)) {
           tools.msgAviso("Valor Alterada de " + oldValue + " para " + newValue);
       }
   }
   
   public List<TipoQuarto> completeTipoQuarto(String query) {
       List<TipoQuarto> results = new ArrayList<TipoQuarto>();
       
       if(tipoQuartoList == null){
			tipoQuartorFacade = new TipoQuartoFacade();
			tipoQuartoList = tipoQuartorFacade.listAll();
       }
       
       for (TipoQuarto tipoUser : tipoQuartoList) {
			if (tipoUser.getTipo().toLowerCase().contains(query.toLowerCase())) {
				results.add(tipoUser);
			}
		}
        
       return results;
   }
	//
	// SORTEIO QUARTO - FINAL
	//
	
	
	
	public void sorteioNumSortShow(Sorteio sorteio){
		this.sorteioSelecionado = sorteio;
		buscaInscricoes();
		
	}
	
	
	////////
	//TESTE - FINAL
	///////
	
	public SorteioFacade getSorteioFacade() {
		if (facade == null) {
			facade = new SorteioFacade();
		}
		return facade;
	}
	
	public UserFacade getUserFacade() {
		if (userFacade == null) {
			userFacade = new UserFacade();
		}
		return userFacade;
	}
	
	public InscricaoMB getInscricaoMB(){
		if(incricaoMB == null)
			incricaoMB = new InscricaoMB();
		return incricaoMB;
	}
	
	public String salvar(int iUnidade){
		if(iUnidade == 1){
			if(sorteiosSelecionados != null && sorteiosSelecionados.size() > 2){
				displayInfoMessageToUser("O n�mero m�ximo de inscri��es para essa col�nia � " + 2);
				return"";
			}
			
			if(sorteiosSelecionados != null && sorteiosSelecionados.isEmpty()){
				displayInfoMessageToUser("Voc� deve selecionar ao menos um per�odo");
				return"";
			}
			
			InscricaoMB inscricaoMB;
			
			for(Sorteio sort : sorteiosSelecionados){
				inscricaoMB = new InscricaoMB();
				
				if(inscricaoMB.salvar(getUser(), sort) == "")
					return "";
			}
			sorteiosSelecionados = new ArrayList<Sorteio>();
			mostouMsgInscRealizada1 = true;
		}
		else{
			if(sorteiosSelecionados2 != null && sorteiosSelecionados2.size() > 1){
				displayInfoMessageToUser("O n�mero m�ximo de inscri��es para essa col�nia � " + 1);
				return"";
			}
			
			if(sorteiosSelecionados2 != null && sorteiosSelecionados2.isEmpty()){
				displayInfoMessageToUser("Voc� deve selecionar ao menos um per�odo");
				return"";
			}
			
			InscricaoMB inscricaoMB;
			
			for(Sorteio sort : sorteiosSelecionados2){
				inscricaoMB = new InscricaoMB();
				
				if(inscricaoMB.salvar(getUser(), sort) == "")
					return "";
			}
			sorteiosSelecionados2 = new ArrayList<Sorteio>();
			mostouMsgInscRealizada2 = true;
		}
		displayInfoMessageToUser("Dados Salvo com sucesso!");
		
		return  "";
	}
	
	public void verInscricoes(Sorteio sorteio){
		if(sorteio == null)
			return;
		
		System.out.println(sorteio.getId());
		inscricoes = getInscricaoMB().listInscricaoBySorteio(sorteio.getId());
	}
	
	
	
	public void encerrarSorteio(Sorteio sorteio){
		if(sorteio == null)
			return;
		
		inscricoes = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		if(inscricoes == null || inscricoes.isEmpty()){
			tools.msgAviso("N�o existem inscri��es realizadas para esse per�odo");
			return;
		}
		
		// Setar o numero do sorteio
		for(int i = 0; i < inscricoes.size(); i++ ){
			if(inscricoes.get(i).getStatus().equals(InscricaoStatus.ATIVO)){
				inscricoes.get(i).setNumSort(i+1);
				inscricoes.get(i).setStatus(InscricaoStatus.ENCERRADO);
			}
		}
		
		try {
			getInscricaoFacade().updateInscricaoList(inscricoes);
		} catch (Exception e) {
			tools.msgAviso("Erro ao atualizar inscri��o.");
			e.printStackTrace();
			return;
		}
		
		try {
			sorteio.setStatus(SorteioStatus.ENCERRADO);
			getSorteioFacade().updateSorteio(sorteio);
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar sorteio para encerrado");
			tools.msgAviso("Erro ao atualizar sorteio.");
			e.printStackTrace();
			return;
		}
		return;
	}
	
		
	public void buscarSocio(){
		
		// SE O CPF NAO MUDOU NAO BUSCA NOVAMENTE
		if(getUser().getCpf() != null && getUser().getCpf().equals(cpfInscricao)){
			return;	// NAO MUDOU O SOCIO
		}
				
		user = getUserFacade().findByEmail(cpfInscricao);
		if(user == null){
			displayErrorMessageToUser("S�cio n�o encontratos");
			return;
		}
		
		userCad = user;
		
		if(user.getStatus().equals(UserStatus.BLOQUEADO)){
			tools.msgAviso("Usu�rio bloqueado, antes de realizar uma incri��o o cadastro do s�cio deve ser ativado");
			setCpfInscricao("000.000.000-00");
			user = null;
			return;
		}
		
		if(user.getStatus().equals(UserStatus.PENDENTE_ATUALIZACAO)){
			tools.msgAviso("Usu�rio desatualizado, antes de realizar uma incri��o o cadastro do s�cio deve ser atualizado");
			setCpfInscricao("000.000.000-00");
			user = null;
			return;
		}
		
		if(user.getStatus().equals(UserStatus.INATIVO)){
			tools.msgAviso("Usu�rio inativo, antes de realizar uma incri��o o cadastro do s�cio deve ser atualizado");
			setCpfInscricao("000.000.000-00");
			user = null;
			return;
		}
		
		buscaSorteiosByTpUser();
	}
	
	public void buscaSorteiosByTpUser(){
		if(getUser().getTipoUser() == null || getUser().getTipoUser().getId()==0)
			return;
		
		sorteioListGrupo1 = getSorteioFacade().findSorteioByTipoUsers(getUser().getTipoUser().getId());
		sorteioListGrupo2 = getSorteioFacade().findSorteioByTipoUsers(getUser().getTipoUser().getId());
		
		sorteioListGrupo1.removeIf(f -> !f.getStatus().equals(SorteioStatus.ABERTO) );
		sorteioListGrupo2.removeIf(f -> !f.getStatus().equals(SorteioStatus.ABERTO) );
		
		
		// Deixa na lista grupo 1 apenas as unidades exclusivas para o tipo de usuario
		sorteioListGrupo1.removeIf(f -> f.getUnidade().getId()>3 );
		
		// Ilha do mel e vila rica
		sorteioListGrupo2.removeIf(f -> f.getUnidade().getId()<=3 );
	}
	
	public List<Sorteio> allByTipoUser(int unidade) {
		// Se o usuario ainda nao foi identificado entao nao procura alista de incricao
		if(getUser().getTipoUser() == null)
			return null;
		
		if(getUser().getTipoUser().getId()==0){
			return null;
		}
		
		List<Sorteio> list;
		try {
			list = getSorteioFacade().findSorteioByTipoUsers(getUser().getTipoUser().getId());
			
			if(list.isEmpty()){
				tools.msgAviso("N�o existe per�odo cadastrado para a patente " + user.getTipoUser());
				return null;
			}
			
			if(unidade==1)
				list.removeIf(f -> f.getUnidade().getId()>3 );
			else
				list.removeIf(f -> f.getUnidade().getId()<=3 );
			
			// Soh selecionar sorteios abertos
			list.removeIf(f -> !f.getStatus().equals(SorteioStatus.ABERTO) );
			
			return list;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;		
	}
	
	public List<Sorteio> allProcessado() {
		List<Sorteio> list;
		try {
			list = getSorteioFacade().listAll();
			
			if(list.isEmpty()){
				tools.msgAviso("N�o existe per�odo cadastrado para a patente " + user.getTipoUser());
				return null;
			}
			// Soh selecionar sorteios abertos
			list.removeIf(f -> !f.getStatus().equals(SorteioStatus.PROCESSADO) );
			
			return list;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;		
	}
	
	
	
	
	public boolean verificaInscricao(User user, int idUnidade){
		if(user == null || user.getCpf() == null)
			return true;
		
		Tools tools = new Tools();
		InscricaoMB inscricaoMB = new InscricaoMB();
		
		List<Inscricao> list = inscricaoMB.allByUser(user);
		
		
		for(Inscricao insc : list){
			// INSCIRCAO NAO ESTIVER CANCELADA
			if(!insc.getStatus().equals(InscricaoStatus.CANCELADO) && insc.getUser().getId()== user.getId())
			{
				if(idUnidade==1){
					if(insc.getSorteio().getUnidade().getId() >= 1 && insc.getSorteio().getUnidade().getId() <= 3){
						if(mostouMsgInscRealizada1==false){
							mostouMsgInscRealizada1 = true;
							displayInfoMessageToUser("Inscri��o j� realizada para a Col�nia de "+ insc.getSorteio().getUnidade().getNome() + " em " + tools.convertDateToString(insc.getDtCad(), "dd/MM/yyyy"));
						}
						botaoInsc1 = false;
						return false;
					}
				}
				
				if(idUnidade==4){
					if(insc.getSorteio().getUnidade().getId() >= 4 && insc.getSorteio().getUnidade().getId() <= 5){
						if(mostouMsgInscRealizada2 == false){
							mostouMsgInscRealizada2 = true;
							displayInfoMessageToUser("Inscri��o j� realizada para a Col�nia de "+ insc.getSorteio().getUnidade().getNome() + " em " + tools.convertDateToString(insc.getDtCad(), "dd/MM/yyyy"));
						}
						botaoInsc2 = false;
						return false;
					}
				}
			}
		}
	
		if(idUnidade==1)
			botaoInsc1 = true;
		else if(idUnidade==4)
			botaoInsc2 = true;
		
		return true;
	}
	
	
	public void sortear(Sorteio sorteio){
		this.sorteioSelecionado = sorteio;
	}
	
	public void reset() {
		sorteio = new Sorteio();
	}
	
	public List<Sorteio> all(){
		return getSorteioFacade().listAll();
	}
	
	
	

	//
	// GETs e SETs
	//
	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<Sorteio> getSorteiosSelecionados() {
		return sorteiosSelecionados;
	}

	public void setSorteiosSelecionados(List<Sorteio> sorteiosSelecionados) {
		this.sorteiosSelecionados = sorteiosSelecionados;
	}

	public List<Sorteio> getSorteiosSelecionados2() {
		return sorteiosSelecionados2;
	}

	public void setSorteiosSelecionados2(List<Sorteio> sorteiosSelecionados2) {
		this.sorteiosSelecionados2 = sorteiosSelecionados2;
	}


	public User getUser() {
		if(user == null)
			return new User();
		
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public boolean isBotaoInsc1() {
		return botaoInsc1;
	}


	public void setBotaoInsc1(boolean botaoInsc1) {
		this.botaoInsc1 = botaoInsc1;
	}


	public boolean isBotaoInsc2() {
		return botaoInsc2;
	}


	public void setBotaoInsc2(boolean botaoInsc2) {
		this.botaoInsc2 = botaoInsc2;
	}


	public String getCpfInscricao() {
		return cpfInscricao;
	}


	public void setCpfInscricao(String cpfInscricao) {
		this.cpfInscricao = cpfInscricao;
	}


	public Sorteio getSorteioSelecionado() {
		return sorteioSelecionado;
	}


	public void setSorteioSelecionado(Sorteio sorteioSelecionado) {
		this.sorteioSelecionado = sorteioSelecionado;
	}


	public List<Inscricao> getInscricoes() {
		return inscricoes;
	}


	public void setInscricoes(List<Inscricao> inscricoes) {
		this.inscricoes = inscricoes;
	}


	public User getUserCad() {
		return userCad;
	}


	public void setUserCad(User userCad) {
		this.userCad = userCad;
	}


	public List<Quarto> getQuartos() {
		return quartos;
	}


	public void setQuartos(List<Quarto> quartos) {
		this.quartos = quartos;
	}


	public int getSortSelecioandoTotalInscritos() {
		return sortSelecioandoTotalInscritos;
	}


	public void setSortSelecioandoTotalInscritos(int sortSelecioandoTotalInscritos) {
		this.sortSelecioandoTotalInscritos = sortSelecioandoTotalInscritos;
	}


	public List<Agrupamento> getSortSelecioandoAgrupInscricoes() {
		return sortSelecioandoAgrupInscricoes;
	}


	public void setSortSelecioandoAgrupInscricoes(List<Agrupamento> sortSelecioandoAgrupInscricoes) {
		this.sortSelecioandoAgrupInscricoes = sortSelecioandoAgrupInscricoes;
	}


	public List<NumSort> getNumSorts() {
		return numSorts;
	}


	public void setNumSorts(List<NumSort> numSorts) {
		this.numSorts = numSorts;
	}


	public void setNumSortFacade(NumSortFacade numSortFacade) {
		this.numSortFacade = numSortFacade;
	}


	public List<SorteioQuarto> getSorteioQuartoList() {
		return sorteioQuartoList;
	}


	public void setSorteioQuartoList(List<SorteioQuarto> sorteioQuartoList) {
		this.sorteioQuartoList = sorteioQuartoList;
	}


	public List<TipoQuarto> getTipoQuartoList() {
		return tipoQuartoList;
	}


	public void setTipoQuartoList(List<TipoQuarto> tipoQuartoList) {
		this.tipoQuartoList = tipoQuartoList;
	}


	public List<Sorteio> getSorteioListGrupo2() {
		return sorteioListGrupo2;
	}


	public void setSorteioListGrupo2(List<Sorteio> sorteioListGrupo2) {
		this.sorteioListGrupo2 = sorteioListGrupo2;
	}


	public List<Sorteio> getSorteioListGrupo1() {
		return sorteioListGrupo1;
	}


	public void setSorteioListGrupo1(List<Sorteio> sorteioListGrupo1) {
		this.sorteioListGrupo1 = sorteioListGrupo1;
	}
	
	
}
