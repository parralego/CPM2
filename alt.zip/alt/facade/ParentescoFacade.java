package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.ParentescoDAO;
import com.model.Parentesco;

public class ParentescoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private ParentescoDAO parentescoDAO = new ParentescoDAO();

	public void createParentesco(Parentesco obj) {
		parentescoDAO.beginTransaction();
		parentescoDAO.save(obj);
		parentescoDAO.commitAndCloseTransaction();
	}

	public void updateParentesco(Parentesco obj) {
		parentescoDAO.beginTransaction();
		Parentesco persistedParentesco = parentescoDAO.find(obj.getId());
		persistedParentesco.setTipo(obj.getTipo());
		parentescoDAO.update(persistedParentesco);
		parentescoDAO.commitAndCloseTransaction();
	}

	public Parentesco findParentesco(int obj) {
		parentescoDAO.beginTransaction();
		Parentesco tipoUser = parentescoDAO.find(obj);
		parentescoDAO.closeTransaction();
		return tipoUser;
	}

	public List<Parentesco> listAll() {
		parentescoDAO.beginTransaction();
		List<Parentesco> result = parentescoDAO.findAll();
		parentescoDAO.closeTransaction();
		return result;
	}

	public void deleteParentesco(Parentesco obj) {
		parentescoDAO.beginTransaction();
		Parentesco persistedParentesco = parentescoDAO.findReferenceOnly(obj.getId());
		parentescoDAO.delete(persistedParentesco);
		parentescoDAO.commitAndCloseTransaction();
	}
}