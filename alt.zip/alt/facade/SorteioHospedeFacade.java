package com.facade;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.dao.SorteioHospedeDAO;
import com.model.SorteioHospede;

public class SorteioHospedeFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private SorteioHospedeDAO objDAO = new SorteioHospedeDAO();
	
	public List<SorteioHospede> findSorteioHospedeBySorteioResultado(int sorteioResultadoId) {
		objDAO.beginTransaction();
		List<SorteioHospede> inscricao = objDAO.findSorteioHospedeBySorteioResultado(sorteioResultadoId);
		objDAO.closeTransaction();
		return inscricao;
	}
	
	public List<SorteioHospede> listAllSorteioHospedeByUser(int userId){
		objDAO.beginTransaction();
		List<SorteioHospede> result = objDAO.findSorteioHospedeByUser(userId);
		objDAO.closeTransaction();
		return result;
	}

	public void create(SorteioHospede obj) {
		objDAO.beginTransaction();
		obj.setDtCad(new Date());
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createList(List<SorteioHospede> list) {
		objDAO.beginTransaction();
		
		for(int i = 0; i < list.size(); i++){
			list.get(i).setDtCad(new Date());
			objDAO.save(list.get(i));
		}
		
		objDAO.commitAndCloseTransaction();
	}

	public void updateSorteioHospede(SorteioHospede obj) {
		objDAO.beginTransaction();
		SorteioHospede persistedSorteioHospede = objDAO.find(obj.getId());
		
		persistedSorteioHospede.setNome(obj.getNome());
		persistedSorteioHospede.setCpf(obj.getCpf());
		persistedSorteioHospede.setRg(obj.getRg());
		persistedSorteioHospede.setSexo(obj.getSexo());
		persistedSorteioHospede.setDtNascimento(obj.getDtNascimento());
		persistedSorteioHospede.setStatus(obj.getStatus());
		persistedSorteioHospede.setDtAlt(new Date());
		persistedSorteioHospede.setStatus(obj.getStatus());
		
		objDAO.update(persistedSorteioHospede);
		objDAO.commitAndCloseTransaction();
	}
	
	public void updateSorteioHospedeList(List<SorteioHospede> list) {
		objDAO.beginTransaction();
		
		for(int i = 0; i < list.size(); i++){
			list.get(i).setDtAlt(new Date());
			objDAO.update(list.get(i));	
		}
		objDAO.commitAndCloseTransaction();
	}

	public SorteioHospede findSorteioHospede(int objId) {
		objDAO.beginTransaction();
		SorteioHospede obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<SorteioHospede> listAll() {
		objDAO.beginTransaction();
		List<SorteioHospede> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteSorteioHospede(SorteioHospede obj) {
		objDAO.beginTransaction();
		SorteioHospede persistedSorteioHospede = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedSorteioHospede);
		objDAO.commitAndCloseTransaction();
	}
}