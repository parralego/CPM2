package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.EstadiaDAO;
import com.model.Estadia;

public class EstadiaFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private EstadiaDAO objDAO = new EstadiaDAO();

	public void createEstadia(Estadia obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateEstadia(Estadia obj) {
		objDAO.beginTransaction();
		Estadia persistedEstadia = objDAO.find(obj.getId());
		
		persistedEstadia.setDtInicio(obj.getDtInicio());
		persistedEstadia.setDtFinal(obj.getDtFinal());
		persistedEstadia.setSorteio(obj.getSorteio());
		
		objDAO.update(persistedEstadia);
		objDAO.commitAndCloseTransaction();
	}

	public Estadia findEstadia(int objId) {
		objDAO.beginTransaction();
		Estadia obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Estadia> listAll() {
		objDAO.beginTransaction();
		List<Estadia> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteEstadia(Estadia obj) {
		objDAO.beginTransaction();
		Estadia persistedEstadia = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedEstadia);
		objDAO.commitAndCloseTransaction();
	}
}