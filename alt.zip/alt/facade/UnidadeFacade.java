package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.TipoUserDAO;
import com.dao.UnidadeDAO;
import com.model.TipoUser;
import com.model.Unidade;

public class UnidadeFacade implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private UnidadeDAO unidadeDAO = new UnidadeDAO();
	private TipoUserDAO tipoUserDAO = new TipoUserDAO();

	public void create(Unidade unidade) {
		unidadeDAO.beginTransaction();
		unidadeDAO.save(unidade);
		unidadeDAO.commitAndCloseTransaction();
	}

	public void update(Unidade obj) {
		unidadeDAO.beginTransaction();
		Unidade persisted = unidadeDAO.find(obj.getId());
		persisted.setNome(obj.getNome());
		persisted.setEmail(obj.getEmail());
		persisted.setTipoFone1(obj.getTipoFone1());
		persisted.setNumFone1(obj.getNumFone1());
		persisted.setTipoFone2(obj.getTipoFone2());
		persisted.setNumFone2(obj.getNumFone2());
		persisted.setCodigoPostal(obj.getCodigoPostal());
		persisted.setLogradouro(obj.getLogradouro());
		persisted.setNumero(obj.getNumero());
		persisted.setComplemento(obj.getComplemento());
		persisted.setBairro(obj.getBairro());
		persisted.setMunicipio(obj.getMunicipio());
		persisted.setUf(obj.getUf());
		unidadeDAO.commitAndCloseTransaction();
	}
	
	public void delete(Unidade unidade){
		unidadeDAO.beginTransaction();
		Unidade persistedUnidadeWithIdOnly = unidadeDAO.findReferenceOnly(unidade.getId());
		unidadeDAO.delete(persistedUnidadeWithIdOnly);
		unidadeDAO.commitAndCloseTransaction();
		
	}

	public Unidade find(int unidadeId) {
		unidadeDAO.beginTransaction();
		Unidade unidade = unidadeDAO.find(unidadeId);
		unidadeDAO.closeTransaction();
		return unidade;
	}

	public List<Unidade> list() {
		unidadeDAO.beginTransaction();
		List<Unidade> result = unidadeDAO.findAll();
		unidadeDAO.closeTransaction();

		return result;
	}

	public Unidade findUnidadeWithAllTipoUsers(int unidadeId) {
		unidadeDAO.beginTransaction();
		Unidade unidade = unidadeDAO.findUnidadeWithAllTipoUser(unidadeId);
		unidadeDAO.closeTransaction();
		return unidade;
	}

	public void addTipoUserToUnidade(int tipoUserId, int unidadeId) {
		unidadeDAO.beginTransaction();
		tipoUserDAO.joinTransaction();
		
		TipoUser tipoUser = tipoUserDAO.find(tipoUserId);
		Unidade  unidade = unidadeDAO.find(unidadeId);
		
		unidade.getTipoUsuarios().add(tipoUser);
		unidadeDAO.commitAndCloseTransaction();
	}

	public void removeTipoUserFromUnidade(int tipoUserId, int unidadeId) {
		unidadeDAO.beginTransaction();
		tipoUserDAO.joinTransaction();
		
		TipoUser tipoUser 	= tipoUserDAO.find(tipoUserId);
		Unidade unidade 	= unidadeDAO.find(unidadeId);
		
		unidade.getTipoUsuarios().remove(tipoUser);
		unidadeDAO.commitAndCloseTransaction();
	}
}