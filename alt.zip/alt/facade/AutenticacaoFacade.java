package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.AutenticacaoDAO;
import com.model.Autenticacao;

public class AutenticacaoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private AutenticacaoDAO objDAO = new AutenticacaoDAO();

	public void createAutenticacao(Autenticacao obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateAutenticacao(Autenticacao obj) {
		objDAO.beginTransaction();
		Autenticacao persistedAutenticacao = objDAO.find(obj.getId());
		
		persistedAutenticacao.setStatus(obj.getStatus());
		persistedAutenticacao.setDtSolicitacao(obj.getDtSolicitacao());
		persistedAutenticacao.setUser(obj.getUser());
		
		objDAO.update(persistedAutenticacao);
		objDAO.commitAndCloseTransaction();
	}

	public Autenticacao findAutenticacao(int objId) {
		objDAO.beginTransaction();
		Autenticacao obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Autenticacao> listAll() {
		objDAO.beginTransaction();
		List<Autenticacao> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteAutenticacao(Autenticacao obj) {
		objDAO.beginTransaction();
		Autenticacao persistedAutenticacao = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedAutenticacao);
		objDAO.commitAndCloseTransaction();
	}
	
	public Autenticacao findByCodigo(String cpf, String codigoAutenticacao) {
		objDAO.beginTransaction();
		Autenticacao obj = objDAO.findByCodigo(cpf, codigoAutenticacao);
		objDAO.closeTransaction();
		return obj;
	}
}