package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.NumSortDAO;
import com.dao.SorteioDAO;
import com.model.NumSort;
import com.model.Sorteio;

public class NumSortFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private NumSortDAO objDAO = new NumSortDAO();
	private SorteioDAO sorteioDAO = new SorteioDAO();
	
	
	public List<NumSort> findNumSortBySorteio(int sorteioId) {
		objDAO.beginTransaction();
		List<NumSort> list = objDAO.findNumSortBySorteio(sorteioId);
		objDAO.closeTransaction();
		return list;
	}

	public void createNumSort(NumSort obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createNumSortList(List<NumSort> list) {
		objDAO.beginTransaction();
		sorteioDAO.joinTransaction();
		
		Sorteio persistedSorteio = sorteioDAO.find(list.get(0).getSorteio().getId());
		
		for(int i = 0; i < list.size(); i++){
//			System.out.println(list.get(i).getId() + "-" + list.get(i).getOrdem() + "-" + list.get(i).getNumero());
			objDAO.save(list.get(i));
		}
		
		persistedSorteio.setNumerosSorteados(list);
		persistedSorteio.setStatus(list.get(0).getSorteio().getStatus());
//		sorteioDAO.update(persistedSorteio);
		
		objDAO.commitAndCloseTransaction();
	}

	public void updateNumSort(NumSort obj) {
		objDAO.beginTransaction();
		NumSort persistedNumSort = objDAO.find(obj.getId());
		
		persistedNumSort.setNumero(obj.getNumero());
		persistedNumSort.setOrdem(obj.getOrdem());
		persistedNumSort.setStatus(obj.getStatus());
		persistedNumSort.setSorteio(obj.getSorteio());
		
		objDAO.update(persistedNumSort);
		objDAO.commitAndCloseTransaction();
	}

	public NumSort findNumSort(int objId) {
		objDAO.beginTransaction();
		NumSort obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<NumSort> listAll() {
		objDAO.beginTransaction();
		List<NumSort> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteNumSort(NumSort obj) {
		objDAO.beginTransaction();
		NumSort persistedNumSort = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedNumSort);
		objDAO.commitAndCloseTransaction();
	}
}