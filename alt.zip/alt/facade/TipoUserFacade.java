package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.TipoUserDAO;
import com.model.TipoUser;

public class TipoUserFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private TipoUserDAO tipoUserDAO = new TipoUserDAO();

	public void createTipoUser(TipoUser tipoUser) {
		tipoUserDAO.beginTransaction();
		tipoUserDAO.save(tipoUser);
		tipoUserDAO.commitAndCloseTransaction();
	}

	public void updateTipoUser(TipoUser tipoUser) {
		tipoUserDAO.beginTransaction();
		TipoUser persistedTipoUser = tipoUserDAO.find(tipoUser.getId());
		persistedTipoUser.setTipo(tipoUser.getTipo());
		tipoUserDAO.update(persistedTipoUser);
		tipoUserDAO.commitAndCloseTransaction();
	}

	public TipoUser findTipoUser(int tipoUserId) {
		tipoUserDAO.beginTransaction();
		TipoUser tipoUser = tipoUserDAO.find(tipoUserId);
		tipoUserDAO.closeTransaction();
		return tipoUser;
	}

	public List<TipoUser> listAll() {
		tipoUserDAO.beginTransaction();
		List<TipoUser> result = tipoUserDAO.findAll();
		tipoUserDAO.closeTransaction();
		return result;
	}

	public void deleteTipoUser(TipoUser tipoUser) {
		tipoUserDAO.beginTransaction();
		TipoUser persistedTipoUser = tipoUserDAO.findReferenceOnly(tipoUser.getId());
		tipoUserDAO.delete(persistedTipoUser);
		tipoUserDAO.commitAndCloseTransaction();
	}
}