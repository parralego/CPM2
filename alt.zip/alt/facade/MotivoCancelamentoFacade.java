package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.MotivoCancelamentoDAO;
import com.model.MotivoCancelamento;

public class MotivoCancelamentoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private MotivoCancelamentoDAO motivoCancelamentoDAO = new MotivoCancelamentoDAO();

	public void createMotivoCancelamento(MotivoCancelamento motivoCancelamento) {
		motivoCancelamentoDAO.beginTransaction();
		motivoCancelamentoDAO.save(motivoCancelamento);
		motivoCancelamentoDAO.commitAndCloseTransaction();
	}

	public void updateMotivoCancelamento(MotivoCancelamento motivoCancelamento) {
		motivoCancelamentoDAO.beginTransaction();
		MotivoCancelamento persistedMotivoCancelamento = motivoCancelamentoDAO.find(motivoCancelamento.getId());
		persistedMotivoCancelamento.setDescricao(motivoCancelamento.getDescricao());
		motivoCancelamentoDAO.update(persistedMotivoCancelamento);
		motivoCancelamentoDAO.commitAndCloseTransaction();
	}

	public MotivoCancelamento findMotivoCancelamento(int motivoCancelamentoId) {
		motivoCancelamentoDAO.beginTransaction();
		MotivoCancelamento motivoCancelamento = motivoCancelamentoDAO.find(motivoCancelamentoId);
		motivoCancelamentoDAO.closeTransaction();
		return motivoCancelamento;
	}

	public List<MotivoCancelamento> listAll() {
		motivoCancelamentoDAO.beginTransaction();
		List<MotivoCancelamento> result = motivoCancelamentoDAO.findAll();
		motivoCancelamentoDAO.closeTransaction();
		return result;
	}

	public void deleteMotivoCancelamento(MotivoCancelamento motivoCancelamento) {
		motivoCancelamentoDAO.beginTransaction();
		MotivoCancelamento persistedMotivoCancelamento = motivoCancelamentoDAO.findReferenceOnly(motivoCancelamento.getId());
		motivoCancelamentoDAO.delete(persistedMotivoCancelamento);
		motivoCancelamentoDAO.commitAndCloseTransaction();
	}
}