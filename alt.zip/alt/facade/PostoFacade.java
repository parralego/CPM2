package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.PostoDAO;
import com.model.Posto;

public class PostoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private PostoDAO objDAO = new PostoDAO();

	public void createPosto(Posto obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updatePosto(Posto obj) {
		objDAO.beginTransaction();
		Posto persistedPosto = objDAO.find(obj.getId());
		persistedPosto.setDescricao(obj.getDescricao());
		persistedPosto.setStatus(obj.getStatus());
		objDAO.update(persistedPosto);
		objDAO.commitAndCloseTransaction();
	}

	public Posto findPosto(int objId) {
		objDAO.beginTransaction();
		Posto obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Posto> listAll() {
		objDAO.beginTransaction();
		List<Posto> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deletePosto(Posto obj) {
		objDAO.beginTransaction();
		Posto persistedPosto = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedPosto);
		objDAO.commitAndCloseTransaction();
	}
}