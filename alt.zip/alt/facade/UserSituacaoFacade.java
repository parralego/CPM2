package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.UserSituacaoDAO;
import com.model.UserSituacao;

public class UserSituacaoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private UserSituacaoDAO objDAO = new UserSituacaoDAO();

	public void createUserSituacao(UserSituacao obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateUserSituacao(UserSituacao obj) {
		objDAO.beginTransaction();
		UserSituacao persistedUserSituacao = objDAO.find(obj.getId());
		persistedUserSituacao.setTipo(obj.getTipo());
		objDAO.update(persistedUserSituacao);
		objDAO.commitAndCloseTransaction();
	}

	public UserSituacao findUserSituacao(int objId) {
		objDAO.beginTransaction();
		UserSituacao obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<UserSituacao> listAll() {
		objDAO.beginTransaction();
		List<UserSituacao> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteUserSituacao(UserSituacao obj) {
		objDAO.beginTransaction();
		UserSituacao persistedUserSituacao = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedUserSituacao);
		objDAO.commitAndCloseTransaction();
	}
}