package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.MeioPgtoDAO;
import com.model.MeioPgto;

public class MeioPgtoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private MeioPgtoDAO objDAO = new MeioPgtoDAO();

	public void createMeioPgto(MeioPgto obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateMeioPgto(MeioPgto obj) {
		objDAO.beginTransaction();
		MeioPgto persistedMeioPgto = objDAO.find(obj.getId());
		persistedMeioPgto.setTipo(obj.getTipo());
		objDAO.update(persistedMeioPgto);
		objDAO.commitAndCloseTransaction();
	}

	public MeioPgto findMeioPgto(int obj) {
		objDAO.beginTransaction();
		MeioPgto tipoUser = objDAO.find(obj);
		objDAO.closeTransaction();
		return tipoUser;
	}

	public List<MeioPgto> listAll() {
		objDAO.beginTransaction();
		List<MeioPgto> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteMeioPgto(MeioPgto obj) {
		objDAO.beginTransaction();
		MeioPgto persistedMeioPgto = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedMeioPgto);
		objDAO.commitAndCloseTransaction();
	}
}