package com.facade;

import java.util.List;

import com.dao.UserDAO;
import com.model.User;

public class UserFacade {
	private UserDAO objDAO = new UserDAO();

	public User isValidLogin(String cpf, String email, String password) {
		objDAO.beginTransaction();
		User user = objDAO.findUserByCpfOrEmail(cpf);
		
		if (user == null || !user.getPassword().equals(password)) {
			return null;
		}

		return user;
	}
	
	public User recuperaEmail(String cpf) {
		objDAO.beginTransaction();
		User user = objDAO.findUserByCpfOrEmail(cpf);		

		return user;
	}
	
	
	public void create(User obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void update(User obj) {
		objDAO.beginTransaction();
		User persisted = objDAO.find(obj.getId());
		persisted.setName(obj.getName());
		persisted.setCpf(obj.getCpf());
		persisted.setEmail(obj.getEmail());
		persisted.setTipoUser(obj.getTipoUser());
		persisted.setRole(obj.getRole());
		persisted.setStatus(obj.getStatus());
		persisted.setRg(obj.getRg());
		persisted.setSexo(obj.getSexo());
		persisted.setUserSituacao(obj.getUserSituacao());
		persisted.setPosto(obj.getPosto());
		persisted.setDtNascimento(obj.getDtNascimento());
		persisted.setTipoFone1(obj.getTipoFone1());
		persisted.setNumFone1(obj.getNumFone1());
		persisted.setTipoFone2(obj.getTipoFone2());
		persisted.setNumFone2(obj.getNumFone2());
		persisted.setCodigoPostal(obj.getCodigoPostal());
		persisted.setLogradouro(obj.getLogradouro());
		persisted.setNumero(obj.getNumero());
		persisted.setComplemento(obj.getComplemento());
		persisted.setBairro(obj.getBairro());
		persisted.setMunicipio(obj.getMunicipio());
		persisted.setUf(obj.getUf());
		
		// Se a senha estiver vazia nao atualizada
		if(!obj.getPassword().isEmpty())
			persisted.setPassword(obj.getPassword());
		
		
		objDAO.update(persisted);
		objDAO.commitAndCloseTransaction();
	}
	
	public void delete(User obj) {
		objDAO.beginTransaction();
		User persisted = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persisted);
		objDAO.commitAndCloseTransaction();
	}

	public User find(int objId) {
		objDAO.beginTransaction();
		User user = objDAO.find(objId);
		objDAO.closeTransaction();
		return user;
	}
	
	public User findByEmail(String email) {
		objDAO.beginTransaction();
		User user = objDAO.findUserByCpfOrEmail(email);
		objDAO.closeTransaction();
		return user;
	}

	public List<User> listAll() {
		objDAO.beginTransaction();
		List<User> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}	
}