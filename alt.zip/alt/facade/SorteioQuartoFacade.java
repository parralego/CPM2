package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.SorteioDAO;
import com.dao.SorteioQuartoDAO;
import com.model.SorteioQuarto;

public class SorteioQuartoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private SorteioQuartoDAO objDAO = new SorteioQuartoDAO();
	private SorteioDAO sorteioDAO = new SorteioDAO();
	
	
	public List<SorteioQuarto> findSorteioQuartoBySorteio(int sorteioId) {
		objDAO.beginTransaction();
		List<SorteioQuarto> list = objDAO.findSorteioQuartoBySorteio(sorteioId);
		objDAO.closeTransaction();
		return list;
	}

	public void createSorteioQuarto(SorteioQuarto obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createSorteioQuartoList(List<SorteioQuarto> list) {
		objDAO.beginTransaction();
		sorteioDAO.joinTransaction();
		
		for(int i = 0; i < list.size(); i++){
			objDAO.save(list.get(i));
		}
		
		objDAO.commitAndCloseTransaction();
	}

	public void updateSorteioQuarto(SorteioQuarto obj) {
		objDAO.beginTransaction();
		
		objDAO.update(obj);
		
		objDAO.commitAndCloseTransaction();
	}
	
	public void updateSorteioQuartoList(List<SorteioQuarto> list) {
		objDAO.beginTransaction();

		for(int i = 0; i < list.size(); i++){
			objDAO.update(list.get(i));	
		}
		objDAO.commitAndCloseTransaction();
	}

	public SorteioQuarto findSorteioQuarto(int objId) {
		objDAO.beginTransaction();
		SorteioQuarto obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<SorteioQuarto> listAll() {
		objDAO.beginTransaction();
		List<SorteioQuarto> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteSorteioQuarto(SorteioQuarto obj) {
		objDAO.beginTransaction();
		SorteioQuarto persistedSorteioQuarto = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedSorteioQuarto);
		objDAO.commitAndCloseTransaction();
	}
}