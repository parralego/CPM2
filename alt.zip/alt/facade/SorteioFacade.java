package com.facade;

import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.dao.TipoUserDAO;
import com.dao.SorteioDAO;
import com.model.TipoUser;
import com.util.Tools;
import com.model.Estadia;
import com.model.Sorteio;

public class SorteioFacade implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private SorteioDAO sorteioDAO = new SorteioDAO();
	private TipoUserDAO tipoUserDAO = new TipoUserDAO();

	public void createSorteio(Sorteio sorteio) {
		sorteioDAO.beginTransaction();
		sorteioDAO.save(sorteio);
		sorteioDAO.commitAndCloseTransaction();
	}

	public void updateSorteio(Sorteio sorteio) {
		sorteioDAO.beginTransaction();
//		Sorteio persistedSorteio = sorteioDAO.find(sorteio.getId());
		
//		persistedSorteio.setDescricao         (sorteio.getDescricao         ());
//		persistedSorteio.setNumDiarias        (sorteio.getNumDiarias        ());
//		persistedSorteio.setEstadia           (sorteio.getEstadia           ());
//		persistedSorteio.setDtSorteio         (sorteio.getDtSorteio         ());
//		persistedSorteio.setDtInicioInscricao (sorteio.getDtInicioInscricao ());
//		persistedSorteio.setDtFinalInscricao  (sorteio.getDtFinalInscricao  ());
//		persistedSorteio.setDtInicioPagamento (sorteio.getDtInicioPagamento ());
//		persistedSorteio.setDtFinalPagamento  (sorteio.getDtFinalPagamento  ());
//		persistedSorteio.setDtInicioSuplente  (sorteio.getDtInicioSuplente  ());
//		persistedSorteio.setDtFinalSumplente  (sorteio.getDtFinalSumplente  ());
//		persistedSorteio.setQtdMaxInscricao   (sorteio.getQtdMaxInscricao   ());
//		persistedSorteio.setUnidade           (sorteio.getUnidade           ());
//		persistedSorteio.setEstadias          (sorteio.getEstadias          ());
//		persistedSorteio.setTipoUsers         (sorteio.getTipoUsers         ());
//		persistedSorteio.setStatus			  (sorteio.getStatus			());
//		persistedSorteio.setNumerosSorteados  (sorteio.getNumerosSorteados  ());	
		
		sorteioDAO.update(sorteio);
		sorteioDAO.commitAndCloseTransaction();
	}
	
	public void deleteSorteio(Sorteio sorteio){
		sorteioDAO.beginTransaction();
		Sorteio persistedSorteioWithIdOnly = sorteioDAO.findReferenceOnly(sorteio.getId());
		sorteioDAO.delete(persistedSorteioWithIdOnly);
		sorteioDAO.commitAndCloseTransaction();
		
	}

	public Sorteio findSorteio(int sorteioId) {
		sorteioDAO.beginTransaction();
		Sorteio sorteio = sorteioDAO.find(sorteioId);
		sorteioDAO.closeTransaction();
		return sorteio;
	}

	public List<Sorteio> listAll() {
		sorteioDAO.beginTransaction();
		List<Sorteio> result = sorteioDAO.findAll();
		sorteioDAO.closeTransaction();

		return result;
	}

	public Sorteio findSorteioWithAllTipoUsers(int sorteioId) {
		sorteioDAO.beginTransaction();
		Sorteio sorteio = sorteioDAO.findSorteioWithAllTipoUsers(sorteioId);
		sorteioDAO.closeTransaction();
		return sorteio;
	}
	
	public List<Sorteio> findSorteioByTipoUsers(int sorteioId) {
		sorteioDAO.beginTransaction();
		List<Sorteio> sorteio = sorteioDAO.findSorteioByTipoUser(sorteioId);
		sorteioDAO.closeTransaction();
		return sorteio;
	}

	public void addTipoUserToSorteio(int tipoUserId, int sorteioId) {
		sorteioDAO.beginTransaction();
		tipoUserDAO.joinTransaction();
		TipoUser tipoUser = tipoUserDAO.find(tipoUserId);
		Sorteio sorteio = sorteioDAO.find(sorteioId);
		sorteio.getTipoUsers().add(tipoUser);
		sorteioDAO.commitAndCloseTransaction();
	}

	public void removeTipoUserFromSorteio(int tipoUserId, int sorteioId) {
		sorteioDAO.beginTransaction();
		tipoUserDAO.joinTransaction();
		TipoUser tipoUser = tipoUserDAO.find(tipoUserId);
		Sorteio sorteio = sorteioDAO.find(sorteioId);
		sorteio.getTipoUsers().remove(tipoUser);
		sorteioDAO.commitAndCloseTransaction();
	}
	
	
	
	public List<Sorteio> listAll3() throws ParseException {
		Tools tools = new Tools();
		List<Sorteio> result 	= new ArrayList<Sorteio>();
		List<Estadia> estadias 	= new ArrayList<Estadia>();
		
		estadias.add(new Estadia(tools.convertStringToDate("20/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("26/12/2016", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("21/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("27/12/2016", "dd/MM/yyyy")));
		Sorteio sort = new Sorteio(1, "1� Per�odo Dezembro - Natal", "periodo01.png", 6, 2, estadias, "(20/12 a 26/12) (21/12 a 27/12)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016","30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("27/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("02/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("28/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("03/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(2, "2� Per�odo Dezembro - Ano Novo", "periodo02.png", 6, 2, estadias, "(27/12 a 02/01) (28/12 a 03/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("03/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("09/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("04/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("10/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(3, "1� Per�odo Janeiro", "periodo03.png", 6, 2, estadias, "(03/01 a 09/01) (04/01 a 10/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		return result;
	}
	
	
	public List<Sorteio> listAll2() throws ParseException {
		Tools tools = new Tools();
		List<Sorteio> result 	= new ArrayList<Sorteio>();
		List<Estadia> estadias 	= new ArrayList<Estadia>();
		
		estadias.add(new Estadia(tools.convertStringToDate("20/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("26/12/2016", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("21/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("27/12/2016", "dd/MM/yyyy")));
		Sorteio sort = new Sorteio(1, "1� Per�odo Dezembro - Natal", "periodo01.png", 6, 2, estadias, "(20/12 a 26/12) (21/12 a 27/12)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016","30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("27/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("02/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("28/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("03/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(2, "2� Per�odo Dezembro - Ano Novo", "periodo02.png", 6, 2, estadias, "(27/12 a 02/01) (28/12 a 03/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("03/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("09/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("04/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("10/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(3, "1� Per�odo Janeiro", "periodo03.png", 6, 2, estadias, "(03/01 a 09/01) (04/01 a 10/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		return result;
	}
	
}