package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.InscricaoDAO;
import com.model.Inscricao;

public class InscricaoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private InscricaoDAO objDAO = new InscricaoDAO();
	
	public List<Inscricao> findInscricaoBySorteio(int sorteioId) {
		objDAO.beginTransaction();
		List<Inscricao> inscricao = objDAO.findInscricaoBySorteio(sorteioId);
		objDAO.closeTransaction();
		return inscricao;
	}
	
	public List<Inscricao> listAllInscricaoByUnidade(int unidadeId, int sorteioId){
		objDAO.beginTransaction();
		List<Inscricao> result = objDAO.findInscricaoByUnidade(unidadeId, sorteioId);
		objDAO.closeTransaction();
		return result;
	}
	
	public List<Inscricao> listAllInscricaoByUser(int userId){
		objDAO.beginTransaction();
		List<Inscricao> result = objDAO.findInscricaoByUser(userId);
		objDAO.closeTransaction();
		return result;
	}

	public void createInscricao(Inscricao obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateInscricao(Inscricao obj) {
		objDAO.beginTransaction();
		Inscricao persistedInscricao = objDAO.find(obj.getId());
		
		persistedInscricao.setDtAlt(obj.getDtAlt());
		persistedInscricao.setUserSessao(obj.getUserSessao());
		persistedInscricao.setStatus(obj.getStatus());
		persistedInscricao.setNumSort(obj.getNumSort());
		
		objDAO.update(persistedInscricao);
		objDAO.commitAndCloseTransaction();
	}
	
	public void updateInscricaoList(List<Inscricao> list) {
		objDAO.beginTransaction();
		
		for(int i = 0; i < list.size(); i++){
			objDAO.update(list.get(i));	
		}
		objDAO.commitAndCloseTransaction();
	}

	public Inscricao findInscricao(int objId) {
		objDAO.beginTransaction();
		Inscricao obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Inscricao> listAll() {
		objDAO.beginTransaction();
		List<Inscricao> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteInscricao(Inscricao obj) {
		objDAO.beginTransaction();
		Inscricao persistedInscricao = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedInscricao);
		objDAO.commitAndCloseTransaction();
	}
}