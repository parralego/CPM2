package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.QuartoDAO;
import com.model.Quarto;

public class QuartoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private QuartoDAO objDAO = new QuartoDAO();
	
	
	public List<Quarto> findQuartoByUnidade(int unidadeId) {
		objDAO.beginTransaction();
		List<Quarto> list = objDAO.findQuartoByUnidade(unidadeId);
		objDAO.closeTransaction();
		return list;
	}

	public void createQuarto(Quarto obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	

	public void updateQuarto(Quarto obj) {
		objDAO.beginTransaction();
		Quarto persistedQuarto = objDAO.find(obj.getId());
		
		persistedQuarto.setBloco(obj.getBloco());
		persistedQuarto.setNome(obj.getNome());
		persistedQuarto.setAndar(obj.getAndar());
		persistedQuarto.setQtdeOcupacao(obj.getQtdeOcupacao());
		persistedQuarto.setStatus(obj.getStatus());
		persistedQuarto.setObs(obj.getObs());
		persistedQuarto.setUnidade(obj.getUnidade());
		persistedQuarto.setTipoQuarto(obj.getTipoQuarto());
		
		objDAO.update(persistedQuarto);
		objDAO.commitAndCloseTransaction();
	}

	public Quarto findQuarto(int objId) {
		objDAO.beginTransaction();
		Quarto obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Quarto> listAll() {
		objDAO.beginTransaction();
		List<Quarto> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteQuarto(Quarto obj) {
		objDAO.beginTransaction();
		Quarto persistedQuarto = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedQuarto);
		objDAO.commitAndCloseTransaction();
	}
}