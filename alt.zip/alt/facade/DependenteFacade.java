package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.DependenteDAO;
import com.model.Dependente;

public class DependenteFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private DependenteDAO objDAO = new DependenteDAO();
	
	
	public List<Dependente> findDependenteByUser(int userId) {
		objDAO.beginTransaction();
		List<Dependente> list = objDAO.findDependenteByUser(userId);
		objDAO.closeTransaction();
		return list;
	}

	public void create(Dependente obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createList(List<Dependente> list) {
		objDAO.beginTransaction();
		for(int i = 0; i < list.size(); i++){
			objDAO.save(list.get(i));
		}
		
		objDAO.commitAndCloseTransaction();
	}
	
	

	public void update(Dependente obj) {
		objDAO.beginTransaction();
		Dependente persistedDependente = objDAO.find(obj.getId());
		
		persistedDependente.setNome(obj.getNome());
		persistedDependente.setDtNascimento(obj.getDtNascimento());
		persistedDependente.setRg(obj.getRg());
		persistedDependente.setCpf(obj.getCpf());
		persistedDependente.setSexo(obj.getSexo());
		persistedDependente.setStatus(obj.getStatus());
		persistedDependente.setDtAlt(obj.getDtAlt());
		
		objDAO.update(persistedDependente);
		objDAO.commitAndCloseTransaction();
	}

	public Dependente findDependente(int objId) {
		objDAO.beginTransaction();
		Dependente obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<Dependente> listAll() {
		objDAO.beginTransaction();
		List<Dependente> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void delete(Dependente obj) {
		objDAO.beginTransaction();
		Dependente persistedDependente = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedDependente);
		objDAO.commitAndCloseTransaction();
	}
}