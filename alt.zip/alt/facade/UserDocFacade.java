package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.UserDocDAO;
import com.model.UserDoc;

public class UserDocFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private UserDocDAO objDAO = new UserDocDAO();
	
	
	public List<UserDoc> findUserDocByUser(int userId) {
		objDAO.beginTransaction();
		List<UserDoc> list = objDAO.findUserDocByUser(userId);
		objDAO.closeTransaction();
		return list;
	}

	public void create(UserDoc obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createUserDocList(List<UserDoc> list) {
		objDAO.beginTransaction();
		for(int i = 0; i < list.size(); i++)
			objDAO.save(list.get(i));
		
		objDAO.commitAndCloseTransaction();
	}

	public void update(UserDoc obj) {
		objDAO.beginTransaction();
		UserDoc persistedUserDoc = objDAO.find(obj.getId());
		
		persistedUserDoc.setNome(obj.getNome());
		persistedUserDoc.setDtAlt(obj.getDtAlt());
		
		objDAO.update(persistedUserDoc);
		objDAO.commitAndCloseTransaction();
	}

	public UserDoc findUserDoc(int objId) {
		objDAO.beginTransaction();
		UserDoc obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<UserDoc> listAll() {
		objDAO.beginTransaction();
		List<UserDoc> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void delete(UserDoc obj) {
		objDAO.beginTransaction();
		UserDoc persistedUserDoc = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedUserDoc);
		objDAO.commitAndCloseTransaction();
	}
}