package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.SorteioResultadoDAO;
import com.model.SorteioResultado;

public class SorteioResultadoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private SorteioResultadoDAO objDAO = new SorteioResultadoDAO();
	
	public List<SorteioResultado> findSorteioResultadoBySorteio(int sorteioId) {
		objDAO.beginTransaction();
		List<SorteioResultado> inscricao = objDAO.findSorteioResultadoBySorteio(sorteioId);
		objDAO.closeTransaction();
		return inscricao;
	}
	
	public List<SorteioResultado> findSorteioResultadoByUnidade(int unidadeId) {
		objDAO.beginTransaction();
		List<SorteioResultado> inscricao = objDAO.findSorteioResultadoByUnidade(unidadeId);
		objDAO.closeTransaction();
		return inscricao;
	}
	
	public List<SorteioResultado> listAllSorteioResultadoByUser(int userId){
		objDAO.beginTransaction();
		List<SorteioResultado> result = objDAO.findSorteioResultadoByUser(userId);
		objDAO.closeTransaction();
		return result;
	}

	public void createSorteioResultado(SorteioResultado obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}
	
	public void createSorteioResultadoList(List<SorteioResultado> list) {
		objDAO.beginTransaction();
		
		for(int i = 0; i < list.size(); i++){
			objDAO.save(list.get(i));
		}
		
		objDAO.commitAndCloseTransaction();
	}

	public void updateSorteioResultado(SorteioResultado obj) {
		objDAO.beginTransaction();
		SorteioResultado persistedSorteioResultado = objDAO.find(obj.getId());
		
		persistedSorteioResultado.setDtAlt(obj.getDtAlt());
		persistedSorteioResultado.setUserSessao(obj.getUserSessao());
		persistedSorteioResultado.setStatus(obj.getStatus());
		persistedSorteioResultado.setMotivoCancel(obj.getMotivoCancel());
		persistedSorteioResultado.setObsCancel(obj.getObsCancel());
		persistedSorteioResultado.setObs(obj.getObs());
		
		objDAO.update(persistedSorteioResultado);
		objDAO.commitAndCloseTransaction();
	}
	
	public void updateSorteioResultadoList(List<SorteioResultado> list) {
		objDAO.beginTransaction();
		
		for(int i = 0; i < list.size(); i++){
			objDAO.update(list.get(i));	
		}
		objDAO.commitAndCloseTransaction();
	}

	public SorteioResultado findSorteioResultado(int objId) {
		objDAO.beginTransaction();
		SorteioResultado obj = objDAO.find(objId);
		objDAO.closeTransaction();
		return obj;
	}

	public List<SorteioResultado> listAll() {
		objDAO.beginTransaction();
		List<SorteioResultado> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteSorteioResultado(SorteioResultado obj) {
		objDAO.beginTransaction();
		SorteioResultado persistedSorteioResultado = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedSorteioResultado);
		objDAO.commitAndCloseTransaction();
	}
}