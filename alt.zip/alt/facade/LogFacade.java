package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.LogDAO;
import com.model.Log;

public class LogFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private LogDAO objDAO = new LogDAO();

	public void createLog(Log obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	// SEM OPCAO DE UPDATE

	public Log findLog(int obj) {
		objDAO.beginTransaction();
		Log tipoUser = objDAO.find(obj);
		objDAO.closeTransaction();
		return tipoUser;
	}

	public List<Log> listAll() {
		objDAO.beginTransaction();
		List<Log> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteLog(Log obj) {
		objDAO.beginTransaction();
		Log persistedLog = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedLog);
		objDAO.commitAndCloseTransaction();
	}
}