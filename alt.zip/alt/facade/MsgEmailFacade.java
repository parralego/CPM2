package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.MsgEmailDAO;
import com.model.MsgEmail;

public class MsgEmailFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private MsgEmailDAO objDAO = new MsgEmailDAO();

	public void create(MsgEmail obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void update(MsgEmail obj) {
		objDAO.beginTransaction();
		MsgEmail persistedMsgEmail = objDAO.find(obj.getId());
		
		persistedMsgEmail.setDescricao	(obj.getDescricao	());
		persistedMsgEmail.setAssunto	(obj.getAssunto		());
		persistedMsgEmail.setTexto		(obj.getTexto		());
		
		objDAO.update(persistedMsgEmail);
		objDAO.commitAndCloseTransaction();
	}

	public MsgEmail find(int obj) {
		objDAO.beginTransaction();
		MsgEmail msgEmail = objDAO.find(obj);
		objDAO.closeTransaction();
		return msgEmail;
	}

	public List<MsgEmail> listAll() {
		objDAO.beginTransaction();
		List<MsgEmail> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void delete(MsgEmail obj) {
		objDAO.beginTransaction();
		MsgEmail persistedMsgEmail = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedMsgEmail);
		objDAO.commitAndCloseTransaction();
	}
}