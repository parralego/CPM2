package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.TipoDocDAO;
import com.model.TipoDoc;

public class TipoDocFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private TipoDocDAO objDAO = new TipoDocDAO();

	public void createTipoDoc(TipoDoc obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateTipoDoc(TipoDoc obj) {
		objDAO.beginTransaction();
		TipoDoc persistedTipoDoc = objDAO.find(obj.getId());
		persistedTipoDoc.setTipo(obj.getTipo());
		objDAO.update(persistedTipoDoc);
		objDAO.commitAndCloseTransaction();
	}

	public TipoDoc findTipoDoc(int obj) {
		objDAO.beginTransaction();
		TipoDoc tipoUser = objDAO.find(obj);
		objDAO.closeTransaction();
		return tipoUser;
	}

	public List<TipoDoc> listAll() {
		objDAO.beginTransaction();
		List<TipoDoc> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteTipoDoc(TipoDoc obj) {
		objDAO.beginTransaction();
		TipoDoc persistedTipoDoc = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedTipoDoc);
		objDAO.commitAndCloseTransaction();
	}
}