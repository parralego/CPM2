package com.facade;

import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.dao.DogDAO;
import com.model.Dog;
import com.model.Estadia;
import com.model.Sorteio;
import com.util.Tools;

public class SorteioFacade2 implements Serializable{
	private static final long serialVersionUID = 1L;
	private DogDAO dogDAO = new DogDAO();

	public void createDog(Dog dog) {
		dogDAO.beginTransaction();
		dogDAO.save(dog);
		dogDAO.commitAndCloseTransaction();
	}

	public void updateDog(Dog dog) {
		dogDAO.beginTransaction();
		Dog persistedDog = dogDAO.find(dog.getId());
		persistedDog.setAge(dog.getAge());
		persistedDog.setName(dog.getName());
		dogDAO.update(persistedDog);
		dogDAO.commitAndCloseTransaction();
	}

	public Dog findDog(int dogId) {
		dogDAO.beginTransaction();
		Dog dog = dogDAO.find(dogId);
		dogDAO.closeTransaction();
		return dog;
	}

	public List<Sorteio> listAll() throws ParseException {
		Tools tools = new Tools();
		List<Sorteio> result 	= new ArrayList<Sorteio>();
		List<Estadia> estadias 	= new ArrayList<Estadia>();
		
		estadias.add(new Estadia(tools.convertStringToDate("20/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("26/12/2016", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("21/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("27/12/2016", "dd/MM/yyyy")));
		Sorteio sort = new Sorteio(1, "1� Per�odo Dezembro - Natal", "periodo01.png", 6, 2, estadias, "(20/12 a 26/12) (21/12 a 27/12)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016","30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("27/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("02/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("28/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("03/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(2, "2� Per�odo Dezembro - Ano Novo", "periodo02.png", 6, 2, estadias, "(27/12 a 02/01) (28/12 a 03/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("03/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("09/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("04/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("10/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(3, "1� Per�odo Janeiro", "periodo03.png", 6, 2, estadias, "(03/01 a 09/01) (04/01 a 10/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		return result;
	}
	
	
	public List<Sorteio> listAll2() throws ParseException {
		Tools tools = new Tools();
		List<Sorteio> result 	= new ArrayList<Sorteio>();
		List<Estadia> estadias 	= new ArrayList<Estadia>();
		
		estadias.add(new Estadia(tools.convertStringToDate("20/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("26/12/2016", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("21/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("27/12/2016", "dd/MM/yyyy")));
		Sorteio sort = new Sorteio(1, "1� Per�odo Dezembro - Natal", "periodo01.png", 6, 2, estadias, "(20/12 a 26/12) (21/12 a 27/12)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016","30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("27/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("02/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("28/12/2016", "dd/MM/yyyy"), tools.convertStringToDate("03/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(2, "2� Per�odo Dezembro - Ano Novo", "periodo02.png", 6, 2, estadias, "(27/12 a 02/01) (28/12 a 03/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		
		estadias 	= new ArrayList<Estadia>();
		estadias.add(new Estadia(tools.convertStringToDate("03/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("09/01/2017", "dd/MM/yyyy")));
		estadias.add(new Estadia(tools.convertStringToDate("04/01/2017", "dd/MM/yyyy"), tools.convertStringToDate("10/01/2017", "dd/MM/yyyy")));
		sort = new Sorteio(3, "1� Per�odo Janeiro", "periodo03.png", 6, 2, estadias, "(03/01 a 09/01) (04/01 a 10/01)", "17/08/2016", "22/08/2016","16/09/2016", "21/09/2016", "30/09/2016");
		result.add(sort);
		return result;
	}

	public void deleteDog(Dog dog) {
		dogDAO.beginTransaction();
		Dog persistedDog = dogDAO.findReferenceOnly(dog.getId());
		dogDAO.delete(persistedDog);
		dogDAO.commitAndCloseTransaction();
	}
}
