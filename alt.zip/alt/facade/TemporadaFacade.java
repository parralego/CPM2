package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.TemporadaDAO;
import com.model.Temporada;

public class TemporadaFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private TemporadaDAO objDAO = new TemporadaDAO();

	public void create(Temporada obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void update(Temporada obj) {
		objDAO.beginTransaction();
		Temporada persistedTemporada = objDAO.find(obj.getId());
		persistedTemporada.setDescricao(obj.getDescricao());
		persistedTemporada.setDtInicio(obj.getDtInicio());
		persistedTemporada.setDtFinal(obj.getDtFinal());
		persistedTemporada.setQtdDiasEstadia(obj.getQtdDiasEstadia());
		persistedTemporada.setStatus(obj.getStatus());
		persistedTemporada.setDtAlt(obj.getDtAlt());
		objDAO.update(persistedTemporada);
		objDAO.commitAndCloseTransaction();
	}

	public Temporada find(int obj) {
		objDAO.beginTransaction();
		Temporada tipoUser = objDAO.find(obj);
		objDAO.closeTransaction();
		return tipoUser;
	}

	public List<Temporada> listAll() {
		objDAO.beginTransaction();
		List<Temporada> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void delete(Temporada obj) {
		objDAO.beginTransaction();
		Temporada persistedTemporada = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedTemporada);
		objDAO.commitAndCloseTransaction();
	}
}