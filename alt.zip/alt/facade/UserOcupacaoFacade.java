package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.UserOcupacaoDAO;
import com.model.UserOcupacao;

public class UserOcupacaoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private UserOcupacaoDAO objDAO = new UserOcupacaoDAO();

	public void createUserOcupacao(UserOcupacao obj) {
		objDAO.beginTransaction();
		objDAO.save(obj);
		objDAO.commitAndCloseTransaction();
	}

	public void updateUserOcupacao(UserOcupacao obj) {
		objDAO.beginTransaction();
		UserOcupacao persistedUserOcupacao = objDAO.find(obj.getId());
		persistedUserOcupacao.setTipo(obj.getTipo());
		objDAO.update(persistedUserOcupacao);
		objDAO.commitAndCloseTransaction();
	}

	public UserOcupacao findUserOcupacao(int id) {
		objDAO.beginTransaction();
		UserOcupacao obj = objDAO.find(id);
		objDAO.closeTransaction();
		return obj;
	}

	public List<UserOcupacao> listAll() {
		objDAO.beginTransaction();
		List<UserOcupacao> result = objDAO.findAll();
		objDAO.closeTransaction();
		return result;
	}

	public void deleteUserOcupacao(UserOcupacao obj) {
		objDAO.beginTransaction();
		UserOcupacao persistedUserOcupacao = objDAO.findReferenceOnly(obj.getId());
		objDAO.delete(persistedUserOcupacao);
		objDAO.commitAndCloseTransaction();
	}
}