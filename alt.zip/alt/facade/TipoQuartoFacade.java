package com.facade;

import java.io.Serializable;
import java.util.List;

import com.dao.TipoQuartoDAO;
import com.model.TipoQuarto;

public class TipoQuartoFacade implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private TipoQuartoDAO tipoQuartoDAO = new TipoQuartoDAO();

	public void createTipoQuarto(TipoQuarto tipoQuarto) {
		tipoQuartoDAO.beginTransaction();
		tipoQuartoDAO.save(tipoQuarto);
		tipoQuartoDAO.commitAndCloseTransaction();
	}

	public void updateTipoQuarto(TipoQuarto tipoQuarto) {
		tipoQuartoDAO.beginTransaction();
		TipoQuarto persistedTipoQuarto = tipoQuartoDAO.find(tipoQuarto.getId());
		persistedTipoQuarto.setTipo(tipoQuarto.getTipo());
		tipoQuartoDAO.update(persistedTipoQuarto);
		tipoQuartoDAO.commitAndCloseTransaction();
	}

	public TipoQuarto findTipoQuarto(int tipoQuartoId) {
		tipoQuartoDAO.beginTransaction();
		TipoQuarto tipoQuarto = tipoQuartoDAO.find(tipoQuartoId);
		tipoQuartoDAO.closeTransaction();
		return tipoQuarto;
	}

	public List<TipoQuarto> listAll() {
		tipoQuartoDAO.beginTransaction();
		List<TipoQuarto> result = tipoQuartoDAO.findAll();
		tipoQuartoDAO.closeTransaction();
		return result;
	}

	public void deleteTipoQuarto(TipoQuarto tipoQuarto) {
		tipoQuartoDAO.beginTransaction();
		TipoQuarto persistedTipoQuarto = tipoQuartoDAO.findReferenceOnly(tipoQuarto.getId());
		tipoQuartoDAO.delete(persistedTipoQuarto);
		tipoQuartoDAO.commitAndCloseTransaction();
	}
}