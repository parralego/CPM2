package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Sorteio;

public class SorteioDAO extends GenericDAO<Sorteio> {

	private static final long serialVersionUID = 1L;
	

	public SorteioDAO() {
		super(Sorteio.class);
	}

	public Sorteio findSorteioWithAllTipoUsers(int sortieoId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sortieoId);

		return super.findOneResult(Sorteio.FIND_SORTEIO_BY_TIPO_USER, parameters);
	}
	
	public List<Sorteio> findSorteioByTipoUser(int tipoUser) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("tipoUserId", tipoUser);

		return super.findAllByQuey(Sorteio.FIND_SORTEIO_BY_TIPO_USER, parameters);
	}
	
	public List<Sorteio> findSorteioByUnidade(int unidadeId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("unidadeId", unidadeId);

		return super.findAllByQuey(Sorteio.FIND_SORTEIO_BY_UNIDADE, parameters);
	}

	public void delete(Sorteio obj) {
        	super.delete(obj.getId(), Sorteio.class);
	}
}
