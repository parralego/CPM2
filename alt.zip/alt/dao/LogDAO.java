package com.dao;

import com.model.Log;

public class LogDAO extends GenericDAO<Log> {

	private static final long serialVersionUID = 1L;

	public LogDAO() {
		super(Log.class);
	}

	public void delete(Log obj) {
		super.delete(obj.getId(), Log.class);
	}

}