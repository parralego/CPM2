package com.dao;

import com.model.MsgEmail;

public class MsgEmailDAO extends GenericDAO<MsgEmail> {

	private static final long serialVersionUID = 1L;

	public MsgEmailDAO() {
		super(MsgEmail.class);
	}

	public void delete(MsgEmail obj) {
		super.delete(obj.getId(), MsgEmail.class);
	}

}