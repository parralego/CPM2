package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Dependente;

public class DependenteDAO extends GenericDAO<Dependente> {

	private static final long serialVersionUID = 1L;
	
	public List<Dependente> findDependenteByUser(int userId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		return super.findAllByQuey(Dependente.FIND_DEPENDENTE_BY_USER, parameters);
	}

	public DependenteDAO() {
		super(Dependente.class);
	}

	public void delete(Dependente obj) {
		super.delete(obj.getId(), Dependente.class);
	}

}