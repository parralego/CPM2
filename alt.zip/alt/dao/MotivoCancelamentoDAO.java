package com.dao;

import com.model.MotivoCancelamento;

public class MotivoCancelamentoDAO extends GenericDAO<MotivoCancelamento> {

	private static final long serialVersionUID = 1L;

	public MotivoCancelamentoDAO() {
		super(MotivoCancelamento.class);
	}

	public void delete(MotivoCancelamento MotivoCancelamento) {
		super.delete(MotivoCancelamento.getId(), MotivoCancelamento.class);
	}

}