package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.SorteioResultado;

public class SorteioResultadoDAO extends GenericDAO<SorteioResultado> {

	private static final long serialVersionUID = 1L;
	
	public List<SorteioResultado> findSorteioResultadoBySorteio(int sorteioId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteioId);

		return super.findAllByQuey(SorteioResultado.FIND_SORTEIORESUTLADO_BY_SORTEIO, parameters);
	}
	
	public List<SorteioResultado> findSorteioResultadoByUnidade(int unidadeId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("unidadeId", unidadeId);

		return super.findAllByQuey(SorteioResultado.FIND_SORTEIORESUTLADO_BY_UNIDADE, parameters);
	}
	
	public List<SorteioResultado> findSorteioResultadoByUser(int userId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		return super.findAllByQuey(SorteioResultado.FIND_SORTEIORESUTLADO_BY_USER, parameters);
	}
	

	public SorteioResultadoDAO() {
		super(SorteioResultado.class);
	}

	public void delete(SorteioResultado obj) {
		super.delete(obj.getId(), SorteioResultado.class);
	}

}