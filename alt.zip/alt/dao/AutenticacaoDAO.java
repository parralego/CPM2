package com.dao;

import java.util.HashMap;
import java.util.Map;

import com.model.Autenticacao;

public class AutenticacaoDAO extends GenericDAO<Autenticacao> {

	private static final long serialVersionUID = 1L;

	public AutenticacaoDAO() {
		super(Autenticacao.class);
	}

	public void delete(Autenticacao obj) {
		super.delete(obj.getId(), Autenticacao.class);
	}
	
	public Autenticacao findByCodigo(String cpf, String codigoAutenticacao){
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("cpf", cpf);
        parameters.put("codigo", codigoAutenticacao);     
 
        return super.findOneResult(Autenticacao.FIND_AUTENTICACAO_BY_CODIGO, parameters);
    }
}