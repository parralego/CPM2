package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.NumSort;

public class NumSortDAO extends GenericDAO<NumSort> {

	private static final long serialVersionUID = 1L;
	
	public List<NumSort> findNumSortBySorteio(int sorteioId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteioId);

		return super.findAllByQuey(NumSort.FIND_NUMSORT_BY_SORTEIO, parameters);
	}
	

	public NumSortDAO() {
		super(NumSort.class);
	}

	public void delete(NumSort obj) {
		super.delete(obj.getId(), NumSort.class);
	}

}