package com.dao;

import com.model.UserSituacao;

public class UserSituacaoDAO extends GenericDAO<UserSituacao> {

	private static final long serialVersionUID = 1L;

	public UserSituacaoDAO() {
		super(UserSituacao.class);
	}

	public void delete(UserSituacao tipoUser) {
		super.delete(tipoUser.getId(), UserSituacao.class);
	}

}