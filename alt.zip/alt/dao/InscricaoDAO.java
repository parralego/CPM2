package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Inscricao;

public class InscricaoDAO extends GenericDAO<Inscricao> {

	private static final long serialVersionUID = 1L;
	
	public List<Inscricao> findInscricaoBySorteio(int sorteioId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteioId);

		return super.findAllByQuey(Inscricao.FIND_INSCRICAO_BY_SORTEIO, parameters);
	}
	
	public List<Inscricao> findInscricaoByUnidade(int unidadeId, int sorteioId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("unidadeId", unidadeId);
		parameters.put("sorteioId", sorteioId);

		return super.findAllByQuey(Inscricao.FIND_INSCRICAO_BY_UNIDADE, parameters);
	}
	
	public List<Inscricao> findInscricaoByUser(int userId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		return super.findAllByQuey(Inscricao.FIND_INSCRICAO_BY_USER, parameters);
	}
	

	public InscricaoDAO() {
		super(Inscricao.class);
	}

	public void delete(Inscricao obj) {
		super.delete(obj.getId(), Inscricao.class);
	}

}