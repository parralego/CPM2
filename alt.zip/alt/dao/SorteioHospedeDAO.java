package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.SorteioHospede;

public class SorteioHospedeDAO extends GenericDAO<SorteioHospede> {

	private static final long serialVersionUID = 1L;
	
	public List<SorteioHospede> findSorteioHospedeBySorteioResultado(int sorteioResultadoId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteioResultadoId);

		return super.findAllByQuey(SorteioHospede.FIND_SORTEIO_HOSPEDE_BY_SORTEIO_RESULTADO, parameters);
	}
	
	public List<SorteioHospede> findSorteioHospedeByUser(int userId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		return super.findAllByQuey(SorteioHospede.FIND_SORTEIO_HOSPEDE_BY_USER, parameters);
	}
	

	public SorteioHospedeDAO() {
		super(SorteioHospede.class);
	}

	public void delete(SorteioHospede obj) {
		super.delete(obj.getId(), SorteioHospede.class);
	}

}