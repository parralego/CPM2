package com.dao;

import com.model.UserOcupacao;

public class UserOcupacaoDAO extends GenericDAO<UserOcupacao> {

	private static final long serialVersionUID = 1L;

	public UserOcupacaoDAO() {
		super(UserOcupacao.class);
	}

	public void delete(UserOcupacao obj) {
		super.delete(obj.getId(), UserOcupacao.class);
	}

}