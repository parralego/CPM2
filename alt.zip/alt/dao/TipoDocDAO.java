package com.dao;

import com.model.TipoDoc;

public class TipoDocDAO extends GenericDAO<TipoDoc> {

	private static final long serialVersionUID = 1L;

	public TipoDocDAO() {
		super(TipoDoc.class);
	}

	public void delete(TipoDoc obj) {
		super.delete(obj.getId(), TipoDoc.class);
	}

}