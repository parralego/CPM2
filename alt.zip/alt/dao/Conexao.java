package com.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.util.Tools;

public class Conexao {

	public static String status = "N�o conectou...";

	public Conexao() {

	}

	public static Connection getConexaoMySQL() {

		Connection connection = null;
		
		Tools tools = new Tools();
		Properties prop = null;
		
		try {
			prop = tools.getProp("email.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String driverName 	= prop.getProperty("conectionDriverName");
		String serverName 	= prop.getProperty("conectionServerName");
		String mydatabase 	= prop.getProperty("conectionDatabase");
		String username 	= prop.getProperty("conectionUserName");      
		String password 	= prop.getProperty("conectionPassword");

		try {
			Class.forName(driverName);
			
			//Configurando a nossa conex�o com um banco de dados//
			String url = "jdbc:mysql://" + serverName + "/" + mydatabase;

			connection = DriverManager.getConnection(url, username, password);

			//Testa sua conex�o
			if (connection != null) {
				status = ("STATUS--->Conectado com sucesso!");
			} else {
				status = ("STATUS--->N�o foi possivel realizar conex�o");
			}
			return connection;



		} catch (ClassNotFoundException e) {  //Driver n�o encontrado
			System.out.println("O driver expecificado nao foi encontrado.");
			return null;

		} catch (SQLException e) {

			//N�o conseguindo se conectar ao banco
			System.out.println("Nao foi possivel conectar ao Banco de Dados.");
			return null;

		}
	}



	//M�todo que retorna o status da sua conex�o//

	public static String statusConection() {

		return status;

	}



	//M�todo que fecha sua conex�o//
	public static boolean FecharConexao() {

		try {
			Conexao.getConexaoMySQL().close();
			return true;
		} catch (SQLException e) {
			return false;
		}
	}

	//M�todo que reinicia sua conex�o//
	public static Connection ReiniciarConexao() {
		FecharConexao();
		return Conexao.getConexaoMySQL();
	}
}
