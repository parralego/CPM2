package com.dao;

import com.model.TipoUser;

public class TipoUserDAO extends GenericDAO<TipoUser> {

	private static final long serialVersionUID = 1L;

	public TipoUserDAO() {
		super(TipoUser.class);
	}

	public void delete(TipoUser tipoUser) {
		super.delete(tipoUser.getId(), TipoUser.class);
	}

}