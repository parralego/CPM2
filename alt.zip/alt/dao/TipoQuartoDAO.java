package com.dao;

import com.model.TipoQuarto;

public class TipoQuartoDAO extends GenericDAO<TipoQuarto> {

	private static final long serialVersionUID = 1L;

	public TipoQuartoDAO() {
		super(TipoQuarto.class);
	}

	public void delete(TipoQuarto tipoQuarto) {
		super.delete(tipoQuarto.getId(), TipoQuarto.class);
	}

}