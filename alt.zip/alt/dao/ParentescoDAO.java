package com.dao;

import com.model.Parentesco;

public class ParentescoDAO extends GenericDAO<Parentesco> {

	private static final long serialVersionUID = 1L;

	public ParentescoDAO() {
		super(Parentesco.class);
	}

	public void delete(Parentesco parentesco) {
		super.delete(parentesco.getId(), Parentesco.class);
	}

}