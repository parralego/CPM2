package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Quarto;

public class QuartoDAO extends GenericDAO<Quarto> {

	private static final long serialVersionUID = 1L;
	
	public List<Quarto> findQuartoByUnidade(int unidadeId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("unidadeId", unidadeId);

		return super.findAllByQuey(Quarto.FIND_QUARTO_BY_UNIDADE, parameters);
	}

	public QuartoDAO() {
		super(Quarto.class);
	}

	public void delete(Quarto obj) {
		super.delete(obj.getId(), Quarto.class);
	}

}