package com.dao;

import com.model.MeioPgto;

public class MeioPgtoDAO extends GenericDAO<MeioPgto> {

	private static final long serialVersionUID = 1L;

	public MeioPgtoDAO() {
		super(MeioPgto.class);
	}

	public void delete(MeioPgto obj) {
		super.delete(obj.getId(), MeioPgto.class);
	}

}