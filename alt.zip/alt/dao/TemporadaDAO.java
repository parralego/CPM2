package com.dao;

import com.model.Temporada;

public class TemporadaDAO extends GenericDAO<Temporada> {

	private static final long serialVersionUID = 1L;

	public TemporadaDAO() {
		super(Temporada.class);
	}

	public void delete(Temporada obj) {
		super.delete(obj.getId(), Temporada.class);
	}

}