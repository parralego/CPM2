package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.UserDoc;

public class UserDocDAO extends GenericDAO<UserDoc> {

	private static final long serialVersionUID = 1L;
	
	public List<UserDoc> findUserDocByUser(int userId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		return super.findAllByQuey(UserDoc.FIND_USER_DOC_BY_USER, parameters);
	}

	public UserDocDAO() {
		super(UserDoc.class);
	}

	public void delete(UserDoc obj) {
		super.delete(obj.getId(), UserDoc.class);
	}

}