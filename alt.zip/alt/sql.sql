UPDATE JSFCRUDDB.USERS SET dtCad = "20161001" WHERE id > 0

INSERT INTO JSFCRUDDB.PARENTESCO VALUES (1, "C�NJUGE");
INSERT INTO JSFCRUDDB.PARENTESCO VALUES (2, "FILHOS");



INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (1, "Certid�o de Casamento");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (2, "Certid�o de Nascimento");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (3, "Certid�o de �bito");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (4, "Comprovante de Filia��o");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (5, "Contrato de Uni�o Est�vel");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (6, "Contra-Cheque");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (7, "Comprovante de Resid�ncia");
INSERT INTO JSFCRUDDB.TIPO_DOC VALUES (99, "Outros");




ALTER TABLE `jsfcruddb`.`user_doc` 
CHANGE COLUMN `imagem` `imagem` LONGBLOB NULL DEFAULT NULL ;


ALTER TABLE `jsfcruddb`.`msg_email` 
CHANGE COLUMN `texto` `texto` VARCHAR(4096) NULL DEFAULT NULL ;



INSERT INTO jsfcruddb.msg_email (id, assunto, descricao, texto, user_sessao_id, dtCad)
VALUES( 1
	  , "Carteirinhas para uso na Col�nia de F�rias"
	  , "Mensagem padr�o para envio de carteirinhas"
	  , '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Prezados S�cio,</span></font><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Segue em anexo a(s) carteirinha(s) para uso na Col�nia de F�rias.<span style="color: rgb(255, 0, 0);"> � obrigat�rio o uso no per�odo de hospedagem na col�nia de f�rias.</span></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Atenciosamente</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><span style="font-weight: bold; color: rgb(255, 0, 0);">AVM </span>- <span style="font-weight: bold;">Departamento de Col�nia de F�rias</span></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">(41) 3333-3333 ou (41) 2222-2222</span></font></div><div><a href="http://avmpmpr.com.br/site/">www.avmpmpr.gov.br</a></div><div><br></div><div><br></div>'
	  , 1
	  , sysdate());
	  
INSERT INTO jsfcruddb.msg_email (id, assunto, descricao, texto, user_sessao_id, dtCad)
VALUES( 2
	  , "Pend�ncias na Solicita��o de Credenciamento"
	  , "Mensagem Padr�o - An�lise de Novos S�cios"
	  , '<div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Prezado,</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">O departamento de cadastro da AVM est� processando seu pedido de credenciamento para se tornar um s�cio da AVM, mas para dar continuidade a esse processo precisamos dos seguintes itens:</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><ol><li><span style="font-weight: bold;">Certidao de Casamento</span></li><li><span style="font-weight: bold;">Certidao de Nascimento</span></li></ol></div><div><br></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Aguardamos um retorno o mais breve poss�vel</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Atenciosamente</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px; font-weight: bold;"><span style="color: rgb(255, 0, 0);">AVM </span>- Departamento de Cadastro</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">(41) 3333-3333 ou (41) 2222-2222</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><a href="http://avmpmpr.com.br/site/">www.avmpmpr.com.br</a></span></font></div>'
	  , 1
	  , sysdate());
	  
	  
	  

	  DELETE FROM JSFCRUDDB.DEPENDENTE WHERE parentesco_id = 3
DELETE FROM JSFCRUDDB.PARENTESCO WHERE id = 3 
