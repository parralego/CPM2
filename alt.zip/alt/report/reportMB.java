package com.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.dao.Conexao;
import com.facade.QuartoFacade;
import com.facade.SorteioFacade;
import com.mb.AbstractMB;
import com.model.Sorteio;
import com.util.Email;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

@ViewScoped
@ManagedBean
public class reportMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Sorteio 		sorteio;
	private List<Sorteio>	sorteioList;
	private SorteioFacade 	sorteioFacade;
	
	@PostConstruct
	public void init(){
		this.acao = 1;
	}
	
	public void print2(){
		Map<String, Object> parameters = new HashMap<String, Object>();
//		parameters.put("sorteioId", sorteio.getId());
		parameters.put("sorteioId", 1);
		
		try {
			JasperPrint jsPrint = JasperFillManager.fillReport("/src/report/RelatorioResultadoSorteio.jasper", parameters);
			JasperViewer jsView = new JasperViewer(jsPrint, false );
			jsView.setVisible(true);
			jsView.toFront();
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void print3() throws JRException{
		QuartoFacade quartoFacade = new QuartoFacade();
		
		String atualDir = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/";
		
		JasperReport pathjrxml = JasperCompileManager.compileReport(atualDir+"teste.jrxml");
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, null, new JRBeanCollectionDataSource(quartoFacade.listAll(), false));
		JasperExportManager.exportReportToPdfFile(printReport, atualDir+"yess.pdf");
		System.out.println("Relatorio gerado");
	}
	
	
	public void gerarRelatQtdeInscBySortPint() throws JRException{
		String atualDir = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/";
		
		JasperReport pathjrxml = JasperCompileManager.compileReport(atualDir+"InscricoesByUnidadeAndPeriodo.jrxml");
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, null, Conexao.getConexaoMySQL());
//		JasperExportManager.exportReportToPdfFile(printReport, atualDir+"InscricoesByUnidadeAndPeriodo.pdf");
		JasperViewer jsView = new JasperViewer(printReport);
		jsView.setVisible(true);
		jsView.toFront();
		System.out.println("Relatorio gerado");
		System.out.println("Relatorio gerado");
	}
	
	public void gerarRelatQtdeInscBySort() throws JRException{
		String nomeRelat = "InscricoesByUnidadeAndPeriodo"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";
				
		JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, null, Conexao.getConexaoMySQL());
		JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		
		Email email = new Email();
		
		email.sendEmailAvisoSorteio(nomeArquivoAnexo, null, tools.getUserSession());
		
		tools.msgAviso("O relat�rio foi enviado pro seu email.");
	}
	
	
	public void gerarRelatAllInscricaoByUser() throws JRException{
		String nomeRelat = "InscricoesByUser"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";
				
		JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, null, Conexao.getConexaoMySQL());
		JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		
		Email email = new Email();
		
		email.sendEmailAvisoSorteio(nomeArquivoAnexo, null, tools.getUserSession());
		
		tools.msgAviso("O relat�rio foi enviado pro seu email.");
	}
	
	
	public void enviarEmailResultSorteio() throws JRException{
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteio.getId());
		
		String nomeRelat = "RelatorioResultadoSorteioRetrato"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";
				
		JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
		JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		
		Email email = new Email();
		
		email.sendEmailAvisoSorteio(nomeArquivoAnexo, null, tools.getUserSession());
		
		tools.msgAviso("O relat�rio foi enviado pro seu email.");
	}
	
	public List<Sorteio> completeTextSorteio(String query) {
        List<Sorteio> results = new ArrayList<Sorteio>();
        
        if(sorteioList == null){
        	sorteioList = getSorteioFacade().listAll();
        }
        
        for (Sorteio sorteio : sorteioList) {
			if (sorteio.getDescricao().toLowerCase().contains(query.toLowerCase())) {
				results.add(sorteio);
			}
		}
         
        return results;
    }
	
	public SorteioFacade getSorteioFacade() {
		if (sorteioFacade == null) {
			sorteioFacade = new SorteioFacade();
		}

		return sorteioFacade;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<Sorteio> getSorteioList() {
		return sorteioList;
	}

	public void setSorteioList(List<Sorteio> sorteioList) {
		this.sorteioList = sorteioList;
	}

}
