package com.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import com.dao.Conexao;
import com.facade.MsgEmailFacade;
import com.facade.SorteioFacade;
import com.facade.UnidadeFacade;
import com.mb.AbstractMB;
import com.model.MsgEmail;
import com.model.Sorteio;
import com.model.Unidade;
import com.util.Email;
import com.util.Report;
import com.util.ReportFild;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@SessionScoped
@ManagedBean
public class reportMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final int REPORT_QUARTO_LIVRE				= 1;
	public static final int REPORT_QUARTO_ALOCADO 			= 2;
	public static final int REPORT_RESULT_SORTEIO 			= 3;
	public static final int REPORT_RESULT_SORTEIO_SUP 		= 4;
	public static final int REPORT_RESULT_SORTEIO_SUP_SORT	= 5;
	public static final int REPORT_INSCRICAO				= 6;
	public static final int REPORT_SORTEIO					= 7;
	
	private String			nomeRelat;
	private String 			nomeArqRelat;
	private String 			nomeArquivoAnexo;
	private String 			nomeArquivoAssuntoEmail;
	
	private Sorteio 		sorteio;
	private List<Sorteio>	sorteioList;
	private SorteioFacade 	sorteioFacade;
	private boolean 		comboSorteioDisabled;
	private boolean         sorteioListSetOpcaoTodas;
	
	private Unidade 		unidade;
	private List<Unidade>	unidadeList;
	private UnidadeFacade 	unidadeFacade;
	private boolean 		comboUnidadeDisabled;
	private boolean         unidadeListSetOpcaoTodas;
	
	
	private boolean 		botaoEmailVisible;
	private boolean			semParametro;
	
	private Report			report;
	
	private String			unidadeLabel;
	private boolean 		unidadeVisible;
	private boolean 		unidadeObrigatorio;
	
	
	private String 			sorteioLabel;
	private boolean 		sorteioVisible;
	private boolean 		sorteioObrigatorio;
	
	@PostConstruct
	public void init(){
		this.unidade = new Unidade();
		this.sorteio = new Sorteio();
//		unidadeList = getUnidadeFacade().list();
		
		this.acao = 1;
		comboUnidadeDisabled = false;
		comboSorteioDisabled = true;
		semParametro		 = false;
		
		sorteioListSetOpcaoTodas = false;
		unidadeListSetOpcaoTodas = false;
		
		unidadeVisible	= false;
		sorteioVisible	= false;
		
		if(tools.getUserSession().getEmail().isEmpty())
			botaoEmailVisible = false;
		else
			botaoEmailVisible = true;
	}
	
	/****************************************************************************************************
	 * Nome.....: show(int iReportCodigo)
	 * Descricao: Implementar as configura��es de cada relatorio tratado na tela de gelatorio generico  
	 * Criacao..: Cl�udio Parralego  
	 * Data.....: 17/11/2016
	 ****************************************************************************************************/
	public void show(int iReportCodigo){
		report = new Report();
		List<ReportFild> campos = new ArrayList<>();
		
		
		switch (iReportCodigo) {
			case REPORT_QUARTO_LIVRE:
				report.setId(REPORT_QUARTO_LIVRE);
				report.setNome("Relat�rio de Quartos Livres");
				report.setAssuntoEmail("Quartos Livres");
				report.setNomeArqJasper("RelatorioQuartosLivres");
				
				campos.add(new ReportFild("Unidade", null		, true, this.unidade));
				campos.add(new ReportFild("Sorteio", "sorteioId", true, this.sorteio));
				report.setCampoList(campos);
				break;
			
			case REPORT_QUARTO_ALOCADO:
				report.setId(REPORT_QUARTO_ALOCADO);
				report.setNome("Relat�rio de Quartos Alocados");
				report.setAssuntoEmail("Quartos Alocados");
				report.setNomeArqJasper("RelatorioQuartosAlocados");

				campos.add(new ReportFild("Unidade", null		, true, this.unidade));
				campos.add(new ReportFild("Sorteio", "sorteioId", true, this.sorteio));
				report.setCampoList(campos);
				break;
			
			case REPORT_RESULT_SORTEIO:
				report.setId(REPORT_RESULT_SORTEIO);
				report.setNome("Relat�rio de Resultado de Sorteio");
				report.setAssuntoEmail("Resultado de Sorteio");
				report.setNomeArqJasper("RelatorioResultadoSorteioRetrato");

				campos.add(new ReportFild("Unidade", null		, true, this.unidade));
				campos.add(new ReportFild("Sorteio", "sorteioId", true, this.sorteio));
				report.setCampoList(campos);
				break;
				
			case REPORT_RESULT_SORTEIO_SUP:
				report.setId(REPORT_RESULT_SORTEIO_SUP);
				report.setNome("Relat�rio de Resultado de Sorteio - Suplentes");
				report.setAssuntoEmail("Resultado de Sorteio - Suplentes");
				report.setNomeArqJasper("RelatorioResultadoSorteioSuplente");

				campos.add(new ReportFild("Unidade", null		, true, this.unidade));
				campos.add(new ReportFild("Sorteio", "sorteioId", true, this.sorteio));
				report.setCampoList(campos);
				break;
				
			case REPORT_RESULT_SORTEIO_SUP_SORT:
				report.setId(REPORT_RESULT_SORTEIO_SUP_SORT);
				report.setNome("Relat�rio de Resultado de Sorteio - Suplentes Sorteados");
				report.setAssuntoEmail("Resultado de Sorteio - Suplentes Sorteados");
				report.setNomeArqJasper("RelatorioResultadoSorteio2");

				campos.add(new ReportFild("Unidade", null		, true, this.unidade));
				campos.add(new ReportFild("Sorteio", "sorteioId", true, this.sorteio));
				report.setCampoList(campos);
				break;
				
			case REPORT_INSCRICAO:
				report.setId(REPORT_INSCRICAO);
				report.setNome("Relat�rio Inscri��es por S�cios");
				report.setAssuntoEmail("Inscri��es por S�cios");
				report.setNomeArqJasper("InscricoesByUser");
				report.setCampoList(null);
				break;
			
			case REPORT_SORTEIO:
				report.setId(REPORT_SORTEIO);
				report.setNome("Relat�rio Inscri��es por Sorteio");
				report.setAssuntoEmail("Inscri��es por Sorteio");
				report.setNomeArqJasper("InscricoesByUnidadeAndPeriodo");
				report.setCampoList(null);
				break;
				
			default:
				break;
		}
		
		if(report.getCampoList() == null)
			semParametro = true;
		else
			semParametro = false;
		
		setCampos();
		
		return;
	}
	
	
	/****************************************************************************************************
	 * Nome.....: setCampos()
	 * Descricao: Configurar os filtros da tela de relatorio generico de acordo com as configura��es 
	 *            passadas para o relatorio no metodo show  
	 * Criacao..: Cl�udio Parralego  
	 * Data.....: 17/11/2016
	 ****************************************************************************************************/
	public void setCampos(){
		// Inicializa variaveis
		unidadeVisible 		= false;
		sorteioVisible 		= false;
		
		// Se o relatorio nao tiver filtros jah retorna
		if(report.getCampoList() == null)
			return;
		
		for(ReportFild campo: report.getCampoList()){
			if(campo.getCampo().getClass().equals(Unidade.class)){
				unidadeLabel 		= campo.getLabel();
				unidadeVisible 		= true;
				unidadeObrigatorio	= campo.isObrigatorio();
				unidade				= new Unidade();
			}
			else if(campo.getCampo().getClass().equals(Sorteio.class)){
				sorteioLabel		= campo.getLabel();
				sorteioVisible 		= true;
				sorteioObrigatorio	= campo.isObrigatorio();
				sorteio				= new Sorteio();
			}
			else{
				tools.msgErro("O campo");
				
			}
		}
	}
	
	/****************************************************************************************************
	 * Nome.....: validar()
	 * Descricao: Validar se os filtros obrigatorios foram peenchidos  
	 * Criacao..: Cl�udio Parralego  
	 * Data.....: 17/11/2016
	 ****************************************************************************************************/
	public boolean validar(){
		if (unidadeObrigatorio && (unidade == null)){
			tools.msgAviso("O campo unidade � obrigat�rio");
			return false;
		}
		
		if (sorteioObrigatorio && (sorteio == null)){
			tools.msgAviso("O campo sorteio � obrigat�rio");
			return false;
		}
		
		return true;
	}
	
	/****************************************************************************************************
	 * Nome.....: reportGerar()
	 * Descricao: Gerar os relatorio em um PDF que serah apresentando em uma tela padrao  
	 * Criacao..: Cl�udio Parralego  
	 * Data.....: 17/11/2016
	 ****************************************************************************************************/
	public void reportGerar(){
		if(!validar())
			return;
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		
		switch (report.getId()) {
			case REPORT_QUARTO_LIVRE:
			case REPORT_QUARTO_ALOCADO:
			case REPORT_RESULT_SORTEIO:
			case REPORT_RESULT_SORTEIO_SUP:
			case REPORT_RESULT_SORTEIO_SUP_SORT:
				parameters.put("sorteioId", sorteio.getId());
			break;
	
			default:
				break;
		}
		
		this.nomeArquivoAssuntoEmail = report.getAssuntoEmail();
		
		this.nomeRelat 			= report.getNomeArqJasper();
		this.nomeArqRelat 		= FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" + nomeRelat + ".jrxml";
		this.nomeArquivoAnexo 	= FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "resources/demo/reportResult.pdf";
				
		try {
			JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
			JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
			JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		} catch (JRException e) {
			tools.msgErro("Erro ao gerar o relatorio!");
			e.printStackTrace();
		}
	}
	
	/****************************************************************************************************
	 * Nome.....: enviarEmail()
	 * Descricao: Enviar o relatoro gerado por email para o usuario logado  
	 * Criacao..: Cl�udio Parralego  
	 * Data.....: 17/11/2016
	 ****************************************************************************************************/
	public void enviarEmail(){
		MsgEmailFacade msgEmailFacede = new MsgEmailFacade();
		MsgEmail msgEmail = msgEmailFacede.find(MsgEmail.MSG_PADRAO_REPORT);
		
		if(msgEmail == null){
			tools.msgErro("Erro ao recuperar mensagem padrao de email.");
			return;
		}
		
		Email email = new Email();
		String assuntoEmail = tools.sprintf("%0! - %1! ", Arrays.asList(msgEmail.getAssunto(), this.nomeArquivoAssuntoEmail)); 
		
		
		 
		if(!email.sendHtmlEmailWithAnexo(assuntoEmail, msgEmail.getTexto(), this.nomeArquivoAnexo, tools.getUserSession())){
			tools.msgErro("ERRO ao enviar email.");
			return;
		}
		
		tools.msgAviso("Email Enviado com sucesso.");
	}
	
	
	
	public void reportQuartoAlocado(){
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteio.getId());
		
		this.nomeArquivoAssuntoEmail = "Quartos Livres";
		
		this.nomeRelat 			= "RelatorioQuartosAlocados"; 
		this.nomeArqRelat 		= FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" + nomeRelat + ".jrxml";
		this.nomeArquivoAnexo 	= FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "resources/demo/reportResult.pdf";
				
		try {
			JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
			JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
			JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		} catch (JRException e) {
			tools.msgErro("Erro ao gerar o relatorio!");
			e.printStackTrace();
		}
	}
	
	public void showSorteioResultado(){
		unidadeList = getUnidadeFacade().list();
		
		comboUnidadeDisabled = false;
		comboSorteioDisabled = true;
		sorteioListSetOpcaoTodas = true;
		unidadeListSetOpcaoTodas = false;
		
	}
	
	
	public List<Sorteio> completeTextSorteioByUnidade(String query) {
        List<Sorteio> results = new ArrayList<Sorteio>();
        
        if(sorteioList == null){
        	sorteioList = getSorteioFacade().listAll();
        }
        
        if(sorteioListSetOpcaoTodas){
	        sorteio.setId(0);
	        sorteio.setDescricao("Todos");
	        results.add(sorteio);
        }
        
        for (Sorteio sorteio : sorteioList) {
			if (sorteio.getDescricao().toLowerCase().contains(query.toLowerCase())) {
				results.add(sorteio);
			}
		}
         
        return results;
    }
	
	public List<Unidade> completeTextUnidade(String query) {
        List<Unidade> results = new ArrayList<Unidade>();
        
        if(unidadeList == null){
        	unidadeList = getUnidadeFacade().list();
        }
        
        if(unidadeListSetOpcaoTodas){
	        unidade.setId(0);
	        unidade.setNome("Todas");
	        results.add(unidade);
        }
        
        for (Unidade unidade : unidadeList) {
			if (unidade.getNome().toLowerCase().contains(query.toLowerCase())) {
				results.add(unidade);
			}
		}
         
        return results;
    }
	
	
	public void carregarSorteio(){
		if(this.unidade == null)
			return ;
		
        sorteioList = getSorteioFacade().findSorteioByUnidade(this.unidade.getId());
		comboSorteioDisabled = false;
	}
	
	
	
	//
	// GETs and SETs
	//
	public SorteioFacade getSorteioFacade() {
		if (sorteioFacade == null) {
			sorteioFacade = new SorteioFacade();
		}

		return sorteioFacade;
	}
	
	public UnidadeFacade getUnidadeFacade() {
		if (unidadeFacade == null) {
			unidadeFacade = new UnidadeFacade();
		}

		return unidadeFacade;
	}

	public Sorteio getSorteio() {
		if(comboSorteioDisabled)
			return null;
		
		if(sorteioList == null || sorteioList.isEmpty()){
			if(this.unidade.getId() > 0){
				sorteioList = getSorteioFacade().findSorteioByUnidade(this.unidade.getId());
			}else {
				sorteioList = getSorteioFacade().listAll();
			}
		}
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<Sorteio> getSorteioList() {
		return sorteioList;
	}

	public void setSorteioList(List<Sorteio> sorteioList) {
		this.sorteioList = sorteioList;
	}

	public Unidade getUnidade() {
		return unidade;
	}

	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public List<Unidade> getUnidadeList() {
		return unidadeList;
	}

	public void setUnidadeList(List<Unidade> unidadeList) {
		this.unidadeList = unidadeList;
	}

	public boolean isComboSorteioDisabled() {
		return comboSorteioDisabled;
	}

	public void setComboSorteioDisabled(boolean comboSorteioDisabled) {
		this.comboSorteioDisabled = comboSorteioDisabled;
	}

	public boolean isComboUnidadeDisabled() {
		return comboUnidadeDisabled;
	}

	public void setComboUnidadeDisabled(boolean comboUnidadeDisabled) {
		this.comboUnidadeDisabled = comboUnidadeDisabled;
	}

	public boolean isSorteioListSetOpcaoTodas() {
		return sorteioListSetOpcaoTodas;
	}

	public void setSorteioListSetOpcaoTodas(boolean sorteioListSetOpcaoTodas) {
		this.sorteioListSetOpcaoTodas = sorteioListSetOpcaoTodas;
	}

	public boolean isUnidadeListSetOpcaoTodas() {
		return unidadeListSetOpcaoTodas;
	}

	public void setUnidadeListSetOpcaoTodas(boolean unidadeListSetOpcaoTodas) {
		this.unidadeListSetOpcaoTodas = unidadeListSetOpcaoTodas;
	}

	public String getNomeArquivoAnexo() {
		return nomeArquivoAnexo;
	}

	public void setNomeArquivoAnexo(String nomeArquivoAnexo) {
		this.nomeArquivoAnexo = nomeArquivoAnexo;
	}	

	public String getNomeRelat() {
		return nomeRelat;
	}

	public void setNomeRelat(String nomeRelat) {
		this.nomeRelat = nomeRelat;
	}

	public boolean isBotaoEmailVisible() {
		return botaoEmailVisible;
	}

	public void setBotaoEmailVisible(boolean botaoEmailVisible) {
		this.botaoEmailVisible = botaoEmailVisible;
	}

	public String getNomeArqRelat() {
		return nomeArqRelat;
	}

	public void setNomeArqRelat(String nomeArqRelat) {
		this.nomeArqRelat = nomeArqRelat;
	}

	public Report getReport() {
		return report;
	}

	public void setReport(Report report) {
		this.report = report;
	}

	public String getUnidadeLabel() {
		return unidadeLabel;
	}

	public void setUnidadeLabel(String unidadeLabel) {
		this.unidadeLabel = unidadeLabel;
	}

	public boolean isUnidadeVisible() {
		return unidadeVisible;
	}

	public void setUnidadeVisible(boolean unidadeVisible) {
		this.unidadeVisible = unidadeVisible;
	}

	public boolean isUnidadeObrigatorio() {
		return unidadeObrigatorio;
	}

	public void setUnidadeObrigatorio(boolean unidadeObrigatorio) {
		this.unidadeObrigatorio = unidadeObrigatorio;
	}

	public boolean isSorteioVisible() {
		return sorteioVisible;
	}

	public void setSorteioVisible(boolean sorteioVisible) {
		this.sorteioVisible = sorteioVisible;
	}

	public boolean isSorteioObrigatorio() {
		return sorteioObrigatorio;
	}

	public void setSorteioObrigatorio(boolean sorteioObrigatorio) {
		this.sorteioObrigatorio = sorteioObrigatorio;
	}

	public String getSorteioLabel() {
		return sorteioLabel;
	}

	public void setSorteioLabel(String sorteioLabel) {
		this.sorteioLabel = sorteioLabel;
	}

	public static int getReportQuartoLivre() {
		return REPORT_QUARTO_LIVRE;
	}

	public static int getReportQuartoAlocado() {
		return REPORT_QUARTO_ALOCADO;
	}

	public static int getReportResultSorteio() {
		return REPORT_RESULT_SORTEIO;
	}

	public static int getReportResultSorteioSup() {
		return REPORT_RESULT_SORTEIO_SUP;
	}

	public static int getReportResultSorteioSupSort() {
		return REPORT_RESULT_SORTEIO_SUP_SORT;
	}

	public static int getReportInscricao() {
		return REPORT_INSCRICAO;
	}

	public static int getReportSorteio() {
		return REPORT_SORTEIO;
	}

	public boolean isSemParametro() {
		return semParametro;
	}

	public void setSemParametro(boolean semParametro) {
		this.semParametro = semParametro;
	}
	
	
}
