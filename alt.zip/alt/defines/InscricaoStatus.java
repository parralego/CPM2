package com.defines;

public enum InscricaoStatus {
	ATIVO, CANCELADO, PENDENTE, ENCERRADO, SORTEADO, SUSPENSO;

}
