package com.defines;

public enum SorteioResultadoStatus {
	GERADO, SORTEADO, SORTEADO2, SUPLENTE, CANCELADO;
}
