package com.defines;

public enum SorteioStatus {
	FECHADO, ABERTO, ENCERRADO, SORTEADO, PROCESSADO, FINALIZADO;
}
