package com.defines;

public enum Role {
	ADMIN		("Administrador"), 
	CADASTRO	("Cadastro"),
	FINANCEIRO	("Financeiro"),
	COL_FER		("Col�nia de F�rias"),
	USER		("S�cio");
	
	private String descricao;
	
	Role(String descricao){
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
