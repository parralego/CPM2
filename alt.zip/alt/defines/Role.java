package com.defines;

public enum Role {
	ADMIN, USER;
}
