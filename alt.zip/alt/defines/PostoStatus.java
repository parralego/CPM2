package com.defines;

public enum PostoStatus {
	INATIVO, ATIVO;
}
