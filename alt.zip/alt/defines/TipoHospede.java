package com.defines;

public enum TipoHospede {
	DEPENDENTE, CONVIDADO;
}
