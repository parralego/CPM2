package com.defines;

public enum Sexo {
	M, F;
}
