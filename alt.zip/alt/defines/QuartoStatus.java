package com.defines;

public enum QuartoStatus {
	ATIVO, REFORMA, RESERVADO, INATIVO, RESERVA_TECNICA, RECREACAO; 
}
