package com.defines;

public enum AutenticacaoStatus {
	ATIVO, CANCELADO, USADO;
}
