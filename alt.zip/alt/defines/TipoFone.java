package com.defines;

public enum TipoFone {
	CELULAR, RESIDENCIAL, COMERCIAL, RECADO, FAX; 
}
