package com.defines;

public enum TipoLog {
	USER_APROVAR, USER_RECUSAR; 
}
