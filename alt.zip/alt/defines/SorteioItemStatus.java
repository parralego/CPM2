package com.defines;

public enum SorteioItemStatus {
	GERADO, SORTEADO, PENDENTE_PAGAMENTO, CANCELADO;
}
