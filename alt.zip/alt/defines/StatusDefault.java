package com.defines;

public enum StatusDefault {
	
	ATIVO		("ATIVO"	, "Ativo"),
    SUSPENSO	("SUSPENSO"	, "Suspenso"),
    CANCELADO	("CANCELADO", "Cancelado");

    private String id;
    private String descricao;
    
    StatusDefault(String id, String descricao){
        this.id = id;
        this.descricao = descricao;
    }

    public String getPreco(){
        return this.id;
    }
    
    public String getNome(){
        return this.descricao;
    }

}
