package com.defines;

public enum Bebida {
	
	CocaCola("Coca-cola", 2.00),
    Suco("Suco", 1.50),
    Agua("Agua", 1.00);

    private double preco;
    private String nome;
    
    Bebida(String nome, double preco){
        this.nome = nome;
        this.preco = preco;
    }

    public double getPreco(){
        return this.preco;
    }
    
    public String getNome(){
        return this.nome;
    }

}
