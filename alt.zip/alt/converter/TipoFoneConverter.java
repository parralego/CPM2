package com.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import com.defines.TipoFone;

@FacesConverter(forClass = com.defines.TipoFone.class)
public class TipoFoneConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		if(arg2.equals(TipoFone.CELULAR.toString()))
			return TipoFone.CELULAR;
		else if(arg2.equals(TipoFone.RESIDENCIAL.toString()))
			return TipoFone.RESIDENCIAL; 
		else if(arg2.equals(TipoFone.COMERCIAL.toString()))
			return TipoFone.COMERCIAL;
		else if(arg2.equals(TipoFone.RECADO.toString()))
			return TipoFone.RECADO;
		else if(arg2.equals(TipoFone.FAX.toString()))
			return TipoFone.FAX;
		
		else
			throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Tipo de Telefone n�o tradado", "Type the name of a TipoUser and select it (or use the dropdow)"));
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {

		if (arg2 == null) {
			return "";
		}
		return arg2.toString();
	}
}
