package com.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import com.facade.UnidadeFacade;
import com.model.Unidade;

@FacesConverter(forClass = com.model.Unidade.class)
public class UnidadeConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		UnidadeFacade facade = new UnidadeFacade();
		int objId;

		try {
			objId = Integer.parseInt(arg2);
		} catch (NumberFormatException exception) {
			throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Type the name of a Unidade and select it (or use the dropdow)", "Type the name of a Posto and select it (or use the dropdow)"));
		}

		return facade.find(objId);
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {

		if (arg2 == null) {
			return "";
		}
		Unidade obj = (Unidade) arg2;
		return String.valueOf(obj.getId());
	}
}
