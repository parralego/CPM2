package com.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import com.facade.MotivoCancelamentoFacade;
import com.model.MotivoCancelamento;

@FacesConverter(forClass = com.model.MotivoCancelamento.class)
public class MotivoCancelamentoConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		MotivoCancelamentoFacade tipoUserFacade = new MotivoCancelamentoFacade();
		int tipoUserId;

		try {
			tipoUserId = Integer.parseInt(arg2);
		} catch (NumberFormatException exception) {
			throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Type the name of a MotivoCancelamento and select it (or use the dropdow)", "Type the name of a MotivoCancelamento and select it (or use the dropdow)"));
		}

		return tipoUserFacade.findMotivoCancelamento(tipoUserId);
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {

		if (arg2 == null) {
			return "";
		}
		MotivoCancelamento tipoUser = (MotivoCancelamento) arg2;
		return String.valueOf(tipoUser.getId());
	}
}
