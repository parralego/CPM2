package com.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import com.facade.UserSituacaoFacade;
import com.model.UserSituacao;

@FacesConverter(forClass = com.model.UserSituacao.class)
public class UserSituacaoConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		UserSituacaoFacade facade = new UserSituacaoFacade();
		int objId;

		try {
			objId = Integer.parseInt(arg2);
		} catch (NumberFormatException exception) {
			throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Type the name of a UserSituacao and select it (or use the dropdow)", "Type the name of a UserSituacao and select it (or use the dropdow)"));
		}

		return facade.findUserSituacao(objId);
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {

		if (arg2 == null) {
			return "";
		}
		UserSituacao obj = (UserSituacao) arg2;
		return String.valueOf(obj.getId());
	}
}
