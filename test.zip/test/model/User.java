package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import com.defines.Role;
import com.defines.Sexo;
import com.defines.TipoFone;
import com.defines.UserStatus;

@Entity
@Table(name = "USERS")
@NamedQuery(name = "User.findUserByEmail", query = "select u from User u where u.email = :parm or u.cpf = :parm")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String FIND_BY_EMAIL = "User.findUserByEmail";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(unique = true)
	@Pattern(regexp=".+@.+\\.[a-z]+", message ="Email invalido!")
	private String email;
	
	@Column(unique = true)
	private String cpf;
	
	private String password;
	
	private String name;
	
	private Date dtNascimento;
	
	private String rg;
	
	@Enumerated(EnumType.STRING)
	private Sexo  sexo;
	
	@Enumerated(EnumType.STRING)
	private Role role;
	
	@Enumerated(EnumType.STRING)
	private UserStatus status;
	
	
	@Enumerated(EnumType.STRING)
	private TipoFone tipoFone1;
	
	private String numFone1;
	
	@Enumerated(EnumType.STRING)
	private TipoFone tipoFone2;
	
	private String numFone2;
	
	private String cpfTitular;
	
	private String codigoPostal;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String municipio;
	private String uf;  
	
	
	@ManyToOne
	private TipoUser tipoUser;
	
	@ManyToOne 
	@JoinColumn(name="tipo_quarto_id")
	private TipoQuarto tipoQuarto;
	
	@ManyToOne
	private UserSituacao userSituacao;
	
	@ManyToOne
	private Posto posto;
	
	
	
	public String primeiroNome(){
		return name.substring(0, name.indexOf(" "));
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public boolean isAdmin() {
		return Role.ADMIN.equals(role);
	}

	public boolean isUser() {
		return Role.USER.equals(role);
	}

	@Override
	public int hashCode() {
		return getId();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof User) {
			User user = (User) obj;
			return user.getId() == id;
		}

		return false;
	}

	public TipoUser getTipoUser() {
		return tipoUser;
	}

	public void setTipoUser(TipoUser tipoUser) {
		this.tipoUser = tipoUser;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public TipoFone getTipoFone1() {
		return tipoFone1;
	}

	public void setTipoFone1(TipoFone tipoFone1) {
		this.tipoFone1 = tipoFone1;
	}

	public String getNumFone1() {
		return numFone1;
	}

	public void setNumFone1(String numFone1) {
		this.numFone1 = numFone1;
	}

	public TipoFone getTipoFone2() {
		return tipoFone2;
	}

	public void setTipoFone2(TipoFone tipoFone2) {
		this.tipoFone2 = tipoFone2;
	}

	public String getNumFone2() {
		return numFone2;
	}

	public void setNumFone2(String numFone2) {
		this.numFone2 = numFone2;
	}

	public String getCpfTitular() {
		return cpfTitular;
	}

	public void setCpfTitular(String cpfTitular) {
		this.cpfTitular = cpfTitular;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public Date getDtNascimento() {
		return dtNascimento;
	}

	public void setDtNascimento(Date dateNascimento) {
		this.dtNascimento = dateNascimento;
	}

	public UserSituacao getUserSituacao() {
		return userSituacao;
	}

	public void setUserSituacao(UserSituacao userSituacao) {
		this.userSituacao = userSituacao;
	}

	public Posto getPosto() {
		return posto;
	}

	public void setPosto(Posto posto) {
		this.posto = posto;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public Sexo getSexo() {
		return sexo;
	}

	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

	public TipoQuarto getTipoQuarto() {
		return tipoQuarto;
	}

	public void setTipoQuarto(TipoQuarto tipoQuarto) {
		this.tipoQuarto = tipoQuarto;
	}
	
	
}