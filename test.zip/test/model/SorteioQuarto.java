package com.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.QuartoStatus;

@Table (name = "SORTEIO_QUARTO")
@Entity
@NamedQuery(name = "SorteioQuarto.findSorteioQuartoBySorteio"	, query = "SELECT Q FROM SorteioQuarto Q left join fetch Q.sorteio as S WHERE S.id= :sorteioId")
public class SorteioQuarto implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final String FIND_SORTEIO_QUARTO_BY_SORTEIO 	= "SorteioQuarto.findSorteioQuartoBySorteio";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="sorteio_id")
	private Sorteio sorteio; 
	
	@ManyToOne
	@JoinColumn(name="quarto_id")
	private Quarto quarto;
	
	@ManyToOne 
	@JoinColumn(name="tipo_quarto_id")
	private TipoQuarto tipoQuarto;
	
	@Enumerated(EnumType.STRING)
	private QuartoStatus status;
	
	private String obs;

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public Quarto getQuarto() {
		return quarto;
	}

	public void setQuarto(Quarto quarto) {
		this.quarto = quarto;
	}	

	public TipoQuarto getTipoQuarto() {
		return tipoQuarto;
	}

	public void setTipoQuarto(TipoQuarto tipoQuarto) {
		this.tipoQuarto = tipoQuarto;
	}

	public QuartoStatus getStatus() {
		return status;
	}

	public void setStatus(QuartoStatus status) {
		this.status = status;
	}

	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
