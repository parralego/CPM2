package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.defines.InscricaoStatus;

@Table (name = "INSCRICAO")
@Entity
@NamedQueries({
		@NamedQuery(name = "Inscricao.findInscricaoBySorteio"		, query = "SELECT I FROM Inscricao I left join fetch I.sorteio as S WHERE S.id= :sorteioId AND I.status NOT IN('CANCELADO', 'SUSPENSO')"	),
		@NamedQuery(name = "Inscricao.findInscricaoByUnidade"		, query = "SELECT I FROM Inscricao I inner join fetch I.sorteio as S inner join fetch s.unidade U WHERE U.id= :unidadeId AND S.id <> :sorteioId AND I.status NOT IN ('CANCELADO', 'SUSPENSO')"	),
		@NamedQuery(name = "Inscricao.findInscricaoByUser"			, query = "SELECT I FROM Inscricao I left join fetch I.user as U WHERE U.id = :userId AND I.status <> 'CANCELADO'"		)})
public class Inscricao implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String FIND_INSCRICAO_BY_SORTEIO 	= "Inscricao.findInscricaoBySorteio";
	public static final String FIND_INSCRICAO_BY_UNIDADE	= "Inscricao.findInscricaoByUnidade";
	public static final String FIND_INSCRICAO_BY_USER 		= "Inscricao.findInscricaoByUser";
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	
	@ManyToOne
	@JoinColumn(name="sorteio_id")
	private Sorteio sorteio; 
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user; 
	
	@ManyToOne
	@JoinColumn(name="user_sessao_id")
	private User userSessao; 
	
	@Enumerated(EnumType.STRING)
	private InscricaoStatus status;
	
	private Date dtCad;
	private Date dtAlt;
	
	private int numSort;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Sorteio getSorteio() {
		return sorteio;
	}
	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public User getUserSessao() {
		return userSessao;
	}
	public void setUserSessao(User userSessao) {
		this.userSessao = userSessao;
	}
	public InscricaoStatus getStatus() {
		return status;
	}
	public void setStatus(InscricaoStatus status) {
		this.status = status;
	}
	public Date getDtCad() {
		return dtCad;
	}
	public void setDtCad(Date dtCad) {
		this.dtCad = dtCad;
	}
	public Date getDtAlt() {
		return dtAlt;
	}
	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}
	public int getNumSort() {
		return numSort;
	}
	public void setNumSort(int numSort) {
		this.numSort = numSort;
	}
}
