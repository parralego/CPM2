package com.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.dao.Conexao;
import com.defines.InscricaoStatus;
import com.defines.QuartoStatus;
import com.defines.SorteioResultadoStatus;
import com.defines.SorteioStatus;
import com.facade.InscricaoFacade;
import com.facade.NumSortFacade;
import com.facade.SorteioFacade;
import com.facade.SorteioQuartoFacade;
import com.facade.SorteioResultadoFacade;
import com.facade.UserFacade;
import com.model.Inscricao;
import com.model.NumSort;
import com.model.Quarto;
import com.model.Sorteio;
import com.model.SorteioQuarto;
import com.model.SorteioResultado;
import com.model.User;
import com.util.Email;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;


@ViewScoped
@ManagedBean
public class SorteioResultadoMB extends AbstractMB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String  		cpfSorteioResultado;
	
	private Sorteio					sorteio;
	private SorteioResultado 		sorteioResultado;
	private List<SorteioResultado> 	sorteioResultadoList;
	private SorteioResultadoFacade 	sorteioResutladoFacade;
	
	private List<Inscricao> 		inscricaoList;
	private InscricaoFacade			inscricaoFacade;
	
	private List<NumSort> 			numSortList;
	private NumSortFacade 			numSortFacade;
	
	private User    		user;
	private UserFacade 		userFacade;
	
	private List<SorteioQuarto> sorteioQuartoList;
	private SorteioQuartoFacade sorteioQuartoFacade;
	
	@PostConstruct
	public void init(){
		this.acao = 1;
	}
	
	public void show(Sorteio sorteio){
		this.sorteio = sorteio;
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
		
		// Se jah existe resultado cadastrado
		if(sorteioResultadoList != null && !sorteioResultadoList.isEmpty())
			return;
		
		// Recuperas as incricoes do sorteio passado por parametro
		inscricaoList = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		if(inscricaoList == null){
			tools.msgAviso("N�o existem inscri��es realizadas para esse per�odo");
			return;
		}
		
		// Recuperas os quartos do sorteio passado por parametro
		this.sorteioQuartoList = getSorteioQuartoFacade().findSorteioQuartoBySorteio(sorteio.getId());
		if(sorteioQuartoList == null || sorteioQuartoList.isEmpty()){
			closeDialog();
			tools.msgErro("Os quartos ainda n�o foram cadastrados para esse sorteio.");
			return;
		}
		
		// Recuperas os numeros sorteados do sorteio passado por parametro
		this.numSortList = getNumSortFacade().findNumSortBySorteio(sorteio.getId());
		if(numSortList == null || numSortList.isEmpty()){
			tools.msgErro("Os n�meros de sorteio ainda n�o foram cadastrados para esse sorteio.");
			return;
		}
		
//		// Remover inscricoes de socios j� sorteados
//		List<SorteioResultado> sorteioResultadoListUnidade = getSorteioResultadoFacade().findSorteioResultadoByUnidade(sorteio.getUnidade().getId());
//		
//		if(sorteioResultadoListUnidade != null && !sorteioResultadoListUnidade.isEmpty()){
//			for(int i= 0; i < sorteioResultadoListUnidade.size(); i++){
//				if(sorteioResultadoListUnidade.get(1).getStatus().equals(SorteioResultadoStatus.SORTEADO)){
//					int iAntes = inscricaoList.size(); 
//					
//					inscricaoList.removeIf(f -> f.getUser().getId() == sorteioResultadoListUnidade.get(1).getInscricao().getUser().getId());
//					
//					int iDepois = inscricaoList.size();
//					
//					if(iAntes != iDepois)
//						System.out.println(iAntes - iDepois + " inscricoes removidas por (Socio jah sorteado)");
//				}
//			}
//		}
		
		sorteioResultadoList = new ArrayList<SorteioResultado>();
		SorteioResultado sorteioResultado;
		
		User userSessao = tools.getUserSession();
		Date dtCad = new Date();
		
		// Percorrrer todos os numeros sorteados do sorteio por ordem de sorteio
		for(int i = 0; i < this.numSortList.size(); i++){
			
			// Percorrrer todas as inscricoes do sorteio
			for(int j = 0; j < this.inscricaoList.size(); j++){
				
				// ACHOU NUMERO SORTEADO
				if(this.inscricaoList.get(j).getNumSort() == this.numSortList.get(i).getNumero()){
					
					// inicializar varivavel do resultado do sorteio
					sorteioResultado = new SorteioResultado();
					sorteioResultado.setInscricao(this.inscricaoList.get(j));
					sorteioResultado.setOrdem(i);
					sorteioResultado.setUserSessao(userSessao);
					sorteioResultado.setDtCad(dtCad);
					sorteioResultado.setDtAlt(dtCad);
					
					sorteioResultado.setStatus(SorteioResultadoStatus.SUPLENTE);
					sorteioResultado.setSorteioQuarto(null);
					
					
					// Procurar um quarto compativel (pelo tipo de quarto)
					for(int x = 0; x < this.sorteioQuartoList.size(); x++){
						if(this.inscricaoList.get(j).getUser().getTipoQuarto().getId() == this.sorteioQuartoList.get(x).getTipoQuarto().getId() ||
						   this.sorteioQuartoList.get(x).getTipoQuarto().getId() == Quarto.QUARTO_LIVRE){
							
							if(!this.sorteioQuartoList.get(x).getStatus().equals(QuartoStatus.ATIVO)){
								System.out.println("Quarto " + this.sorteioQuartoList.get(x).getQuarto().getNome() +" n�o ativo");
								continue;
							}
							
							if(this.sorteioQuartoList.get(x).getTipoQuarto().getId() == Quarto.QUARTO_LIVRE)
								sorteioResultado.setObs("Quarto Livre");
							else
								sorteioResultado.setObs("Quarto Patente");
							
							sorteioResultado.setSorteioQuarto(this.sorteioQuartoList.get(x));
							sorteioResultado.setStatus(SorteioResultadoStatus.SORTEADO);
							
							this.sorteioQuartoList.remove(x);	// Remover o quarto jah alocado da lista de quartos
							break;
						}
					}
					
					this.inscricaoList.remove(j);	// Remover a inscricao jah alocada da lista de inscricoes
					sorteioResultadoList.add(sorteioResultado);
					break;
				}
			}
		}
	}
	
	public void showConsulta(Sorteio sorteio){
		this.acao = 3;
		this.sorteio = sorteio;
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
	}
	
	
	public void salvar(){
		
		if(this.sorteioResultadoList == null || this.sorteioResultadoList.isEmpty()){
			tools.msgAviso("N�o existe resultado de sorteio.");
			return ;
		}
		
		
		// MARCAR TODAS AS INCRICOES DE SOCIOS SORTEADOS COMO CANCELADAS
		List<Inscricao> incricoesComSorteio = new ArrayList<Inscricao>();
		List<Inscricao> incricoesDaUnidade = getInscricaoFacade().listAllInscricaoByUnidade(this.sorteio.getUnidade().getId(), this.sorteio.getId());
		
		if(incricoesDaUnidade != null && !incricoesDaUnidade.isEmpty()){
			for(int i =0; i < sorteioResultadoList.size(); i++){
				// SE O SOCIO JAH FOR SORTEADO
				if(sorteioResultadoList.get(i).getStatus().equals(SorteioResultadoStatus.SORTEADO)){
					for(int j = 0; j < incricoesDaUnidade.size(); j++){
						
						// SE ACHAR UMA INSCCRICAO ATIVA PARA A MESMA UNIDADE ONDE JAH FOI SORTEADO
						if(sorteioResultadoList.get(i).getInscricao().getUser().getId() == incricoesDaUnidade.get(j).getUser().getId() ){
							incricoesDaUnidade.get(j).setStatus(InscricaoStatus.SUSPENSO);
							incricoesComSorteio.add(incricoesDaUnidade.get(j));	// ADICIONA NA LISTA PARA CANCELAR A INSCRICAO
							System.out.println("Inscricao CANCELADA pois o socio j� foi sorteado");
							System.out.println(incricoesDaUnidade.get(j).getId() + "-" + incricoesDaUnidade.get(j).getUser().getCpf() + "-" + incricoesDaUnidade.get(j).getSorteio().getDescricao());
							break;
						}
					}
				}
			}
		}
		
		
		
		// CANCELAR RESULTADO DE SORTEIO DE SOCIOS Q ESTAVA SUPLESNTES E FORAM SORTEADOS NO SORTEIO ATUAL
		List<SorteioResultado> sorteioResultadoListUnidadeComSorteio = new ArrayList<SorteioResultado>(); 
		List<SorteioResultado> sorteioResultadoListUnidade 			 = getSorteioResultadoFacade().findSorteioResultadoByUnidade(sorteio.getUnidade().getId());
		
		if(sorteioResultadoListUnidade != null && !sorteioResultadoListUnidade.isEmpty()){
			for(int i =0; i < sorteioResultadoList.size(); i++){
				if(sorteioResultadoList.get(i).getStatus().equals(SorteioResultadoStatus.SORTEADO)){
					for(int j= 0; j < sorteioResultadoListUnidade.size(); j++){
						if(sorteioResultadoList.get(i).getInscricao().getUser().getId() == sorteioResultadoListUnidade.get(j).getInscricao().getUser().getId() ){
							
							// SE FOR SUPLENTE E O SOCIO FOI SORTEADO ENTAO CANCELA A SUPENCIA
							if(sorteioResultadoListUnidade.get(j).getStatus().equals(SorteioResultadoStatus.SUPLENTE)){
								sorteioResultadoListUnidade.get(j).setStatus(SorteioResultadoStatus.CANCELADO);	// MARCA PARA CENCELADO
								sorteioResultadoListUnidade.get(j).setMotivoCancel(1);							// JAH SORTEADO
								sorteioResultadoListUnidade.get(j).setObsCancel("Sorcio ja sorteado " + sorteio.getDescricao());
								sorteioResultadoListUnidadeComSorteio.add(sorteioResultadoListUnidade.get(j));		// ADICIONA NA LISTA PARA CANCELAR A O RESULTADO DO SORTEIO
								
								System.out.println("Resultado do Sorteio CANCELADO pois o socio j� foi sorteado");
								System.out.println(sorteioResultadoListUnidade.get(j).getId() + "-" + sorteioResultadoListUnidade.get(j).getInscricao().getUser().getCpf() + "-" + sorteioResultadoListUnidade.get(j).getInscricao().getSorteio().getDescricao());
								break;
							}
						}
					}
				}
			}
		}
		
		
		// ADICIONAR O RESULTADO DE SORTEIO NA TABELA SORTEIO_RESULTADO
		try {
			getSorteioResultadoFacade().createSorteioResultadoList(this.sorteioResultadoList);
			System.out.println("Resultado do sorteio cadastrado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao cadastrar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// ATUALIZA TODAS AS INCRICOES DO SORTEIO PARA SORTEADO
		inscricaoList = getInscricaoFacade().findInscricaoBySorteio(sorteio.getId());
		for(int i = 0; i < inscricaoList.size(); i++){
			inscricaoList.get(i).setStatus(InscricaoStatus.SORTEADO);
		}
		
		try {
			getInscricaoFacade().updateInscricaoList(this.inscricaoList);
			System.out.println("Inscricoes atualizadas com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar inscricoes para SORTEADO");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		
		// ATUALIZAR TODAS AS ICRICOES ATIVAS DE SOCIOS JAH SORTEADOS PARA SUSPENSA 
		try {
			getInscricaoFacade().updateInscricaoList(incricoesComSorteio);
			System.out.println("Inscricoes atualizadas com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar inscricoes para SUSPENSA");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// CANCELAR TODAS AS SUPLENCIAS DE SOCIOS SORTEADOS NO SORTEIO ATUAL
		try {
			getSorteioResultadoFacade().updateSorteioResultadoList(sorteioResultadoListUnidadeComSorteio);
			System.out.println("Resultado do sorteio cadastrado com sucesso.");
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao cadastrar resultado do sorteio");
			e.printStackTrace();
			tools.msgErro("ERRO ao cadastrar o resutlado do sorteio.");
			return;
		}
		
		// ATAULIZAR SORTEIO PARA PROCESSADO
		try {
			SorteioFacade sorteioFacade = new SorteioFacade();
			sorteio.setStatus(SorteioStatus.PROCESSADO);
			sorteioFacade.updateSorteio(sorteio);
		} catch (Exception e) {
			keepDialogOpen();
			System.out.println("Erro ao atualizar sorteio para processado");
			tools.msgAviso("Erro ao atualizar sorteio.");
			e.printStackTrace();
			return;
		}
		
		tools.msgAviso("Resultado do sorteio cadastrado com sucesso.");
		
		return;
	}
	
	
	
	public void enviarEmailResultSorteio(Sorteio sorteio, int tipoEnvio) throws JRException{
		
		sorteioResultadoList = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteio.getId());
		
		if(sorteioResultadoList == null || sorteioResultadoList.isEmpty()){
			tools.msgAviso("N�o existe resultado de sorteio, o email n�o ser� enviado");
			return;
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteio.getId());
		
		String nomeRelat = "RelatorioResultadoSorteio"; 
		String nomeArqRelat = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 		+ nomeRelat + ".jrxml";
		String nomeArquivoAnexo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "WEB-INF/classes/report/" 	+ nomeRelat + ".pdf";
					
		JasperReport pathjrxml = JasperCompileManager.compileReport(nomeArqRelat);
		JasperPrint printReport = JasperFillManager.fillReport(pathjrxml, parameters, Conexao.getConexaoMySQL());
		JasperExportManager.exportReportToPdfFile(printReport, nomeArquivoAnexo);
		
		Email email = new Email();
		boolean teste=false;
		 
		if(tipoEnvio == 1) // LISTA DE SORTEADOS
			teste = email.sendEmailAvisoSorteio(nomeArquivoAnexo, sorteioResultadoList, null);
		else if (tipoEnvio == 2) // Usuario logado
			teste = email.sendEmailAvisoSorteio(nomeArquivoAnexo, null, tools.getUserSession());
		
		if(!teste){
			tools.msgErro("ERRO ao enviar email.");
			return;
		}
		
		tools.msgAviso("Email Enviado com sucesso.");
	}
	
	
	
	public List<SorteioResultado> allProcessados(){
		List<SorteioResultado> list = getSorteioResultadoFacade().listAll();
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public List<SorteioResultado> allByUser(){
		if(getUser() == null || getUser().getId() == 0)
			return null;
		
		List<SorteioResultado> list = getSorteioResultadoFacade().listAllSorteioResultadoByUser(getUser().getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public List<SorteioResultado> allByUser(User user){
		if(user == null)
			return null;
		
		List<SorteioResultado> list = getSorteioResultadoFacade().listAllSorteioResultadoByUser(user.getId());
		
		// S� deixar inscricoes ativas
		list.removeIf(p -> p.getStatus().equals(SorteioResultadoStatus.CANCELADO));
		
		return list;
	}
	
	public void buscarSocio(){
		
		// SE O CPF NAO MUDOU NAO BUSCA NOVAMENTE
		if(getUser().getCpf() == null || !getUser().getCpf().equals(cpfSorteioResultado)){
			user = getUserFacade().findByEmail(cpfSorteioResultado);
		}
	}
	
	
	public void verInscricoes(Sorteio sorteio){
		if(sorteio == null)
			return;
		
		sorteioResultadoList = listSorteioResultadoBySorteio(sorteio.getId());
	}
	
	public List<SorteioResultado> listSorteioResultadoBySorteio(int sorteioId) {
		List<SorteioResultado> list;
		
		list = getSorteioResultadoFacade().findSorteioResultadoBySorteio(sorteioId);
		
		if(list.isEmpty())
			return null;
		
		list.removeIf(f -> f.getStatus().equals(SorteioResultadoStatus.CANCELADO) );
		
		return list;
	}

	//
	// GETs e SETs
	//
	public InscricaoFacade getInscricaoFacade(){
		if(this.inscricaoFacade == null) 
			this.inscricaoFacade = new InscricaoFacade();
		
		return this.inscricaoFacade;
	}
	
	public SorteioQuartoFacade getSorteioQuartoFacade() {
		if (sorteioQuartoFacade == null)
			sorteioQuartoFacade = new SorteioQuartoFacade();

		return sorteioQuartoFacade;
	}
	
	public NumSortFacade getNumSortFacade() {
		if(numSortFacade == null)
			numSortFacade = new NumSortFacade();
		
		return numSortFacade;
	}
	
	

	public String getCpfSorteioResultado() {
		return cpfSorteioResultado;
	}

	public void setCpfSorteioResultado(String cpfSorteioResultado) {
		this.cpfSorteioResultado = cpfSorteioResultado;
	}

	public User getUser() {
		if(user == null)
			user = new User();
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserFacade getUserFacade() {
		if (userFacade == null) {
			userFacade = new UserFacade();
		}
		return userFacade;
	}

	public void setUserFacade(UserFacade userFacade) {
		this.userFacade = userFacade;
	}
	
	public SorteioResultadoFacade getSorteioResultadoFacade() {
		if (sorteioResutladoFacade == null) {
			sorteioResutladoFacade = new SorteioResultadoFacade();
		}

		return sorteioResutladoFacade;
	}

	public SorteioResultado getSorteioResultado() {
		if (sorteioResultado == null) {
			sorteioResultado = new SorteioResultado();
		}

		return sorteioResultado;
	}

	public void setSorteioResultado(SorteioResultado inscricao) {
		this.sorteioResultado = inscricao;
	}

	public List<SorteioResultado> getInscricoes() {
		return sorteioResultadoList;
	}

	public void setInscricoes(List<SorteioResultado> inscricoes) {
		this.sorteioResultadoList = inscricoes;
	}

	public Sorteio getSorteio() {
		return sorteio;
	}

	public void setSorteio(Sorteio sorteio) {
		this.sorteio = sorteio;
	}

	public List<SorteioResultado> getSorteioResultadoList() {
		return sorteioResultadoList;
	}

	public void setSorteioResultadoList(List<SorteioResultado> sorteioResultadoList) {
		this.sorteioResultadoList = sorteioResultadoList;
	}	
	
	
}