package com.defines;

public enum DefaultStatus {
	INATIVO, ATIVO, BLOQUEADO;
}
