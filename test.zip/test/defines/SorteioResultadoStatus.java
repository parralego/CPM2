package com.defines;

public enum SorteioResultadoStatus {
	GERADO, SORTEADO, SUPLENTE, CANCELADO;
}
