package com.defines;

public enum UserStatus {
	INATIVO, PENDENTE_ATIVACAO, ATIVO, BLOQUEADO, PENDENTE_ATUALIZACAO;
}
