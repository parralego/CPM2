package com.dao;

import com.model.Posto;

public class PostoDAO extends GenericDAO<Posto> {

	private static final long serialVersionUID = 1L;

	public PostoDAO() {
		super(Posto.class);
	}

	public void delete(Posto obj) {
		super.delete(obj.getId(), Posto.class);
	}

}