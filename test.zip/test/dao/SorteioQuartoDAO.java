package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.SorteioQuarto;

public class SorteioQuartoDAO extends GenericDAO<SorteioQuarto> {

	private static final long serialVersionUID = 1L;
	
	public List<SorteioQuarto> findSorteioQuartoBySorteio(int sorteioId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("sorteioId", sorteioId);

		return super.findAllByQuey(SorteioQuarto.FIND_SORTEIO_QUARTO_BY_SORTEIO, parameters);
	}
	

	public SorteioQuartoDAO() {
		super(SorteioQuarto.class);
	}

	public void delete(SorteioQuarto obj) {
		super.delete(obj.getId(), SorteioQuarto.class);
	}

}