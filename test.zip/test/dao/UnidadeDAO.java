package com.dao;

import java.util.HashMap;
import java.util.Map;

import com.model.Unidade;

public class UnidadeDAO extends GenericDAO<Unidade> {

	private static final long serialVersionUID = 1L;

	public UnidadeDAO() {
		super(Unidade.class);
	}

	public Unidade findUnidadeWithAllTipoUser(int unidadeId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("unidadeId", unidadeId);

		return super.findOneResult(Unidade.FIND_UNIDADE_BY_ID_WITH_TIPO_USERS, parameters);
	}

	public void delete(Unidade unidade) {
        	super.delete(unidade.getId(), Unidade.class);
	}
}
