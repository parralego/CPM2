package com.dao;

import com.model.Estadia;

public class EstadiaDAO extends GenericDAO<Estadia> {

	private static final long serialVersionUID = 1L;

	public EstadiaDAO() {
		super(Estadia.class);
	}

	public void delete(Estadia obj) {
		super.delete(obj.getId(), Estadia.class);
	}

}